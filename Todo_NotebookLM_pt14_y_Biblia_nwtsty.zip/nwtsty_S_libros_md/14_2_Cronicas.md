# Segundo Libro de las Crónicas (Segundo de las Crónicas)

---

## Información sobre 2 Crónicas

---

**2 CRÓNICAS**

## CONTENIDO DEL LIBRO

- **1**
  - Salomón pide sabiduría (1-12)
  - Las riquezas de Salomón (13-17)
- **2**
  - Preparativos para construir el templo (1-18)
- **3**
  - Salomón empieza a construir el templo (1-7)
  - El Santísimo (8-14)
  - Las dos columnas de cobre (15-17)
- **4**
  - El altar, el Mar y las palanganas (1-6)
  - Candelabros, mesas y patios (7-11a)
  - Se terminan los muebles y utensilios del templo (11b-22)
- **5**
  - Preparativos para la inauguración del templo (1-14)
    - Llevan el Arca al templo (2-10)
- **6**
  - Salomón le habla al pueblo (1-11)
  - La oración de inauguración de Salomón (12-42)
- **7**
  - La gloria de Jehová llena el templo (1-3)
  - Ceremonias de inauguración (4-10)
  - Jehová se le aparece a Salomón (11-22)
- **8**
  - Las otras construcciones de Salomón (1-11)
  - Se organiza la adoración en el templo (12-16)
  - La flota de Salomón (17, 18)
- **9**
  - La reina de Saba visita a Salomón (1-12)
  - Las riquezas de Salomón (13-28)
  - Muerte de Salomón (29-31)
- **10**
  - Israel se rebela contra Rehoboam (1-19)
- **11**
  - El reinado de Rehoboam (1-12)
  - Los levitas leales se mudan a Judá (13-17)
  - La familia de Rehoboam (18-23)
- **12**
  - Sisac ataca Jerusalén (1-12)
  - Fin del reinado de Rehoboam (13-16)
- **13**
  - Abías, rey de Judá (1-22)
    - Abías vence a Jeroboán (3-20)
- **14**
  - Muerte de Abías (1)
  - Asá, rey de Judá (2-8)
  - Derrota a 1.000.000 de etíopes (9-15)
- **15**
  - Asá hace reformas (1-19)
- **16**
  - Acuerdo de Asá con Siria (1-6)
  - Hananí reprende a Asá (7-10)
  - Muerte de Asá (11-14)
- **17**
  - Jehosafat, rey de Judá (1-6)
  - Campaña de enseñanza (7-9)
  - Las fuerzas militares de Jehosafat (10-19)
- **18**
  - La alianza de Jehosafat con Acab (1-11)
  - Micaya profetiza una derrota (12-27)
  - Matan a Acab en Ramot-Galaad (28-34)
- **19**
  - Jehú reprende a Jehosafat (1-3)
  - Jehosafat hace reformas (4-11)
- **20**
  - Las naciones vecinas amenazan Judá (1-4)
  - Jehosafat pide ayuda en oración (5-13)
  - La respuesta de Jehová (14-19)
  - Judá es salvada milagrosamente (20-30)
  - Fin del reinado de Jehosafat (31-37)
- **21**
  - Jehoram, rey de Judá (1-11)
  - Mensaje escrito de Elías (12-15)
  - Desastroso fin de Jehoram (16-20)
- **22**
  - Ocozías, rey de Judá (1-9)
  - Atalía se apodera del trono (10-12)
- **23**
  - Jehoiadá interviene; hacen rey a Jehoás (1-11)
  - Matan a Atalía (12-15)
  - Jehoiadá hace reformas (16-21)
- **24**
  - El reinado de Jehoás (1-3)
  - Jehoás renueva el templo (4-14)
  - Apostasía de Jehoás (15-22)
  - Asesinan a Jehoás (23-27)
- **25**
  - Amasías, rey de Judá (1-4)
  - Guerra con Edom (5-13)
  - Idolatría de Amasías (14-16)
  - Guerra con el rey Jehoás de Israel (17-24)
  - Muerte de Amasías (25-28)
- **26**
  - Uzías, rey de Judá (1-5)
  - Sus hazañas militares (6-15)
  - Castigado con lepra por ser arrogante (16-21)
  - Muerte de Uzías (22, 23)
- **27**
  - Jotán, rey de Judá (1-9)
- **28**
  - Acaz, rey de Judá (1-4)
  - Derrotado por Siria e Israel (5-8)
  - Oded advierte a Israel (9-15)
  - Judá es humillada (16-19)
  - Idolatría de Acaz; su muerte (20-27)
- **29**
  - Ezequías, rey de Judá (1, 2)
  - Ezequías hace reformas (3-11)
  - Se purifica el templo (12-19)
  - Se reanudan los servicios del templo (20-36)
- **30**
  - Ezequías celebra la Pascua (1-27)
- **31**
  - Ezequías acaba con la apostasía (1)
  - Los sacerdotes y levitas reciben el apoyo correspondiente (2-21)
- **32**
  - Senaquerib amenaza a Jerusalén (1-8)
  - Desafía a Jehová (9-19)
  - Un ángel ataca al ejército asirio (20-23)
  - Ezequías se enferma; se vuelve arrogante (24-26)
  - Los logros de Ezequías y su muerte (27-33)
- **33**
  - Manasés, rey de Judá (1-9)
  - Se arrepiente de su maldad (10-17)
  - Muerte de Manasés (18-20)
  - Amón, rey de Judá (21-25)
- **34**
  - Josías, rey de Judá (1, 2)
  - Josías hace reformas (3-13)
  - Encuentran el libro de la Ley (14-21)
  - Huldá profetiza una calamidad (22-28)
  - Josías lee el libro ante el pueblo (29-33)
- **35**
  - Josías organiza una gran Pascua (1-19)
  - El faraón Nekó mata a Josías (20-27)
- **36**
  - Jehoacaz, rey de Judá (1-3)
  - Jehoiaquim, rey de Judá (4-8)
  - Joaquín, rey de Judá (9, 10)
  - Sedequías, rey de Judá (11-14)
  - Destrucción de Jerusalén (15-21)
  - Ciro ordena la reconstrucción del templo (22, 23)

---

## Segundo de las Crónicas 1

**1** El reinado de Salomón hijo de David se fue fortaleciendo cada vez más. Jehová su Dios estaba con él y lo engrandeció de manera extraordinaria.

**2** Salomón convocó a todo Israel, a los jefes de mil y de cien, a los jueces y a todos los jefes de todo Israel, los jefes de las casas paternas.

**3** Entonces Salomón y toda la congregación fueron al lugar alto de Gabaón, porque allí era donde estaba la tienda de reunión del Dios verdadero, la que Moisés, el siervo de Jehová, había hecho en el desierto.

**4** Sin embargo, David había subido el Arca del Dios verdadero desde Quiryat-Jearim al lugar que le había preparado; le había montado una tienda en Jerusalén.

**5** El altar de cobre que había hecho Bezalel —hijo de Urí, hijo de Hur— lo habían puesto delante del tabernáculo de Jehová; y Salomón y la congregación solían orar delante del altar.

**6** Salomón entonces hizo ofrendas allí delante de Jehová; ofreció 1.000 ofrendas quemadas en el altar de cobre de la tienda de reunión.

**7** Aquella noche, Dios se le apareció a Salomón y le dijo: “Pídeme lo que quieras”.

**8** Salomón le respondió a Dios: “Tú le demostraste gran amor leal a mi padre David, y me has hecho rey en lugar de él.

**9** Ahora, oh, Jehová Dios, haz que se cumpla la promesa que le hiciste a David mi padre, porque me has hecho rey de un pueblo tan numeroso como las partículas de polvo que hay en la tierra.

**10** Dame sabiduría y conocimiento para que pueda dirigir a este pueblo, porque ¿quién es capaz de juzgar a este gran pueblo tuyo?”.

**11** Entonces Dios le dijo a Salomón: “Como ese es el deseo de tu corazón y no has pedido riquezas, ni bienes, ni honra, ni la muerte de los que te odian, ni una vida larga, sino que has pedido sabiduría y conocimiento para juzgar a mi pueblo, del cual te he hecho rey,

**12** recibirás sabiduría y conocimiento; pero también te daré riquezas, bienes y honra como no los ha tenido ningún rey antes que tú ni los tendrá ninguno después de ti”.

**13** Salomón volvió a Jerusalén desde el lugar alto de Gabaón, de delante de la tienda de reunión; y reinó sobre Israel.

**14** Salomón siguió acumulando carros y caballos. Llegó a tener 1.400 carros y 12.000 caballos, y los tenía estacionados en las ciudades de los carros y en Jerusalén, cerca del rey.

**15** El rey hizo que en Jerusalén la plata y el oro fueran tan abundantes como las piedras y que la madera de cedro fuera tan abundante como los sicómoros en la Sefelá.

**16** Los caballos de Salomón eran importados de Egipto; los mercaderes del rey compraban caballos por manadas a un precio establecido.

**17** Cada carro importado de Egipto costaba 600 piezas de plata, y cada caballo costaba 150. Entonces los exportaban a todos los reyes de los hititas y los reyes de Siria.

### Notas a pie de página
- **v. 5:** O “solían consultarlo a él allí”.
- **v. 10:** Lit. “para salir delante de este pueblo y para entrar”.
- **v. 11:** Lit. “muchos días”.
- **v. 14:** O “jinetes”.
- **v. 14:** O “jinetes”.
- **v. 16:** O quizás “de Egipto y de Coa; los mercaderes del rey los compraban de Coa”, que tal vez se refiere a Cilicia.

---

## Segundo de las Crónicas 2

**1** Salomón ahora dio la orden de construir una casa para el nombre de Jehová y una casa para su propio reino.

**2** Salomón reclutó 70.000 hombres como trabajadores comunes, 80.000 como picapedreros en las montañas y 3.600 como supervisores de ellos.

**3** Además, Salomón le mandó este mensaje a Hiram, el rey de Tiro: “Haz por mí lo mismo que hiciste por David mi padre cuando le enviaste madera de cedro para que él se construyera una casa donde vivir.

**4** Ahora voy a construir una casa para el nombre de Jehová mi Dios, para santificársela, para quemar incienso aromático delante de él y también para que los panes apilados estén allí constantemente y para presentar las ofrendas quemadas, por la mañana y por la tarde, en sábado, en luna nueva y en los periodos de fiesta de Jehová nuestro Dios. Esta es una obligación permanente para Israel.

**5** La casa que voy a construir será grandiosa, porque nuestro Dios es superior a todos los demás dioses.

**6** ¿Y quién es capaz de construirle una casa? Porque ni los cielos ni el cielo de los cielos pueden contenerlo. Por eso, ¿quién soy yo para construirle una casa? Tan solo puedo construir un lugar para hacer humear sacrificios delante de él.

**7** Ahora envíame un artesano que tenga habilidad trabajando el oro, la plata, el cobre, el hierro, la lana púrpura, el hilo rojo carmesí y el hilo azul, y que sepa esculpir. Él trabajará en Judá y Jerusalén con mis artesanos hábiles, que David mi padre proporcionó.

**8** Y envíame madera de cedro, enebro y sándalo desde el Líbano, porque yo sé que tus siervos son expertos talando árboles del Líbano. Mis siervos trabajarán junto con los tuyos

**9** para prepararme grandes cantidades de madera, porque la casa que voy a construir será extraordinariamente grande.

**10** Yo me encargaré de suministrarles alimento a tus siervos, a los leñadores que talen los árboles: 20.000 coros de trigo, 20.000 coros de cebada, 20.000 batos de vino y 20.000 batos de aceite”.

**11** Entonces Hiram, el rey de Tiro, le mandó por escrito este mensaje a Salomón: “Jehová te ha hecho rey de su pueblo porque lo ama”.

**12** Hiram también dijo: “Alabado sea Jehová, el Dios de Israel, que hizo los cielos y la tierra, porque le ha dado al rey David un hijo sabio, dotado de prudencia y entendimiento, que construirá una casa para Jehová y una casa para su propio reino.

**13** Te envío a un artesano hábil, un experto, Hiram-Abí.

**14** Es hijo de una mujer danita, pero su padre era de Tiro. Tiene experiencia trabajando el oro, la plata, el cobre, el hierro, la piedra, la madera, la lana púrpura, el hilo azul, la tela fina y el hilo rojo carmesí. Él sabe hacer cualquier clase de tallado y cualquier diseño que se le dé. Trabajará con tus artesanos hábiles y con los artesanos hábiles de mi señor David, tu padre.

**15** Que mi señor ahora les mande a sus siervos el trigo, la cebada, el aceite y el vino que ha prometido.

**16** Y nosotros talaremos árboles del Líbano —tantos como necesites—, haremos balsas con ellos y te los llevaremos por mar a Jope, y tú los subirás a Jerusalén”.

**17** Entonces Salomón hizo un censo de todos los hombres que eran residentes extranjeros en la tierra de Israel, igual que lo había hecho David su padre, y en total había 153.600.

**18** De manera que puso a 70.000 de ellos como trabajadores comunes, a 80.000 como picapedreros en las montañas y a 3.600 como supervisores para poner a la gente a trabajar.

### Notas a pie de página
- **v. 1:** O “un palacio”.
- **v. 2:** O “cargadores”.
- **v. 4:** Es decir, el pan de la presencia.
- **v. 10:** Un coro equivalía a 220 L (200 dry qt). Ver apén. B14.
- **v. 10:** Un bato equivalía a 22 L (5,81 gal). Ver apén. B14.
- **v. 18:** O “cargadores”.

---

## Segundo de las Crónicas 3

**1** Entonces Salomón empezó a construir la casa de Jehová en Jerusalén, en el monte Moria, donde Jehová se le había aparecido a su padre David, en el lugar que David había preparado en la era de Ornán el jebuseo.

**2** Empezó la construcción el día dos del segundo mes, en el cuarto año de su reinado.

**3** Y los cimientos que Salomón colocó para construir la casa del Dios verdadero medían 60 codos de largo y 20 codos de ancho, de acuerdo con la medida antigua.

**4** El pórtico en la parte delantera tenía el mismo ancho que la casa: 20 codos, y su altura era de 20 codos. Y él lo revistió por dentro de oro puro.

**5** Recubrió de madera de enebro la gran casa, después la revistió de oro de gran calidad y luego la decoró con figuras de palmeras y con cadenas.

**6** Además, revistió la casa de hermosas piedras preciosas, y el oro que usó era oro de Parvaim.

**7** Revistió de oro la casa, las vigas, los umbrales, sus paredes y sus puertas; y talló querubines en las paredes.

**8** Luego hizo el compartimiento del Santísimo; su longitud era igual al ancho de la casa, 20 codos, y su anchura también era de 20 codos. Lo revistió con 600 talentos de oro de gran calidad.

**9** El oro de los clavos pesaba 50 siclos, y revistió de oro las habitaciones de la azotea.

**10** Entonces hizo en el compartimiento del Santísimo dos esculturas de querubines, y las revistió de oro.

**11** La longitud total de las alas de los querubines era de 20 codos; una de las alas del primer querubín medía 5 codos de largo y tocaba la pared de la casa, y su otra ala medía 5 codos de largo y tocaba una de las alas del otro querubín.

**12** Y una de las alas del otro querubín medía 5 codos de largo y tocaba la otra pared de la casa, y su otra ala medía 5 codos de largo y tocaba una de las alas del primer querubín.

**13** Las alas extendidas de estos querubines abarcaban 20 codos; ellos estaban de pie y de cara al interior.

**14** También hizo la cortina de hilo azul, lana púrpura, hilo rojo carmesí y tela fina, y le bordó figuras de querubines.

**15** Entonces hizo delante de la casa dos columnas que medían 35 codos de largo, y el capitel encima de cada columna medía 5 codos.

**16** Además, hizo cadenas en forma de collar y las puso sobre las columnas, e hizo 100 granadas y las colocó en las cadenas.

**17** Levantó las columnas delante del templo, una a la derecha y una a la izquierda; a la de la derecha la llamó Jakín y a la de la izquierda Boaz.

### Notas a pie de página
- **v. 3:** Un codo estándar equivalía a 44,5 cm (17,5 in), pero algunos creen que “la medida antigua” se refiere al codo largo, que equivalía a 51,8 cm (20,4 in). Ver apén. B14.
- **v. 4:** Algunos manuscritos antiguos dicen “120”, pero otros manuscritos y algunas traducciones dicen “20 codos”.
- **v. 8:** Lit. “la casa”.
- **v. 8:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 9:** Un siclo equivalía a 11,4 g (0,367 oz tr). Ver apén. B14.
- **v. 9:** O “terraza”.
- **v. 10:** Lit. “la casa”.
- **v. 13:** Es decir, al Santo.
- **v. 17:** O “al sur”.
- **v. 17:** O “al norte”.
- **v. 17:** Que significa ‘que él [es decir, Jehová] establezca firmemente’.
- **v. 17:** Que posiblemente significa ‘con fuerza’.

---

## Segundo de las Crónicas 4

**1** Entonces hizo el altar de cobre; medía 20 codos de largo, 20 codos de ancho y 10 codos de alto.

**2** Hizo el Mar de metal fundido. Era circular, medía 10 codos de borde a borde, tenía 5 codos de alto y se necesitaba un cordón de 30 codos para rodearlo.

**3** Y por debajo lo rodeaban adornos de calabazas; había 10 por codo y rodeaban todo el Mar. Las calabazas estaban en dos filas y habían sido fundidas con él en una sola pieza.

**4** Estaba apoyado en 12 toros: 3 que miraban al norte, 3 que miraban al oeste, 3 que miraban al sur y 3 que miraban al este. El Mar descansaba sobre ellos, y todos estaban de espaldas al centro.

**5** El grosor del Mar era de un palmo menor y su borde era como el borde de una copa, como una flor de lirio. El depósito podía contener 3.000 batos.

**6** Además, hizo 10 palanganas; puso 5 a la derecha y 5 a la izquierda. Allí lavaban y enjuagaban las cosas que usaban para las ofrendas quemadas. Pero el Mar era para que se lavaran los sacerdotes.

**7** Entonces hizo 10 candelabros de oro, de acuerdo con las especificaciones, y los puso en el templo, 5 a la derecha y 5 a la izquierda.

**8** También hizo 10 mesas y las puso en el templo, 5 a la derecha y 5 a la izquierda, e hizo 100 tazones de oro.

**9** Luego hizo el patio de los sacerdotes y el gran patio y las puertas del gran patio, y revistió de cobre las puertas de estos.

**10** Y puso el Mar al lado derecho, al sureste.

**11** Hiram también hizo los baldes, las palas y los tazones. Así Hiram terminó los trabajos de la casa del Dios verdadero para el rey Salomón:

**12** las dos columnas y los dos capiteles en forma de tazón sobre las columnas; las dos mallas que cubrían los dos capiteles en forma de tazón sobre las columnas;

**13** las 400 granadas para las dos mallas —dos filas de granadas para cada malla— que cubrían los dos capiteles en forma de tazón sobre las columnas;

**14** los 10 carritos y las 10 palanganas sobre los carritos;

**15** el Mar y los 12 toros debajo de él;

**16** y los baldes, las palas, los tenedores y todos sus utensilios, que Hiram-Abiv hizo de cobre pulido para el rey Salomón, para la casa de Jehová.

**17** El rey mandó que los fundieran en el distrito del Jordán, en la arcilla espesa entre Sucot y Zeredá.

**18** Salomón hizo grandes cantidades de todos estos utensilios; no se llegó a saber el peso del cobre.

**19** Salomón hizo todos los utensilios para la casa del Dios verdadero: el altar de oro; las mesas para el pan de la presencia;

**20** los candelabros y sus lámparas de oro puro, para que estuvieran encendidas delante del cuarto más interior de acuerdo con las normas;

**21** las flores, lámparas y despabiladeras de oro, del oro más puro;

**22** los apagadores, tazones, copas y braserillos de oro puro; y la entrada de la casa, sus puertas interiores para el Santísimo y las puertas de la casa del templo, también de oro.

### Notas a pie de página
- **v. 2:** O “depósito”.
- **v. 5:** Unos 7,4 cm (2,9 in). Ver apén. B14.
- **v. 5:** O “tenía una capacidad de”.
- **v. 5:** Un bato equivalía a 22 L (5,81 gal). Ver apén. B14.
- **v. 9:** O “recinto”.
- **v. 14:** O “carritos para llevar agua”.
- **v. 21:** O “pinzas”.

---

## Segundo de las Crónicas 5

**1** Salomón terminó todo el trabajo que tenía que hacer para la casa de Jehová. Entonces trajo las cosas que su padre David había santificado y guardó la plata, el oro y todos los objetos en las cámaras del tesoro de la casa del Dios verdadero.

**2** Por aquel tiempo, Salomón reunió a los ancianos de Israel: a todos los jefes de las tribus y los jefes de las casas paternas de Israel. Vinieron a Jerusalén para subir el arca del pacto de Jehová desde la Ciudad de David, es decir, Sion.

**3** Todos los hombres de Israel se reunieron delante del rey durante la fiesta que se celebra el séptimo mes.

**4** Así que todos los ancianos de Israel vinieron, y los levitas levantaron el Arca.

**5** Subieron el Arca, la tienda de reunión y todos los utensilios santos que había en la tienda. Los subieron los sacerdotes y los levitas.

**6** El rey Salomón y toda la asamblea de Israel, que fue convocada para reunirse con él, estaban delante del Arca. Las ovejas y las reses que se estaban sacrificando eran tantas que no se podían contar ni numerar.

**7** Entonces los sacerdotes llevaron el arca del pacto de Jehová a su lugar, dentro del cuarto más interior de la casa, el Santísimo, debajo de las alas de los querubines.

**8** Las alas de los querubines estaban extendidas sobre el lugar donde estaba el Arca, de manera que los querubines cubrían el Arca y sus varas desde arriba.

**9** Las varas eran tan largas que sus puntas se podían ver desde el Santo, delante del cuarto más interior, pero no se podían ver desde fuera. Y allí siguen hasta el día de hoy.

**10** No había nada en el Arca excepto las dos tablas que Moisés había puesto dentro de ella en Horeb, cuando Jehová hizo un pacto con el pueblo de Israel al salir de Egipto.

**11** Cuando los sacerdotes salieron del lugar santo (porque todos los sacerdotes allí presentes se habían santificado sin importar sus divisiones),

**12** todos los cantores levitas que pertenecían a Asaf, a Hemán, a Jedutún y a sus hijos y sus hermanos iban vestidos de tela fina y llevaban címbalos, instrumentos de cuerda y arpas; estaban de pie al este del altar y junto con ellos había 120 sacerdotes tocando las trompetas.

**13** Los trompetistas y los cantores estaban alabando y dando gracias a Jehová todos a la vez. El sonido de las trompetas, los címbalos y los demás instrumentos musicales resonaba mientras alababan a Jehová, “porque él es bueno; su amor leal dura para siempre”. En ese momento, una nube llenó la casa, la casa de Jehová.

**14** Los sacerdotes no pudieron quedarse allí para realizar su servicio por causa de la nube, porque la gloria de Jehová llenó la casa del Dios verdadero.

### Notas a pie de página
- **v. 3:** Es decir, la Fiesta de las Cabañas.
- **v. 5:** O “los sacerdotes levitas”.

---

## Segundo de las Crónicas 6

**1** Entonces Salomón dijo: “Jehová dijo que él residiría entre densas nubes.

**2** Ahora yo he construido para ti una casa majestuosa, un lugar permanente donde mores para siempre”.

**3** Luego el rey se dio la vuelta y se puso a bendecir a toda la congregación de Israel, que estaba allí de pie.

**4** Y dijo: “Alabado sea Jehová, el Dios de Israel, quien cumplió con sus manos lo que le prometió con su boca a David mi padre:

**5** ‘Desde el día en que saqué de la tierra de Egipto a mi pueblo, no había escogido ninguna ciudad de todas las tribus de Israel para construir en ella una casa para que mi nombre permanezca allí. Tampoco había escogido a un hombre para que fuera líder de mi pueblo Israel.

**6** Pero ahora he escogido a Jerusalén para que mi nombre permanezca allí, y he escogido a David para gobernar a mi pueblo Israel’.

**7** Y fue el deseo de corazón de David mi padre construir una casa para el nombre de Jehová, el Dios de Israel.

**8** Pero Jehová le dijo a David mi padre: ‘Deseaste en tu corazón construir una casa para mi nombre, y fue bueno que desearas eso en tu corazón.

**9** Sin embargo, tú no construirás la casa. El hijo que vas a tener es quien construirá la casa para mi nombre’.

**10** Jehová ha cumplido su promesa, porque he sucedido a David mi padre y me siento en el trono de Israel, tal como lo prometió Jehová. También he construido la casa para el nombre de Jehová, el Dios de Israel,

**11** y allí he puesto el Arca, que contiene el pacto que Jehová hizo con el pueblo de Israel”.

**12** Entonces él se puso de pie frente al altar de Jehová, delante de toda la congregación de Israel, y extendió las manos.

**13** (Salomón había hecho una plataforma de cobre y la había puesto en medio del patio. Medía cinco codos de largo, cinco codos de ancho y tres codos de alto; y él se puso de pie sobre ella). Se arrodilló delante de toda la congregación de Israel, extendió las manos a los cielos

**14** y dijo: “Oh, Jehová, Dios de Israel. No hay ningún Dios como tú en los cielos ni en la tierra. Tú cumples el pacto y les muestras amor leal a tus siervos, los que andan en tus caminos con todo su corazón.

**15** Has cumplido la promesa que le hiciste a tu siervo David, mi padre. Hiciste la promesa con tu boca y hoy la has cumplido con tu mano.

**16** Y ahora, oh, Jehová, Dios de Israel, cumple la promesa que le hiciste a tu siervo David, mi padre, cuando le dijiste: ‘Si tus hijos prestan atención a sus pasos andando según mi ley, tal como tú has andado en mis caminos, siempre habrá delante de mí un descendiente tuyo que se siente en el trono de Israel’.

**17** Y ahora, oh, Jehová, Dios de Israel, que se cumpla la promesa que le hiciste a tu siervo David.

**18** ”Pero ¿acaso morará Dios en la tierra con la humanidad? Si ni los cielos, ni siquiera el cielo de los cielos, pueden contenerte, ¡mucho menos esta casa que he construido!

**19** Ahora presta atención a la oración y la súplica de este siervo tuyo. Oh, Jehová mi Dios, escucha los ruegos por ayuda y la oración que tu siervo está haciendo delante de ti.

**20** Que tus ojos miren día y noche esta casa —el lugar donde dijiste que pondrías tu nombre— para escuchar la oración que tu siervo haga hacia este lugar.

**21** Y escucha las súplicas de tu siervo cuando te pida ayuda y las súplicas de tu pueblo Israel cuando oren hacia este lugar. Escúchalas desde tu morada en los cielos. Escúchalas y perdónanos.

**22** ”Si alguien peca contra otra persona y se le obliga a hacer un juramento —y tiene que asumir las consecuencias de ese juramento— y entonces, estando bajo el juramento, se presenta ante tu altar en esta casa,

**23** escúchalo desde los cielos y actúa. Juzga a tus siervos: dale su merecido al malo y haz que sus actos recaigan sobre su propia cabeza; declara inocente al justo y recompénsalo de acuerdo con su justicia.

**24** ”Y, si tu pueblo Israel es derrotado por un enemigo por haber seguido pecando contra ti y se vuelven, glorifican tu nombre, oran y suplican ante ti en esta casa,

**25** entonces escúchalos desde los cielos, perdona el pecado de tu pueblo Israel y tráelos de vuelta a la tierra que les diste a ellos y a sus antepasados.

**26** ”Cuando los cielos estén cerrados y no llueva por haber seguido pecando ellos contra ti, y oren hacia este lugar, glorifiquen tu nombre y dejen su pecado porque tú los volviste humildes,

**27** entonces escúchalos desde los cielos y perdona el pecado de tus siervos, de tu pueblo Israel —porque les enseñarás el buen camino en que deben andar—, y haz llover sobre la tierra que le diste a tu pueblo en herencia.

**28** ”Si en el país hay hambre, una epidemia, un viento abrasador, tizón, plagas de langostas o langostas voraces, o si sus enemigos los cercan en alguna de las ciudades del país, o si ocurre cualquier otra clase de plaga o enfermedad,

**29** sea cual sea la oración, sea cual sea la súplica que haga cualquier persona o todo tu pueblo Israel cuando extienda las manos hacia esta casa (porque cada uno sabe cuál es su propia plaga y su propio dolor),

**30** entonces escucha desde los cielos, desde tu morada, y perdónalos. Págale a cada uno según su conducta, porque tú conoces su corazón (solo tú conoces bien el corazón de las personas),

**31** para que te teman andando en tus caminos todos los días que vivan en la tierra que les diste a nuestros antepasados.

**32** ”Además, respecto al extranjero que no es parte de tu pueblo Israel y que viene de una tierra distante por tu gran nombre, tu poderosa mano y tu poderoso brazo, y viene y ora hacia esta casa,

**33** escúchalo desde los cielos, desde tu morada, y haz todo lo que el extranjero te pida, para que todos los pueblos de la tierra conozcan tu nombre, te teman —como lo hace tu pueblo Israel— y sepan que tu nombre ha sido invocado sobre esta casa que he construido.

**34** ”Si tu pueblo va a la guerra a luchar contra sus enemigos por el camino en que los envíes y te oran en dirección a esta ciudad que has escogido y hacia la casa que he construido para tu nombre,

**35** entonces escucha desde los cielos su oración y su súplica, y hazles justicia.

**36** ”Si pecan contra ti (porque no hay nadie que no peque) y tú te enfureces con ellos y los entregas a un enemigo y sus vencedores se los llevan cautivos a otro país, sea lejos o cerca,

**37** y ellos recobran el juicio en el país al que los llevaron cautivos y se vuelven a ti y te suplican en el país donde estén cautivos diciendo ‘Hemos pecado y hemos fallado, hemos actuado muy mal’,

**38** y se vuelven a ti con todo su corazón y con toda su alma en el país al que los hayan llevado, donde estén cautivos, y oran en dirección a la tierra que les diste a sus antepasados y la ciudad que has escogido y la casa que he construido para tu nombre,

**39** entonces escucha desde los cielos, desde tu morada, la oración y la súplica de ellos, y hazles justicia y perdona a tu pueblo, que pecó contra ti.

**40** ”Ahora, oh, Dios mío, que tus ojos estén abiertos y tus oídos atentos a la oración ofrecida en este lugar.

**41** Y ahora sube, oh, Jehová Dios, a tu lugar de descanso, tú y el Arca de tu fuerza. Que tus sacerdotes, oh, Jehová Dios, estén vestidos de salvación, y que los que son leales a ti se alegren debido a tu bondad.

**42** Oh, Jehová Dios, no rechaces a tu ungido. Acuérdate del amor leal que le mostraste a David tu siervo”.

### Notas a pie de página
- **v. 9:** Lit. “Tu hijo, el que saldrá de tus lomos”.
- **v. 13:** O “recinto”.
- **v. 13:** Un codo equivalía a 44,5 cm (17,5 in). Ver apén. B14.
- **v. 22:** O “y esta le impone una maldición”. Es decir, un juramento que conllevaba una maldición como castigo si se juraba falsamente o si no se cumplía.
- **v. 22:** Lit. “la maldición”.
- **v. 22:** Lit. “la maldición”.
- **v. 23:** Lit. “justo”.
- **v. 26:** O “los afligiste”.
- **v. 28:** O “saltamontes”.
- **v. 28:** Lit. “en la tierra de las puertas de él”.
- **v. 29:** O “aflicción”.
- **v. 32:** O “fama”.
- **v. 38:** Ver glosario.
- **v. 40:** O “respecto a”.
- **v. 42:** Lit. “no apartes el rostro de”.

---

## Segundo de las Crónicas 7

**1** Tan pronto como Salomón acabó de orar, bajó fuego de los cielos y consumió la ofrenda quemada y los sacrificios, y la gloria de Jehová llenó la casa.

**2** Los sacerdotes no pudieron entrar en la casa de Jehová porque la gloria de Jehová había llenado la casa de Jehová.

**3** Todo el pueblo de Israel estaba mirando cuando el fuego bajó y la gloria de Jehová apareció sobre la casa. Se inclinaron rostro a tierra sobre el pavimento, se postraron y le dieron gracias a Jehová, “porque él es bueno; su amor leal dura para siempre”.

**4** El rey y todo el pueblo ofrecieron sacrificios delante de Jehová.

**5** El rey Salomón ofreció como sacrificio 22.000 reses y 120.000 ovejas. Así el rey y todo el pueblo inauguraron la casa del Dios verdadero.

**6** Los sacerdotes estaban de pie en sus puestos, igual que los levitas con los instrumentos que se usaban para acompañar las canciones para Jehová. (El rey David había hecho estos instrumentos para darle gracias a Jehová y para ofrecer alabanzas con ellos, “porque su amor leal dura para siempre”). Y los sacerdotes tocaban las trompetas bien alto enfrente de los levitas, mientras todos los israelitas estaban de pie.

**7** Entonces Salomón santificó el centro del patio que estaba delante de la casa de Jehová, porque tuvo que ofrecer allí las ofrendas quemadas y la grasa de los sacrificios de paz. Y es que el altar de cobre que Salomón había hecho no podía contener los sacrificios quemados, las ofrendas de grano y la grasa.

**8** En aquella ocasión, Salomón estuvo siete días celebrando la fiesta con todo Israel, una congregación muy grande de gente que venía de tan lejos como Lebó-Hamat y el torrente de Egipto.

**9** Pero al octavo día celebraron una asamblea solemne, porque habían celebrado siete días la inauguración del altar y siete días la fiesta.

**10** Entonces, el día 23 del séptimo mes, él mandó al pueblo a sus hogares. Se fueron con gran alegría y el corazón contento por la bondad que Jehová les había mostrado a David, a Salomón y a su pueblo Israel.

**11** Así terminó Salomón la casa de Jehová y la casa del rey; y Salomón terminó con éxito todo lo que planeó hacer para la casa de Jehová y su propia casa.

**12** Jehová entonces se le apareció a Salomón durante la noche y le dijo: “He oído tu oración, y he elegido para mí este lugar como casa de sacrificio.

**13** Cuando cierre los cielos y no llueva, y cuando les ordene a los saltamontes que se coman la vegetación del país, y en caso de que le envíe una epidemia a mi pueblo,

**14** si mi pueblo —que lleva mi nombre— se humilla y ora y busca mi rostro y deja sus malos caminos, entonces yo los escucharé desde los cielos y les perdonaré su pecado y sanaré su tierra.

**15** Ahora mis ojos estarán abiertos y mis oídos atentos a la oración hecha en este lugar.

**16** Y ahora he elegido y santificado esta casa para que mi nombre esté en ella de manera permanente, y mis ojos y mi corazón siempre estarán allí.

**17** ”Y, si tú andas en mis caminos como lo hizo tu padre David y haces todo lo que te he mandado y obedeces mis normas y mis decisiones judiciales,

**18** entonces yo estableceré el trono de tu reinado, tal como pacté con tu padre David cuando dije ‘Siempre habrá un descendiente tuyo gobernando a Israel’.

**19** Pero, si ustedes se desvían y dejan los estatutos y los mandamientos que les he dado, y se van a servir a otros dioses y a inclinarse ante ellos,

**20** entonces yo arrancaré de raíz a Israel de mi tierra, que les he dado, y quitaré de mi vista esta casa que he santificado para mi nombre, y la convertiré en objeto de desprecio y motivo de burla entre todos los pueblos.

**21** Y esta casa llegará a ser un montón de ruinas. Todo el que pase junto a ella se quedará mirando asombrado y preguntará: ‘¿Por qué Jehová les hizo eso a esta tierra y a esta casa?’.

**22** Entonces responderán: ‘Fue porque abandonaron a Jehová, el Dios de sus antepasados, quien los sacó de la tierra de Egipto. Se aferraron a otros dioses y se inclinaron ante ellos y les sirvieron. Por eso él les trajo toda esta calamidad’”.

### Notas a pie de página
- **v. 6:** Posiblemente se refiere a los levitas.
- **v. 7:** O “de comunión”.
- **v. 8:** O “la entrada de Hamat”.
- **v. 8:** O “wadi”.
- **v. 9:** El día después de la fiesta, o el día 15.
- **v. 11:** O “el palacio”.
- **v. 20:** Lit. “un proverbio”.

---

## Segundo de las Crónicas 8

**1** Al cabo de 20 años, en los cuales Salomón construyó la casa de Jehová y su propia casa,

**2** Salomón reconstruyó las ciudades que Hiram le había dado y estableció israelitas allí.

**3** Además, Salomón fue a Hamat-Zobá y la conquistó.

**4** Entonces fortificó Tadmor, en el desierto, y todas las ciudades de almacenamiento que había construido en Hamat.

**5** También construyó Bet-Horón Alta y Bet-Horón Baja —ciudades fortificadas con murallas, puertas y barras—,

**6** y Baalat, así como todas las ciudades de almacenamiento de Salomón, todas las ciudades de los carros, las ciudades para los jinetes y todo lo que Salomón quiso construir en Jerusalén, en el Líbano y en toda la tierra bajo su dominio.

**7** En cuanto a toda la gente que quedó de los hititas, los amorreos, los perizitas, los heveos y los jebuseos, que no eran parte de Israel,

**8** Salomón reclutó a los descendientes de ellos que quedaron en el país —aquellos a quienes los israelitas no habían exterminado— para que hicieran trabajos forzados, y así siguen hasta el día de hoy.

**9** Pero Salomón no convirtió a ningún israelita en esclavo para sus obras, pues ellos eran sus guerreros, los jefes de sus oficiales y los jefes de sus conductores de carros y de sus jinetes.

**10** Había 250 jefes de los comisarios del rey Salomón, los capataces de los trabajadores.

**11** Salomón también hizo que la hija del faraón subiera de la Ciudad de David a la casa que él le había hecho, pues dijo: “Aunque sea mi esposa, no debe vivir en la casa del rey David de Israel, porque los lugares a los que ha venido el Arca de Jehová son santos”.

**12** Entonces Salomón le ofreció sacrificios quemados a Jehová en el altar de Jehová que él había construido enfrente del pórtico.

**13** Seguía la rutina diaria y hacía ofrendas de acuerdo con el mandamiento de Moisés para los sábados, las lunas nuevas y las tres fiestas anuales: la Fiesta de los Panes Sin Levadura, la Fiesta de las Semanas y la Fiesta de las Cabañas.

**14** Además, estableció las divisiones de los sacerdotes para sus servicios de acuerdo con las instrucciones de su padre David; también puso a los levitas en sus puestos de servicio, para que alabaran a Dios y sirvieran en presencia de los sacerdotes según la rutina diaria, y puso a los porteros en sus divisiones para las distintas puertas, porque eso fue lo que ordenó David, el hombre del Dios verdadero.

**15** No se apartaron de las órdenes del rey para los sacerdotes y los levitas en ningún asunto, ni en lo que tiene que ver con los almacenes.

**16** De modo que toda la obra de Salomón estuvo bien organizada, desde el día en que se colocaron los cimientos de la casa de Jehová hasta que quedó terminada. Así fue como se completó la casa de Jehová.

**17** Entonces Salomón fue a Ezión-Guéber y a Elot, a orillas del mar, en la tierra de Edom.

**18** Por medio de sus propios siervos, Hiram le mandó barcos y marineros de experiencia. Fueron con los siervos de Salomón a Ofir y de allí trajeron 450 talentos de oro y se los entregaron al rey Salomón.

### Notas a pie de página
- **v. 1:** O “propio palacio”.
- **v. 2:** Lit. “hijos de Israel”.
- **v. 4:** O “reconstruyó”.
- **v. 13:** Se refiere a refugios temporales.
- **v. 16:** O “se completó”.
- **v. 18:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.

---

## Segundo de las Crónicas 9

**1** La reina de Saba oyó hablar de la fama de Salomón, así que vino a Jerusalén a poner a Salomón a prueba con preguntas difíciles. Iba acompañada de un séquito muy impresionante, con camellos que traían aceite balsámico, muchísimo oro y piedras preciosas. Se presentó ante Salomón y le dijo todo lo que ella tenía en la mente.

**2** Salomón le contestó todas sus preguntas. No hubo nada demasiado difícil para Salomón. Pudo explicárselo todo.

**3** Cuando la reina de Saba vio la sabiduría de Salomón, la casa que había construido,

**4** los alimentos de su mesa, la manera como estaban sentados sus siervos, el servicio de los meseros y su atuendo, los coperos y su atuendo, cuando vio los sacrificios quemados que él ofrecía con regularidad en la casa de Jehová, ella se quedó sin aliento.

**5** Así que le dijo al rey: “Todo lo que escuché en mi país sobre tus logros y tu sabiduría era cierto.

**6** Pero yo no creí lo que decían hasta que vine y lo vi con mis propios ojos. Y la verdad es que no me habían contado ni la mitad de lo sabio que eres. Tú superas por mucho lo que escuché.

**7** ¡Felices tus hombres y felices tus siervos, que están siempre contigo escuchando tu sabiduría!

**8** Alabado sea Jehová tu Dios, que te vio con agrado y te sentó en su trono como rey para Jehová tu Dios. Como tu Dios ama a Israel y quiere que permanezca para siempre, te ha nombrado rey para que gobiernes con justicia y rectitud”.

**9** Entonces le dio al rey 120 talentos de oro y una gran cantidad de aceite balsámico y piedras preciosas. Nunca más se llegó a traer tanto aceite balsámico como el que la reina de Saba le dio al rey Salomón.

**10** Además, los siervos de Hiram y los siervos de Salomón que traían oro de Ofir también trajeron madera de sándalo y piedras preciosas.

**11** Con la madera de sándalo, el rey hizo escaleras para la casa de Jehová y para la casa del rey, y también arpas e instrumentos de cuerda para los cantores. Nunca se había visto madera como esa en la tierra de Judá.

**12** El rey Salomón también le dio a la reina de Saba todo lo que ella quiso y pidió, más que lo que ella le había traído al rey. Entonces ella se fue y regresó a su país junto con sus siervos.

**13** El peso del oro que el rey Salomón recibía cada año era de 666 talentos de oro,

**14** aparte del que traían los mercaderes y los comerciantes, así como todos los reyes de los árabes y los gobernadores del país que le traían oro y plata a Salomón.

**15** El rey Salomón hizo 200 escudos grandes de oro aleado (cada escudo tenía 600 siclos de oro aleado)

**16** y 300 escudos pequeños de oro aleado (cada escudo tenía tres minas de oro). Entonces el rey los puso en la Casa del Bosque del Líbano.

**17** Además, el rey hizo un gran trono de marfil y lo revistió de oro puro.

**18** Había seis escalones para subir al trono, y fijado a él había un banquillo de oro. El asiento tenía un brazo a cada lado, y un león de pie junto a cada brazo.

**19** Y había 12 leones de pie sobre los seis escalones, uno en cada extremo de los seis escalones. Ningún otro reino tenía algo así.

**20** Todas las copas del rey Salomón eran de oro, y todos los utensilios de la Casa del Bosque del Líbano eran de oro puro. No había nada que fuera de plata, porque en los días de Salomón no se le daba ningún valor a la plata.

**21** Los barcos del rey iban a Tarsis con los siervos de Hiram. Cada tres años, los barcos de Tarsis venían cargados de oro, plata, marfil, monos y pavos reales.

**22** El rey Salomón era más rico y más sabio que todos los demás reyes de la tierra.

**23** Los reyes de toda la tierra querían visitar a Salomón para oír la sabiduría que el Dios verdadero le había puesto en el corazón.

**24** Todos le traían regalos: objetos de plata, objetos de oro, ropa, armas, aceite balsámico, caballos y mulas. Esto sucedía año tras año.

**25** Y Salomón tenía 4.000 compartimientos para sus caballos en sus establos, carros y 12.000 caballos, y los tenía estacionados en las ciudades de los carros y en Jerusalén, cerca del rey.

**26** Y tenía bajo su dominio a todos los reyes desde el Río hasta la tierra de los filisteos y hasta la frontera de Egipto.

**27** El rey hizo que en Jerusalén la plata fuera tan abundante como las piedras y que la madera de cedro fuera tan abundante como los sicómoros en la Sefelá.

**28** Además, a Salomón le traían caballos de Egipto y de todos los demás países.

**29** En cuanto al resto de la historia de Salomón, está escrito de principio a fin entre las palabras del profeta Natán, en la profecía de Ahíya el silonita y en el registro de las visiones de Idó —el hombre de visiones— acerca de Jeroboán hijo de Nebat.

**30** Salomón reinó en Jerusalén sobre todo Israel por 40 años.

**31** Entonces Salomón descansó con sus antepasados y lo enterraron en la Ciudad de David, su padre; y su hijo Rehoboam se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 1:** O “Seba”.
- **v. 1:** O “enigmas”.
- **v. 1:** O “una caravana”.
- **v. 1:** O “en el corazón”.
- **v. 2:** Lit. “nada escondido”.
- **v. 4:** Lit. “no hubo más espíritu en ella”.
- **v. 5:** O “palabras”.
- **v. 9:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 11:** O “el palacio”.
- **v. 12:** O quizás “además de regalos que correspondían al valor de”.
- **v. 15:** Un siclo equivalía a 11,4 g (0,367 oz tr). Ver apén. B14.
- **v. 16:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 16:** La mina que se menciona en las Escrituras Hebreas equivalía a 570 g (18,35 oz tr). Ver apén. B14.
- **v. 23:** Lit. “buscaban el rostro de”.
- **v. 25:** O “jinetes”.
- **v. 26:** Es decir, el río Éufrates.

---

## Segundo de las Crónicas 10

**1** Rehoboam fue a Siquem, pues todo Israel había venido a Siquem para hacerlo rey.

**2** Cuando Jeroboán hijo de Nebat se enteró de eso, enseguida regresó de Egipto (él seguía en Egipto porque había huido debido al rey Salomón).

**3** Entonces mandaron a buscarlo, y Jeroboán y todo Israel fueron a ver a Rehoboam y le dijeron:

**4** “Tu padre hizo que nuestro yugo fuera duro. Pero, si tú aligeras el duro servicio y el pesado yugo que nos impuso tu padre, nosotros te serviremos”.

**5** Él les contestó: “Regresen a verme en tres días”. De modo que la gente se fue.

**6** El rey Rehoboam entonces consultó a los ancianos que le habían servido a su padre Salomón cuando todavía vivía. Les preguntó: “¿Qué me aconsejan que le responda a este pueblo?”.

**7** Ellos le contestaron: “Si tratas bien a este pueblo, lo complaces y le das una respuesta favorable, ellos siempre serán tus siervos”.

**8** Sin embargo, él rechazó el consejo que le dieron los ancianos y consultó a los jóvenes que se habían criado con él y que ahora eran sus ayudantes.

**9** Les preguntó: “¿Qué me aconsejan? Esta gente me dijo: ‘Haz más ligero el yugo que tu padre nos impuso’. ¿Qué debemos contestarles?”.

**10** Los jóvenes que se habían criado con él le dijeron: “A la gente que te ha dicho: ‘Tu padre hizo pesado nuestro yugo; hazlo tú más ligero’, debes contestarle esto: ‘Mi meñique será más grueso que las caderas de mi padre.

**11** Mi padre les impuso a ustedes un yugo pesado, pero yo se lo haré más pesado. Mi padre los castigó con látigos, pero yo lo haré con látigos de puntas afiladas’”.

**12** Jeroboán y todos los demás fueron a ver a Rehoboam al tercer día, tal como les había indicado el rey cuando dijo “Regresen a verme dentro de tres días”.

**13** Pero el rey les contestó con dureza. De ese modo el rey Rehoboam pasó por alto el consejo de los ancianos.

**14** Siguiendo el consejo de los jóvenes, les dijo: “Yo haré que el yugo de ustedes sea más pesado, más pesado todavía. Mi padre los castigó con látigos, pero yo lo haré con látigos de puntas afiladas”.

**15** Así que el rey no escuchó al pueblo, porque el Dios verdadero hizo que las cosas ocurrieran así, a fin de cumplir las palabras que Jehová le había dicho a Jeroboán hijo de Nebat mediante Ahíya el silonita.

**16** En cuanto a todo Israel, como el rey no quiso escucharlos, el pueblo le respondió al rey: “¿Qué tenemos que ver con David? No tenemos ninguna herencia con el hijo de Jesé. ¡Vamos, Israel, que cada uno se vaya con sus dioses! David, ocúpate ahora de tu propia casa”. Entonces todos los de Israel volvieron a sus hogares.

**17** Pero Rehoboam siguió reinando sobre los israelitas que vivían en las ciudades de Judá.

**18** Entonces el rey Rehoboam les envió a Hadoram, que estaba al mando de los reclutados para trabajo obligatorio, pero los israelitas lo mataron a pedradas. El rey Rehoboam logró subirse a su carro para huir a Jerusalén.

**19** Y los israelitas han estado en rebelión contra la casa de David hasta el día de hoy.

### Notas a pie de página
- **v. 4:** O “el opresivo”.
- **v. 6:** Ver glosario.
- **v. 8:** Ver glosario.
- **v. 13:** Ver glosario.
- **v. 16:** Lit. “tiendas”.

---

## Segundo de las Crónicas 11

**1** Cuando Rehoboam llegó a Jerusalén, inmediatamente reunió a la casa de Judá y a Benjamín, 180.000 guerreros adiestrados, para pelear contra Israel y devolverle el reino a Rehoboam.

**2** Entonces Semaya, el hombre del Dios verdadero, recibió este mensaje de Jehová:

**3** “Diles a Rehoboam hijo de Salomón —el rey de Judá— y a todos los israelitas en Judá y Benjamín:

**4** ‘Esto es lo que dice Jehová: “No suban a pelear contra sus hermanos. Que cada uno vuelva a su casa, porque yo hice que esto pasara”’”. Así que ellos obedecieron las palabras de Jehová y regresaron; no fueron a pelear contra Jeroboán.

**5** Rehoboam vivió en Jerusalén e hizo ciudades fortificadas en Judá.

**6** Fortificó Belén, Etam, Tecoa,

**7** Bet-Zur, Socó, Adulam,

**8** Gat, Maresá, Zif,

**9** Adoraim, Lakís, Azecá,

**10** Zorá, Ayalón y Hebrón. Esas ciudades de Judá y de Benjamín fueron fortificadas.

**11** Además, reforzó las ciudades fortificadas. Puso en ellas comandantes y las abasteció de alimentos, aceite y vino.

**12** A todas esas ciudades les suministró escudos grandes y lanzas; las hizo muy fuertes. Y Judá y Benjamín siguieron siendo de él.

**13** Y los sacerdotes y los levitas que estaban en todo Israel dejaron sus territorios y se pusieron de parte de Rehoboam.

**14** Los levitas dejaron sus campos de pasto y sus propiedades, y vinieron a Judá y Jerusalén, porque Jeroboán y sus hijos los habían quitado de sus puestos de sacerdotes para Jehová.

**15** Jeroboán nombró a sus propios sacerdotes para los lugares altos y para servir tanto a los demonios parecidos a cabras como a los becerros que había hecho.

**16** Y los de las tribus de Israel que estaban decididos de corazón a buscar a Jehová, el Dios de Israel, siguieron a los sacerdotes y los levitas a Jerusalén para hacerle sacrificios a Jehová, el Dios de sus antepasados.

**17** Por tres años fortalecieron el reinado de Judá y apoyaron a Rehoboam hijo de Salomón, porque estuvieron tres años siguiendo los pasos de David y Salomón.

**18** Entonces Rehoboam se casó con Mahalat, la hija de Jerimot —hijo de David— y de Abihail, la hija de Eliab, hijo de Jesé.

**19** Con el tiempo ella tuvo estos hijos con él: Jeús, Semarías y Zaham.

**20** Después de ella, él se casó con Maacá, la nieta de Absalón. Con el tiempo ella tuvo con él a Abías, Atái, Zizá y Selomit.

**21** Rehoboam amaba a Maacá, la nieta de Absalón, más que a todas sus otras esposas y concubinas; y es que tuvo 18 esposas y 60 concubinas, y fue padre de 28 hijos y 60 hijas.

**22** Rehoboam nombró a Abías hijo de Maacá como jefe y líder entre sus hermanos, porque pensaba hacerlo rey.

**23** Sin embargo, actuó con inteligencia y envió a algunos de sus hijos a todas las regiones de Judá y de Benjamín, a todas las ciudades fortificadas. Además, les dio muchas provisiones y les consiguió muchas esposas.

### Notas a pie de página
- **v. 1:** Lit. “escogidos”.
- **v. 2:** O “la palabra”.
- **v. 8:** O “Maresah”. Ver apén. A2.
- **v. 15:** Lit. “las cabras”.
- **v. 15:** O “terneros”.
- **v. 23:** O “entendimiento”.
- **v. 23:** O “dispersó”.

---

## Segundo de las Crónicas 12

**1** Poco después de que su reinado se consolidó y él se hizo fuerte, Rehoboam dejó la Ley de Jehová, y todo Israel hizo lo mismo.

**2** En el quinto año del rey Rehoboam, el rey Sisac de Egipto subió a atacar Jerusalén, pues ellos le habían sido infieles a Jehová.

**3** Él tenía 1.200 carros, 60.000 jinetes e innumerables soldados que llegaron con él desde Egipto: libios, sukiyim y etíopes.

**4** Conquistó las ciudades fortificadas de Judá y finalmente llegó a Jerusalén.

**5** El profeta Semaya vino a ver a Rehoboam y a los príncipes de Judá que se habían reunido en Jerusalén por miedo a Sisac, y les dijo: “Esto es lo que dice Jehová: ‘Ustedes me han abandonado, así que yo también los he abandonado en manos de Sisac’”.

**6** Ante eso, los príncipes de Israel y el rey se humillaron y dijeron: “Jehová es justo”.

**7** Cuando Jehová vio que se habían humillado, Semaya recibió este mensaje de Jehová: “Se han humillado. No los destruiré, y dentro de poco los rescataré. No derramaré mi ira sobre Jerusalén mediante Sisac.

**8** Pero se convertirán en sus siervos, y así sabrán la diferencia entre servirme a mí y servirles a los reyes de otros países”.

**9** El rey Sisac de Egipto subió a atacar Jerusalén. Se llevó los tesoros de la casa de Jehová y los tesoros de la casa del rey. Se lo llevó todo, incluidos los escudos de oro que Salomón había hecho.

**10** Así que el rey Rehoboam hizo escudos de cobre para reemplazarlos y los puso al cuidado de los jefes de la guardia, que vigilaban la entrada de la casa del rey.

**11** Cada vez que el rey venía a la casa de Jehová, los guardias llegaban con los escudos y después volvían a ponerlos en el cuarto de los guardias.

**12** Como el rey se humilló, la furia de Jehová se calmó y no los destruyó por completo. Además, había algunas cosas buenas en Judá.

**13** El rey Rehoboam ganó más poder en Jerusalén y siguió reinando; Rehoboam tenía 41 años cuando se convirtió en rey, y reinó 17 años en Jerusalén, la ciudad que Jehová eligió de todas las tribus de Israel para poner allí su nombre. La madre del rey se llamaba Naamá la ammonita.

**14** Ahora bien, él hizo lo que estaba mal, porque no había decidido en su corazón buscar a Jehová.

**15** En cuanto a la historia de Rehoboam, está escrita de principio a fin en el registro genealógico entre las palabras del profeta Semaya y de Idó, el hombre de visiones. Y siempre hubo guerras entre Rehoboam y Jeroboán.

**16** Entonces Rehoboam descansó con sus antepasados y fue enterrado en la Ciudad de David. Y su hijo Abías se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 7:** O “la palabra”.
- **v. 8:** Lit. “reinos”.
- **v. 9:** O “del palacio”.
- **v. 10:** Lit. “de los corredores”.

---

## Segundo de las Crónicas 13

**1** Abías se convirtió en rey de Judá en el año 18 del rey Jeroboán.

**2** Reinó tres años en Jerusalén, y el nombre de su madre era Micaya hija de Uriel de Guibeá. Y hubo guerra entre Abías y Jeroboán.

**3** De modo que Abías fue a la guerra con un ejército de 400.000 guerreros poderosos y adiestrados. Y Jeroboán se colocó en formación de batalla contra él con 800.000 hombres adiestrados, guerreros poderosos.

**4** Abías entonces se puso de pie sobre el monte Zemaraim, que está en la región montañosa de Efraín, y dijo: “¡Jeroboán, todo Israel, óiganme!

**5** ¿No saben que Jehová, el Dios de Israel, le dio a David el reino de Israel para siempre, a él y a sus hijos, mediante un pacto de sal?

**6** Pero Jeroboán hijo de Nebat, el siervo de Salomón, hijo de David, se levantó y se rebeló contra su señor.

**7** Con él se juntaban hombres desocupados e inútiles. Y ellos pudieron más que Rehoboam hijo de Salomón, que era joven e inseguro y no tuvo la fuerza para enfrentarse a ellos.

**8** ”Y ahora ustedes se creen que tienen suficiente fuerza para enfrentarse al reino de Jehová en manos de los hijos de David porque son muchísimos y porque tienen los becerros de oro que Jeroboán hizo para que fueran sus dioses.

**9** ¿No expulsaron ustedes a los sacerdotes de Jehová, los descendientes de Aarón, y a los levitas? ¿Y no nombraron ustedes a sus propios sacerdotes, como hacen los pueblos de otros países? Cualquiera que venía con un toro joven y siete carneros se podía convertir en sacerdote de dioses que no son dioses.

**10** En cuanto a nosotros, Jehová es nuestro Dios y no lo hemos abandonado; nuestros sacerdotes, los descendientes de Aarón, están sirviendo a Jehová, y los levitas los ayudan con el trabajo.

**11** Cada mañana y cada tarde hacen humear ofrendas quemadas para Jehová junto con incienso aromático, y los panes apilados están sobre la mesa de oro puro, y cada tarde encienden el candelabro de oro y sus lámparas. Nosotros estamos cumpliendo con nuestra responsabilidad hacia Jehová nuestro Dios, pero ustedes lo han abandonado.

**12** ¡Miren! El Dios verdadero está con nosotros, nos está dirigiendo, con sus sacerdotes y las trompetas para dar el toque de guerra contra ustedes. Hombres de Israel, no peleen contra Jehová, el Dios de sus antepasados, porque no vencerán”.

**13** Pero Jeroboán preparó una emboscada para atacarlos por detrás. De modo que su ejército estaba enfrente de Judá y los de la emboscada detrás.

**14** Cuando los hombres de Judá se dieron la vuelta, vieron que tendrían que pelear por delante y también por detrás. Así que empezaron a suplicarle a Jehová mientras los sacerdotes tocaban bien fuerte las trompetas.

**15** Los hombres de Judá dieron un grito de guerra. Y, cuando los hombres de Judá soltaron el grito de guerra, el Dios verdadero derrotó a Jeroboán y a todo Israel delante de Abías y Judá.

**16** Los israelitas salieron huyendo de Judá y Dios los entregó en sus manos.

**17** Abías y su gente mataron a muchísimos de ellos; murieron 500.000 hombres adiestrados de Israel.

**18** Así se humilló a los hombres de Israel en aquella ocasión, pero los hombres de Judá salieron vencedores porque confiaron en Jehová, el Dios de sus antepasados.

**19** Abías siguió persiguiendo a Jeroboán y le quitó estas ciudades: Betel y sus pueblos dependientes, Jesaná y sus pueblos dependientes, y Efrén y sus pueblos dependientes.

**20** Jeroboán nunca recuperó su poder en la época de Abías; entonces Jehová le causó la muerte.

**21** Pero Abías fue ganando poder. Con el tiempo llegó a tener 14 esposas, 22 hijos y 16 hijas.

**22** Y el resto de la historia de Abías —las cosas que hizo y sus palabras— está registrado en los escritos del profeta Idó.

### Notas a pie de página
- **v. 2:** O “Guibeah”. Ver apén. A2.
- **v. 3:** Lit. “escogidos”.
- **v. 3:** Lit. “escogidos”.
- **v. 5:** Es decir, un pacto duradero e inalterable.
- **v. 9:** Lit. “venía a llenar su mano con”.
- **v. 11:** Es decir, el pan de la presencia.
- **v. 17:** Lit. “escogidos”.
- **v. 18:** Lit. “se apoyaron”.
- **v. 19:** O “cercanos”.
- **v. 22:** O “la exposición”, “el comentario”.

---

## Segundo de las Crónicas 14

**1** Entonces Abías descansó con sus antepasados y lo enterraron en la Ciudad de David, y su hijo Asá se convirtió en el nuevo rey. En sus días la región tuvo 10 años de paz.

**2** Asá hizo lo que era bueno y correcto a los ojos de Jehová su Dios.

**3** Quitó los altares de dioses extranjeros y los lugares altos, destrozó las columnas sagradas y derribó los postes sagrados.

**4** Además, le dijo a Judá que buscara a Jehová, el Dios de sus antepasados, y que obedeciera la Ley y los mandamientos.

**5** Así que quitó los lugares altos y los altares de incienso de todas las ciudades de Judá, y el reino disfrutó de paz bajo su gobierno.

**6** Construyó ciudades fortificadas en Judá aprovechando que había paz en la región. No hubo guerras contra él durante esos años porque Jehová le dio descanso.

**7** Asá le dijo a Judá: “Vamos a construir estas ciudades y a rodearlas de murallas y torres, de puertas y barras. El país todavía está en nuestro poder, pues hemos buscado a Jehová nuestro Dios. Lo hemos buscado, y él nos ha dado paz en todos lados”. Y su construcción fue todo un éxito.

**8** Asá tenía un ejército de 300.000 hombres de Judá con escudos grandes y lanzas. Y de Benjamín había 280.000 guerreros poderosos que llevaban escudos pequeños y que iban armados con arcos.

**9** Tiempo después, Zérah el etíope vino a atacarlos con un ejército de 1.000.000 de hombres y 300 carros. Cuando llegó a Maresá,

**10** Asá salió a enfrentarse con él, y se colocaron en formación de batalla en el valle de Zefata, junto a Maresá.

**11** Asá entonces le rogó a Jehová su Dios y le dijo: “Oh, Jehová, para ti no hay diferencia entre ayudar a los que son fuertes y ayudar a los que son débiles. Ayúdanos, Jehová nuestro Dios, porque confiamos en ti, y es en tu nombre que vinimos a enfrentarnos con esta multitud. Jehová, tú eres nuestro Dios. No permitas que simples hombres mortales te venzan”.

**12** De modo que Jehová derrotó a los etíopes delante de Asá y de Judá, y los etíopes salieron huyendo.

**13** Asá y su gente los persiguieron hasta Guerar, y los etíopes fueron cayendo hasta que ninguno quedó vivo, pues Jehová y su ejército los aplastaron. Después, los hombres de Judá se llevaron un botín enorme.

**14** Además, atacaron todas las ciudades alrededor de Guerar, pues estas se llenaron de miedo a causa de Jehová. Saquearon todas las ciudades, porque había mucho que saquear en ellas.

**15** También atacaron las tiendas de los que tenían ganado, y se quedaron con muchos rebaños y camellos. Después de eso regresaron a Jerusalén.

### Notas a pie de página
- **v. 1:** O “descanso”.
- **v. 3:** Ver glosario.
- **v. 7:** Lit. “puertas dobles”.
- **v. 7:** Lit. “descanso”.
- **v. 8:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 8:** Lit. “y pisaban el arco”.
- **v. 9:** O “Maresah”. Ver apén. A2.
- **v. 10:** O “Maresah”. Ver apén. A2.
- **v. 11:** Lit. “muchos”.
- **v. 11:** Lit. “nos apoyamos”.
- **v. 15:** O “carpas”.

---

## Segundo de las Crónicas 15

**1** Y el espíritu de Dios vino sobre Azarías hijo de Oded.

**2** Entonces Azarías salió al encuentro de Asá y le dijo: “¡Asá, todo Judá y Benjamín! ¡Óiganme! Jehová estará con ustedes mientras ustedes sigan estando con él. Si lo buscan, él dejará que lo encuentren; pero, si lo abandonan, él los abandonará.

**3** Por mucho tiempo Israel había estado sin el Dios verdadero, sin ningún sacerdote que enseñara y sin ley.

**4** Pero, cuando en su angustia volvieron a Jehová —el Dios de Israel— y lo buscaron, él dejó que lo encontraran.

**5** En aquellos tiempos nadie podía viajar de forma segura, pues había muchos disturbios entre todos los habitantes de los países.

**6** Las naciones se destruían unas a otras y las ciudades también, porque Dios las mantenía en estado de caos con todo tipo de calamidades.

**7** Pero, en cuanto a ustedes, sean fuertes y no se desanimen, pues su labor será recompensada”.

**8** Tan pronto como Asá oyó estas palabras y la profecía del profeta Oded, se armó de valor y quitó los ídolos repugnantes de toda la tierra de Judá y Benjamín y de las ciudades que había conquistado en la región montañosa de Efraín. También restauró el altar de Jehová que estaba delante del pórtico de Jehová.

**9** Y reunió a todo Judá y Benjamín y a los residentes extranjeros de Efraín, Manasés y Simeón que había entre ellos, porque un gran número de ellos se había pasado de Israel al bando de Asá cuando vieron que Jehová su Dios estaba con él.

**10** Se reunieron en Jerusalén el tercer mes del año 15 del reinado de Asá.

**11** Ese día le sacrificaron a Jehová 700 reses y 7.000 ovejas del botín que habían traído.

**12** Además, hicieron un pacto en el que se comprometían a buscar con todo su corazón y con toda su alma a Jehová, el Dios de sus antepasados.

**13** Cualquiera que no buscara a Jehová, el Dios de Israel, tendría que morir, fuera pequeño o grande, hombre o mujer.

**14** Así que le hicieron un juramento a Jehová en voz alta, con gritos de alegría y tocando trompetas y cuernos.

**15** Todo Judá se alegró muchísimo por el juramento, porque lo habían hecho con todo el corazón. Buscaron a Jehová con mucho empeño y él dejó que lo encontraran, y les siguió dando paz en todos lados.

**16** El rey Asá incluso le quitó el puesto de reina madre a su abuela Maacá, porque ella había hecho un ídolo obsceno para la adoración del poste sagrado. Asá derribó su ídolo obsceno, y lo pulverizó y lo quemó en el valle de Cedrón.

**17** Pero no se quitaron los lugares altos de Israel. Aun así, Asá sirvió a Dios con un corazón completo toda su vida.

**18** Y trajo a la casa del Dios verdadero las cosas que él y su padre habían santificado: plata, oro y diversos utensilios.

**19** No hubo ninguna guerra hasta el año 35 del reinado de Asá.

### Notas a pie de página
- **v. 3:** Lit. “Y muchos días”.
- **v. 5:** Lit. “no había paz para el que salía ni para el que entraba”.
- **v. 7:** Lit. “no dejen caer las manos”.
- **v. 12:** Ver glosario.
- **v. 15:** Lit. “descanso”.
- **v. 16:** O “de dama”.
- **v. 17:** O “completamente dedicado”.
- **v. 17:** Lit. “todos sus días”.

---

## Segundo de las Crónicas 16

**1** En el año 36 del reinado de Asá, el rey Baasá de Israel fue contra Judá y se puso a fortificar Ramá para no dejar que nadie saliera del territorio del rey Asá de Judá ni entrara en él.

**2** Ante eso, Asá sacó plata y oro de las cámaras del tesoro de la casa de Jehová y de la casa del rey y se los envió al rey Ben-Hadad de Siria, que estaba viviendo en Damasco. Le dijo:

**3** “Hay un acuerdo entre tú y yo, y entre tu padre y mi padre. Aquí te envío plata y oro. Vamos, rompe tu acuerdo con el rey Baasá de Israel para que se aleje de mí”.

**4** Ben-Hadad le hizo caso al rey Asá y envió a los jefes de sus ejércitos a atacar las ciudades de Israel, y ellos conquistaron Ijón, Dan, Abel-Maim y todos los almacenes de las ciudades de Neftalí.

**5** Cuando Baasá se enteró, enseguida dejó de fortificar Ramá y abandonó las obras.

**6** El rey Asá tomó consigo a todo Judá, y se llevaron de Ramá las piedras y la madera que Baasá había usado para construir, y con ellas Asá fortificó Gueba y Mizpá.

**7** En aquel tiempo el vidente Hananí vino a ver al rey Asá de Judá y le dijo: “Por confiar en el rey de Siria y no confiar en Jehová tu Dios, el ejército del rey de Siria se te ha escapado de las manos.

**8** ¿Verdad que los etíopes y los libios eran un ejército enorme con muchos carros y jinetes? Pero confiaste en Jehová y él los entregó en tus manos.

**9** Porque los ojos de Jehová están vigilando toda la tierra para mostrar su fuerza a favor de los que le sirven con un corazón completo. Pero esta vez te portaste como un tonto; de ahora en adelante habrá guerras contra ti”.

**10** Esto hizo que Asá se pusiera furioso; se ofendió con el vidente y lo metió en prisión. En ese tiempo Asá también empezó a maltratar a algunos del pueblo.

**11** Pues bien, la historia de Asá está escrita de principio a fin en el Libro de los Reyes de Judá y de Israel.

**12** En el año 39 de su reinado, Asá empezó a padecer una enfermedad en los pies y acabó poniéndose muy mal; pero aun durante su enfermedad no acudió a Jehová, sino a los médicos.

**13** Entonces Asá descansó con sus antepasados; murió en el año 41 de su reinado.

**14** De modo que lo enterraron en la sepultura majestuosa que él se había excavado en la Ciudad de David. Lo acostaron en una camilla cubierta de aceite balsámico y un ungüento especial hecho a base de una mezcla de distintos ingredientes. Además, le hicieron una hoguera enorme en su funeral.

### Notas a pie de página
- **v. 1:** O “reconstruir”.
- **v. 2:** O “del palacio”.
- **v. 3:** O “pacto”.
- **v. 5:** O “reconstruir”.
- **v. 6:** O “reconstruyó”.
- **v. 7:** Lit. “apoyarte”.
- **v. 7:** Lit. “no apoyarte”.
- **v. 9:** O “para apoyar a”.
- **v. 9:** O “completamente dedicado a él”.
- **v. 10:** Lit. “en la casa de los cepos”.
- **v. 12:** O “sanadores”.
- **v. 14:** Al parecer, lo que quemaron fueron especias, y no a Asá.

---

## Segundo de las Crónicas 17

**1** Y su hijo Jehosafat se convirtió en el nuevo rey, y consolidó su posición sobre Israel.

**2** Colocó fuerzas militares en todas las ciudades fortificadas de Judá. También puso tropas en la tierra de Judá y en las ciudades de Efraín que su padre Asá había conquistado.

**3** Jehová continuó con Jehosafat porque siguió los pasos que había seguido su antepasado David en tiempos anteriores y no acudió a los Baales.

**4** Y es que él buscó al Dios de su padre y siguió sus mandamientos en vez de seguir las prácticas de Israel.

**5** Jehová mantuvo el reino firmemente establecido en sus manos. Y todo Judá le continuó dando regalos a Jehosafat, y él tuvo riquezas y gloria en abundancia.

**6** Cobró valor en su corazón y siguió los caminos de Jehová. Hasta quitó de Judá los lugares altos y los postes sagrados.

**7** En el tercer año de su reinado mandó traer a sus príncipes Ben-Hail, Abdías, Zacarías, Netanel y Micaya, para impartir enseñanza en las ciudades de Judá.

**8** Con ellos estaban estos levitas: Semaya, Netanías, Zebadías, Asahel, Semiramot, Jehonatán, Adonías, Tobiya y Tob-Adonías. Y, junto con ellos, los sacerdotes Elisamá y Jehoram.

**9** Empezaron a enseñar en Judá, llevando con ellos el libro de la Ley de Jehová. Fueron por todas las ciudades de Judá enseñando a la gente.

**10** Y todos los reinos de las tierras que rodeaban Judá sintieron mucho miedo a causa de Jehová y no pelearon contra Jehosafat.

**11** Y los filisteos le traían a Jehosafat como tributo regalos y dinero. Los árabes le traían de sus rebaños 7.700 carneros y 7.700 machos de las cabras.

**12** Jehosafat se hizo cada vez más poderoso. Siguió construyendo fortalezas y ciudades de almacenamiento en Judá.

**13** Realizó grandes proyectos en las ciudades de Judá, y en Jerusalén tenía soldados, guerreros poderosos.

**14** Estaban agrupados según sus casas paternas. De Judá, estaban los jefes de mil. Estaba el jefe Adná, y con él había 300.000 guerreros poderosos.

**15** Él tenía bajo su mando al jefe Jehohanán, y con él había 280.000.

**16** Y también tenía bajo su mando a Amasíah hijo de Zicrí, que se ofreció voluntariamente para servir a Jehová, y con él había 200.000 guerreros poderosos.

**17** Y, de Benjamín, estaba Eliadá, un guerrero poderoso, y con él había 200.000 hombres armados con arcos y escudos.

**18** Él tenía bajo su mando a Jehozabad, y con él había 180.000 hombres equipados para la guerra.

**19** Estos servían al rey, además de los que el rey había puesto en las ciudades fortificadas por todo Judá.

### Notas a pie de página
- **v. 2:** O “guarniciones”.
- **v. 4:** Lit. “anduvo en”.
- **v. 14:** O “Adnah”. Ver apén. A2.

---

## Segundo de las Crónicas 18

**1** Aunque Jehosafat tenía riquezas y gloria en abundancia, hizo una alianza matrimonial con Acab.

**2** Así que unos años más tarde bajó a ver a Acab en Samaria. Acab sacrificó muchas ovejas y reses para él y para la gente que estaba con él, y le insistió a Jehosafat para que atacara Ramot-Galaad.

**3** Entonces el rey Acab de Israel le dijo al rey Jehosafat de Judá: “¿Irás conmigo a Ramot-Galaad?”. Él le contestó: “Yo estaré contigo, y mi pueblo estará con tu pueblo y te apoyará en la guerra”.

**4** Pero Jehosafat le dijo al rey de Israel: “Por favor, primero averigua qué dice Jehová”.

**5** Así que el rey de Israel juntó a los profetas, 400 hombres, y les dijo: “¿Vamos a la guerra contra Ramot-Galaad, o no?”. Ellos le dijeron: “Sube, que el Dios verdadero la entregará en manos del rey”.

**6** Entonces Jehosafat dijo: “¿No hay por aquí un profeta de Jehová? Consultemos a Dios también por medio de él”.

**7** El rey de Israel le contestó a Jehosafat: “Todavía queda un hombre por medio de quien podemos consultar a Jehová, pero yo lo odio, porque las cosas que profetiza sobre mí nunca son buenas, siempre son malas. Es Micaya hijo de Imlá”. Pero Jehosafat dijo: “El rey no debería hablar así”.

**8** Así que el rey de Israel llamó a un funcionario de la corte y le dijo: “Rápido, trae a Micaya hijo de Imlá”.

**9** El rey de Israel y Jehosafat, el rey de Judá, estaban sentados en la era a la entrada de la puerta de Samaria. Estaban sentados cada cual en su trono y vestidos con ropas reales. Y todos los profetas estaban profetizando delante de ellos.

**10** Entonces Sedequías hijo de Kenaaná se hizo unos cuernos de hierro y dijo: “Esto es lo que dice Jehová: ‘Con estos cuernos embestirás a los sirios hasta exterminarlos’”.

**11** Todos los demás profetas profetizaban lo mismo. Decían: “Sube a Ramot-Galaad, que vencerás. Jehová la entregará en manos del rey”.

**12** El mensajero que fue a llamar a Micaya le dijo: “Mira que todo lo que dijeron los profetas era bueno para el rey. Por favor, di tú lo mismo que ellos, anuncia algo bueno”.

**13** Pero Micaya dijo: “Tan cierto como que Jehová vive, diré lo que mi Dios diga”.

**14** Entonces se presentó ante el rey, y el rey le preguntó: “Micaya, ¿vamos a la guerra contra Ramot-Galaad, o no voy?”. Al instante contestó: “Sube, que vencerás. Ellos serán entregados en manos de ustedes”.

**15** Al oír esto, el rey le dijo: “¿Cuántas veces tengo que hacerte jurar que me dirás solo la verdad en el nombre de Jehová?”.

**16** Así que él dijo: “Veo a todos los israelitas esparcidos por las montañas, como ovejas sin pastor. Jehová dijo: ‘No tienen amo. Que cada uno vuelva a su casa en paz’”.

**17** Entonces el rey de Israel le dijo a Jehosafat: “¿No te dije ‘Él no profetizará cosas buenas sobre mí, solo malas’?”.

**18** Y Micaya dijo: “Escucha ahora las palabras de Jehová. Vi a Jehová sentado en su trono y a todo el ejército de los cielos de pie a su derecha y a su izquierda.

**19** Jehová entonces dijo: ‘¿Quién engañará al rey Acab de Israel para que suba a Ramot-Galaad y muera allí?’. Y uno decía una cosa, mientras que otro decía otra.

**20** Entonces un espíritu se acercó y se paró delante de Jehová y dijo: ‘Yo lo engañaré’. Jehová le preguntó: ‘¿Cómo lo vas a hacer?’.

**21** Él contestó: ‘Iré y me convertiré en un espíritu engañoso en boca de todos sus profetas’. Así que le dijo: ‘Lo vas a engañar; sí, te va a salir bien. Ve y hazlo’.

**22** Por eso Jehová ha puesto un espíritu engañoso en boca de estos profetas tuyos, pero en realidad Jehová ha anunciado que sufrirás una calamidad”.

**23** Sedequías hijo de Kenaaná se acercó entonces a Micaya, le dio una bofetada y le dijo: “¿Conque el espíritu de Jehová me dejó a mí para irse a hablar contigo? ¿Y por dónde fue?”.

**24** Micaya le respondió: “¡Mira! Lo sabrás el día que te metas en el cuarto más recóndito para esconderte”.

**25** Entonces el rey de Israel dijo: “Llévense a Micaya y entréguenselo a Amón, el jefe de la ciudad, y a Joás, el hijo del rey.

**26** Díganles: ‘Esto es lo que dice el rey: “Metan a este individuo en prisión y denle una ración reducida de pan y de agua hasta que yo vuelva victorioso”’”.

**27** Pero Micaya dijo: “Si vuelves victorioso, Jehová no ha hablado conmigo”. Y añadió: “Ustedes, toda la gente, tómenlo en cuenta”.

**28** De modo que el rey de Israel y Jehosafat, el rey de Judá, subieron a Ramot-Galaad.

**29** El rey de Israel le dijo a Jehosafat: “Yo me voy a disfrazar para entrar en la batalla, pero tú ponte tus ropas reales”. Así que el rey de Israel se disfrazó y entraron en la batalla.

**30** El rey de Siria les había ordenado a los comandantes de los carros: “No luchen con nadie, ni con pequeño ni con grande, solo con el rey de Israel”.

**31** En cuanto los comandantes de los carros vieron a Jehosafat, se dijeron: “Es el rey de Israel”. Así que fueron hacia él para atacarlo. Jehosafat se puso a gritar por ayuda, y Jehová lo ayudó. Dios inmediatamente hizo que se apartaran de él.

**32** Cuando los comandantes de los carros se dieron cuenta de que no era el rey de Israel, enseguida dejaron de perseguirlo.

**33** Pero un hombre disparó al azar con su arco y le dio al rey de Israel entre las uniones de su coraza. El rey le dijo al conductor de su carro: “Da la vuelta y sácame de la batalla, porque me han herido gravemente”.

**34** La batalla fue muy intensa todo aquel día. Tuvieron que sostener al rey de Israel de pie en el carro de cara a los sirios hasta el atardecer, y murió al ponerse el sol.

### Notas a pie de página
- **v. 2:** O “y convenció”.
- **v. 4:** O “la palabra de”.
- **v. 10:** O “empujarás”.
- **v. 20:** O “ángel”.
- **v. 26:** Lit. “en paz”.
- **v. 27:** Lit. “en paz”.
- **v. 33:** O “en su inocencia”.
- **v. 33:** Lit. “del campamento”.

---

## Segundo de las Crónicas 19

**1** Entonces el rey Jehosafat de Judá regresó sano y salvo a su casa en Jerusalén.

**2** Jehú hijo de Hananí, el hombre de visiones, salió al encuentro del rey Jehosafat y le dijo: “¿Crees que está bien que ayudes a los malos y ames a los que odian a Jehová? Por eso Jehová está indignado contigo.

**3** Sin embargo, se han hallado cosas buenas en ti, porque has eliminado del país los postes sagrados y has preparado tu corazón para buscar al Dios verdadero”.

**4** Jehosafat siguió viviendo en Jerusalén y de nuevo salió a visitar al pueblo, desde Beer-Seba hasta la región montañosa de Efraín, para traerlo de vuelta a Jehová, el Dios de sus antepasados.

**5** Nombró jueces por todo el país, en cada una de las ciudades fortificadas de Judá.

**6** Y les dijo a los jueces: “Miren bien lo que hacen, porque no juzgan para ningún hombre, sino para Jehová. Él está con ustedes cuando juzgan.

**7** Y ahora tengan temor de Jehová. Cuidado con lo que hacen, porque Jehová nuestro Dios no tolera injusticias, ni parcialidad, ni que se acepten sobornos”.

**8** También en Jerusalén, Jehosafat seleccionó a algunos de los levitas y sacerdotes y a algunos de los jefes de las casas paternas de Israel para servir como jueces para Jehová y resolver los casos legales de los habitantes de Jerusalén.

**9** Y les ordenó: “Esto es lo que deben hacer, con temor de Jehová, con fidelidad y con un corazón completo:

**10** cuando sus hermanos, los que viven en otras ciudades, les presenten un caso legal que tenga que ver con derramamiento de sangre o una cuestión sobre alguna ley, algún mandamiento, sobre normas o decisiones judiciales, ustedes deben advertirles para que ellos no lleguen a ser culpables ante Jehová; de lo contrario, él se indignará con ustedes y con sus hermanos. Esto es lo que ustedes deben hacer para no acabar siendo culpables.

**11** Aquí está el sacerdote principal Amarías, que será el encargado de ustedes en todos los asuntos relacionados con Jehová. Zebadías hijo de Ismael será el líder de la casa de Judá en todos los asuntos relacionados con el rey. Y los levitas les servirán a ustedes de funcionarios. Sean fuertes y pónganse a trabajar, y que Jehová esté con los que hacen lo que está bien”.

### Notas a pie de página
- **v. 1:** O “regresó en paz”.
- **v. 1:** O “palacio”.
- **v. 3:** O “tu corazón está resuelto a”.
- **v. 9:** O “completamente dedicado”.
- **v. 11:** O “con lo que es bueno”.

---

## Segundo de las Crónicas 20

**1** Después, los moabitas y los ammonitas, junto con algunos ammonim, vinieron a luchar contra Jehosafat.

**2** Así que se le informó a Jehosafat: “Una gran multitud ha venido contra ti desde la región del mar, desde Edom, y allí están en Hazazón-Tamar, es decir, En-Guedí”.

**3** Ante eso, a Jehosafat le dio miedo y se resolvió a buscar a Jehová. De modo que ordenó un ayuno para todo Judá.

**4** La gente de Judá entonces se reunió para consultar a Jehová; vinieron de todas las ciudades de Judá para consultar a Jehová.

**5** Entonces Jehosafat se puso de pie en medio de la congregación de Judá y Jerusalén en la casa de Jehová, delante del patio nuevo,

**6** y dijo: “Oh, Jehová, Dios de nuestros antepasados, ¿no eres tú Dios en los cielos? ¿No tienes dominio sobre todos los reinos de las naciones? En tus manos hay fuerza y poder, y nadie puede contra ti.

**7** Oh, nuestro Dios, ¿verdad que expulsaste delante de tu pueblo Israel a los habitantes de esta tierra y entonces se la diste de forma permanente a la descendencia de tu amigo Abrahán?

**8** Y ellos se establecieron en ella y te construyeron allí un santuario para tu nombre. Decían:

**9** ‘Si nos ocurre una calamidad —sea por la espada, un juicio desfavorable, una epidemia o hambre—, nos pondremos de pie ante esta casa y ante ti (porque tu nombre está en esta casa) y angustiados acudiremos a ti por ayuda, y tú nos escucharás y nos salvarás’.

**10** Ahora están aquí los hombres de Ammón, Moab y la región montañosa de Seír. Cuando Israel salió de la tierra de Egipto, tú no permitiste que invadiera el territorio de ellos; se apartó y no los destruyó.

**11** Y ahora nos lo pagan viniendo aquí a sacarnos de tu propiedad, que tú nos diste como herencia.

**12** Oh, Dios nuestro, ¿no los vas a castigar? Porque nosotros no podemos contra esta gran multitud que viene a atacarnos, y no sabemos qué hacer, pero nuestros ojos miran hacia ti”.

**13** Mientras tanto, todos los de Judá estaban de pie delante de Jehová, junto con sus esposas y sus hijos, incluso los pequeñitos.

**14** Entonces, en medio de la congregación, Jahaziel —hijo de Zacarías, hijo de Benaya, hijo de Jeiel, hijo de Matanías el levita de los hijos de Asaf— recibió el espíritu de Jehová.

**15** Él dijo: “¡Presten atención, todo Judá, habitantes de Jerusalén y tú, rey Jehosafat! Esto es lo que Jehová les dice: ‘No tengan miedo ni se aterroricen por esta gran multitud, porque la batalla no es de ustedes, sino de Dios.

**16** Mañana bajen a enfrentarse a ellos. Estarán subiendo por el paso de Ziz, y ustedes se los encontrarán al final del valle, frente al desierto de Jeruel.

**17** Ustedes no tendrán que pelear esta batalla. Ocupen sus puestos, estense quietos y vean cómo los salva Jehová. Gente de Judá y Jerusalén, no tengan miedo ni se aterroricen. Mañana salgan y enfréntense a ellos, que Jehová estará con ustedes’”.

**18** Al instante, Jehosafat se inclinó rostro a tierra, y todo Judá y los habitantes de Jerusalén cayeron ante Jehová para adorar a Jehová.

**19** Entonces los levitas que eran descendientes de los cohatitas y de los coreítas se levantaron para alabar a voz en cuello a Jehová, el Dios de Israel.

**20** A la mañana siguiente, se levantaron temprano y salieron al desierto de Tecoa. Mientras salían, Jehosafat se puso de pie y dijo: “¡Escúchenme, oh, Judá y habitantes de Jerusalén! Tengan fe en Jehová su Dios para que puedan mantenerse firmes. Tengan fe en los profetas de él, y les irá bien”.

**21** Después de consultarlo con la gente, seleccionó hombres para que le cantaran a Jehová y lo alabaran con adorno santo yendo delante de los hombres armados y diciendo: “Denle gracias a Jehová, porque su amor leal dura para siempre”.

**22** Cuando empezaron a cantar alabanzas con alegría, Jehová les tendió una emboscada a los hombres de Ammón, Moab y la región montañosa de Seír que estaban invadiendo Judá, y se mataron unos a otros.

**23** Los ammonitas y los moabitas se volvieron en contra de los habitantes de la región montañosa de Seír para destruirlos y exterminarlos; y, cuando acabaron con los habitantes de Seír, se mataron unos a otros.

**24** Cuando los de Judá llegaron a la torre de vigilancia del desierto y miraron hacia la multitud, vieron sus cadáveres tirados en el suelo; no había sobrevivientes.

**25** Entonces Jehosafat y su gente fueron a llevarse el botín. Encontraron muchos bienes, ropa y objetos valiosos entre los cadáveres, y se pusieron a quitárselos hasta que ya no pudieron cargar con más. El botín era tan grande que les tomó tres días llevárselo.

**26** Al cuarto día se reunieron en el valle de Beracá, donde alabaron a Jehová. Por eso llamaron a aquel lugar el valle de Beracá, como se le llama hasta el día de hoy.

**27** Entonces todos los hombres de Judá y de Jerusalén, con Jehosafat al frente de ellos, regresaron muy contentos a Jerusalén, porque Jehová los llenó de alegría con la victoria sobre sus enemigos.

**28** Llegaron a Jerusalén con instrumentos de cuerda, arpas y trompetas, y fueron a la casa de Jehová.

**29** Cuando todos los reinos de los países oyeron que Jehová había peleado contra los enemigos de Israel, el miedo de Dios se apoderó de ellos.

**30** Así, el reino de Jehosafat tuvo paz, y su Dios continuó dándole paz en todos lados.

**31** Y Jehosafat siguió reinando sobre Judá. Tenía 35 años cuando se convirtió en rey, y reinó 25 años en Jerusalén. Su madre se llamaba Azubá hija de Silhí.

**32** Él siguió los pasos de su padre Asá; no se desvió de ellos. Hizo lo que estaba bien a los ojos de Jehová.

**33** Sin embargo, no se quitaron los lugares altos, y el pueblo todavía no había preparado su corazón para el Dios de sus antepasados.

**34** En cuanto al resto de la historia de Jehosafat, está escrito de principio a fin entre las palabras de Jehú hijo de Hananí, que fueron incluidas en el Libro de los Reyes de Israel.

**35** Después de esto, el rey Jehosafat de Judá hizo una alianza con el rey Ocozías de Israel, quien actuaba muy mal.

**36** Lo convirtió en su socio para hacer barcos que fueran a Tarsis, y construyeron los barcos en Ezión-Guéber.

**37** Sin embargo, Eliezer hijo de Dodavahu de Maresá profetizó esto contra Jehosafat: “Por haber hecho una alianza con Ocozías, Jehová destruirá tus obras”. Así que los barcos se destrozaron y no pudieron ir a Tarsis.

### Notas a pie de página
- **v. 1:** O quizás “meunitas”.
- **v. 2:** Al parecer, el mar Muerto.
- **v. 3:** Lit. “dirigió su rostro”.
- **v. 16:** O “wadi”.
- **v. 17:** O “rescata”.
- **v. 20:** O “aguantar”.
- **v. 26:** O “la llanura baja”.
- **v. 26:** Lit. “bendijeron”.
- **v. 26:** Que significa ‘bendición’.
- **v. 30:** Lit. “descanso”.

---

## Segundo de las Crónicas 21

**1** Entonces Jehosafat descansó con sus antepasados y fue enterrado con sus antepasados en la Ciudad de David; y su hijo Jehoram se convirtió en el nuevo rey.

**2** Sus hermanos —los hijos de Jehosafat— eran Azarías, Jehiel, Zacarías, Azarías, Miguel y Sefatías; todos ellos eran los hijos del rey Jehosafat de Israel.

**3** Y su padre les había dado muchos regalos de plata y oro, así como cosas valiosas y ciudades fortificadas en Judá; pero el reino se lo dio a Jehoram, pues él era el primogénito.

**4** Una vez que Jehoram tomó el control del reino de su padre, consolidó su posición matando a espada a todos sus hermanos y también a algunos de los príncipes de Israel.

**5** Jehoram tenía 32 años cuando llegó a ser rey, y reinó ocho años en Jerusalén.

**6** Siguió los pasos de los reyes de Israel, tal como lo habían hecho los de la casa de Acab, pues la hija de Acab había llegado a ser su esposa. Y él hacía lo que estaba mal a los ojos de Jehová.

**7** Pero Jehová no quiso destruir a los de la casa de David por el pacto que había hecho con David, pues había prometido que les daría una lámpara a él y a sus hijos para siempre.

**8** En los días de Jehoram, Edom se rebeló contra Judá y entonces proclamó su propio rey.

**9** Así que Jehoram cruzó hacia allá con sus comandantes y con todos sus carros. Se levantó de noche y venció a los edomitas que lo habían cercado a él y a los comandantes de los carros.

**10** Pero la rebelión de Edom contra Judá ha seguido hasta el día de hoy. Libná también se rebeló contra él en aquel tiempo porque él había abandonado a Jehová, el Dios de sus antepasados.

**11** Él también había hecho lugares altos en las montañas de Judá para hacer que los habitantes de Jerusalén se prostituyeran espiritualmente, y descarrió a Judá.

**12** Al final le llegó un mensaje por escrito del profeta Elías, que decía: “Esto es lo que dice Jehová, el Dios de tu antepasado David: ‘Tú no has seguido los pasos de tu padre Jehosafat ni los del rey Asá de Judá.

**13** Más bien, sigues los pasos de los reyes de Israel y haces que Judá y los habitantes de Jerusalén se prostituyan espiritualmente, tal como se prostituyeron los de la casa de Acab. Hasta mataste a tus propios hermanos, a los de la casa de tu padre, que eran mejores que tú.

**14** Por lo tanto, Jehová lanzará un gran golpe contra tu pueblo, tus hijos, tus esposas y contra todos tus bienes.

**15** Y sufrirás muchas enfermedades, incluida una enfermedad de los intestinos, que empeorará cada día, hasta que los intestinos se te salgan por culpa de esa enfermedad’”.

**16** Entonces Jehová hizo que los filisteos y los árabes que estaban cerca de los etíopes se pusieran en contra de Jehoram.

**17** Así que entraron por la fuerza e invadieron Judá. Se llevaron todos los bienes que encontraron en la casa del rey, así como a sus hijos y sus esposas; el único hijo que le quedó fue Jehoacaz, su hijo menor.

**18** Y, después de todo esto, Jehová hizo que Jehoram sufriera una enfermedad incurable en los intestinos.

**19** Algún tiempo después, al cabo de dos años completos, los intestinos se le salieron debido a su enfermedad, y murió sufriendo muchísimo por culpa de esa enfermedad. Y su pueblo no le hizo una hoguera, como sí se había hecho por sus antepasados.

**20** Tenía 32 años cuando llegó a ser rey, y reinó ocho años en Jerusalén. Cuando murió, nadie lo lamentó. Lo enterraron en la Ciudad de David, pero no en las sepulturas de los reyes.

### Notas a pie de página
- **v. 16:** Lit. “el espíritu de los filisteos”.
- **v. 17:** O “el palacio”.
- **v. 17:** También llamado Ocozías.

---

## Segundo de las Crónicas 22

**1** Entonces los habitantes de Jerusalén hicieron que Ocozías, el hijo menor de Jehoram, fuera rey en su lugar, porque la banda de saqueadores que vino al campamento con los árabes había matado a todos los hijos mayores. Así que Ocozías hijo de Jehoram empezó a reinar como rey de Judá.

**2** Ocozías tenía 22 años cuando se convirtió en rey, y reinó un año en Jerusalén. Su madre era Atalía, la nieta de Omrí.

**3** Él también siguió los pasos de los de la casa de Acab, pues su madre le aconsejaba que hiciera cosas malas.

**4** Hacía lo que estaba mal a los ojos de Jehová, como los de la casa de Acab, porque ellos llegaron a ser sus consejeros después de la muerte de su padre, y eso lo llevó a la ruina.

**5** Por seguir sus consejos, él fue con Jehoram hijo del rey Acab de Israel a luchar contra el rey Hazael de Siria en Ramot-Galaad, donde los arqueros hirieron a Jehoram.

**6** Jehoram volvió a Jezreel para recuperarse de las heridas que le habían causado en Ramá cuando peleó contra el rey Hazael de Siria. Como Jehoram hijo de Acab estaba herido, Ocozías hijo de Jehoram, el rey de Judá, bajó a Jezreel para verlo.

**7** Pero, mediante esa visita a Jehoram, Dios causó el hundimiento de Ocozías. Cuando llegó allí, salió con Jehoram para encontrarse con Jehú, el nieto de Nimsí, a quien Jehová había ungido para acabar con la casa de Acab.

**8** Cuando Jehú empezó a ejecutar la sentencia contra la casa de Acab, encontró a los príncipes de Judá y a los hijos de los hermanos de Ocozías, siervos de Ocozías, y los mató.

**9** Después buscó a Ocozías. Lo capturaron en Samaria, donde estaba escondido, se lo trajeron a Jehú y lo mataron. Luego lo enterraron, pues dijeron: “Es el nieto de Jehosafat, quien buscó a Jehová con todo su corazón”. No había nadie de la casa de Ocozías que pudiera gobernar el reino.

**10** Cuando Atalía, la madre de Ocozías, vio que su hijo había muerto, exterminó todo el linaje real de la casa de Judá.

**11** Sin embargo, Jehosabeat, la hija del rey, se llevó a escondidas a Jehoás hijo de Ocozías y lo apartó de los demás hijos del rey a quienes iban a matar. Lo metió a él con su nodriza en un dormitorio. Jehosabeat hija del rey Jehoram (ella era la esposa del sacerdote Jehoiadá y hermana de Ocozías) logró mantenerlo escondido de Atalía y así evitó que lo matara.

**12** Él se quedó escondido con ellos en la casa del Dios verdadero por seis años, mientras Atalía reinaba sobre el país.

### Notas a pie de página
- **v. 2:** Lit. “hija”.
- **v. 6:** O “enfermo”.
- **v. 6:** En algunos manuscritos hebreos, “Azarías”.
- **v. 7:** Lit. “hijo”.
- **v. 8:** O “ministros”.
- **v. 10:** Lit. “toda descendencia del reino”.

---

## Segundo de las Crónicas 23

**1** Al séptimo año, Jehoiadá actuó con valor e hizo un pacto con los jefes de cien, es decir, con Azarías hijo de Jeroham, Ismael hijo de Jehohanán, Azarías hijo de Obed, Maaseya hijo de Adaya y Elisafat hijo de Zicrí.

**2** Después recorrieron todo Judá y reunieron a los levitas de todas las ciudades de Judá y a los jefes de las casas paternas de Israel. Cuando llegaron a Jerusalén,

**3** toda la congregación hizo un pacto con el rey en la casa del Dios verdadero. Después de eso, Jehoiadá les dijo: “¡Miren! El hijo del rey reinará, de acuerdo con la promesa de Jehová sobre los hijos de David.

**4** Esto es lo que ustedes harán: una tercera parte de los sacerdotes y de los levitas que estén de servicio el sábado serán porteros;

**5** otra tercera parte estará en la casa del rey, y la otra tercera parte estará en la Puerta del Fundamento, y todo el pueblo estará en los patios de la casa de Jehová.

**6** No dejen entrar a nadie en la casa de Jehová excepto a los sacerdotes y los levitas que estén prestando servicio. Ellos podrán entrar porque son un grupo santo, y todo el pueblo cumplirá su obligación con Jehová.

**7** Los levitas rodearán al rey por todos lados, cada uno con sus armas en la mano. Cualquier persona que entre en la casa tendrá que morir. Estén con el rey dondequiera que vaya”.

**8** Los levitas y todo Judá hicieron exactamente lo que les había mandado el sacerdote Jehoiadá. Cada uno reunió a sus hombres, a los que estaban de servicio el sábado y también a los que estaban libres el sábado, pues el sacerdote Jehoiadá no les había dado permiso a las divisiones para dejar sus puestos.

**9** El sacerdote Jehoiadá entonces les dio a los jefes de cien las lanzas, los escudos pequeños y los escudos circulares que habían sido del rey David y que estaban en la casa del Dios verdadero.

**10** Y colocó a toda la gente, cada cual con su arma en la mano, desde el lado derecho de la casa hasta el lado izquierdo, junto al altar y junto a la casa, rodeando completamente al rey.

**11** Entonces sacaron al hijo del rey y pusieron la corona y el Testimonio sobre él. Lo hicieron rey, y Jehoiadá y sus hijos lo ungieron. Luego dijeron: “¡Viva el rey!”.

**12** Cuando Atalía oyó gente corriendo y alabando al rey, enseguida fue hacia la gente que estaba en la casa de Jehová.

**13** Entonces vio allí al rey de pie junto a su columna en la entrada. Los príncipes y los trompetistas estaban con el rey, toda la gente del país estaba muy contenta, y tocaban las trompetas. Y los cantores con instrumentos musicales estaban dirigiendo las alabanzas. Al instante, Atalía se rasgó la ropa y gritó: “¡Conspiración! ¡Conspiración!”.

**14** Pero el sacerdote Jehoiadá hizo salir a los jefes de cien, los que estaban al mando del ejército, y les dijo: “¡Sáquenla de las filas y, si alguien la sigue, mátenlo a espada!”. Y es que el sacerdote había dicho “No la maten en la casa de Jehová”.

**15** Así que la agarraron y, en cuanto llegaron a la entrada de la Puerta de los Caballos de la casa del rey, la mataron allí.

**16** Luego Jehoiadá hizo un pacto entre él y todo el pueblo y el rey; en él se comprometían a seguir siendo el pueblo de Jehová.

**17** Después de eso, toda la gente fue al templo de Baal y lo derribaron, hicieron pedazos sus altares y sus imágenes, y enfrente de los altares ejecutaron a Matán, el sacerdote de Baal.

**18** Entonces Jehoiadá les dio la tarea de supervisar la casa de Jehová a los sacerdotes y los levitas, a quienes David había organizado en divisiones para servir en la casa de Jehová ofreciendo los sacrificios quemados de Jehová de acuerdo con lo que está escrito en la Ley de Moisés, con alegría y con canciones, como mandó David.

**19** También colocó a los porteros junto a las puertas de la casa de Jehová para que no pudiera entrar nadie que de algún modo estuviera impuro.

**20** Después reunió a los jefes de cien, a los nobles, a los gobernantes del pueblo y a toda la gente del país; escoltó al rey y bajó con él desde la casa de Jehová. Entonces pasaron por la puerta superior hacia la casa del rey y sentaron al rey en el trono del reino.

**21** Toda la gente del país se alegró mucho y la ciudad quedó en paz, pues habían matado a espada a Atalía.

### Notas a pie de página
- **v. 5:** O “el palacio”.
- **v. 7:** Lit. “cuando salga y cuando entre”.
- **v. 9:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 10:** O “proyectil”.
- **v. 11:** O “diadema”.
- **v. 11:** Posiblemente un rollo que contenía la Ley de Dios.
- **v. 13:** O “dando la señal para”.
- **v. 18:** Lit. “por las manos de”.

---

## Segundo de las Crónicas 24

**1** Jehoás tenía siete años cuando se convirtió en rey, y reinó 40 años en Jerusalén. Su madre se llamaba Zibíah de Beer-Seba.

**2** Jehoás hizo lo que estaba bien a los ojos de Jehová durante todos los días del sacerdote Jehoiadá.

**3** Jehoiadá le consiguió dos esposas, y él llegó a ser padre de hijos e hijas.

**4** Tiempo después, Jehoás deseó en su corazón renovar la casa de Jehová.

**5** De manera que reunió a los sacerdotes y los levitas, y les dijo: “Salgan a las ciudades de Judá y junten dinero de todo Israel para reparar la casa de su Dios cada año; y háganlo rápido”. Pero los levitas no se dieron prisa.

**6** Así que el rey llamó al sacerdote principal Jehoiadá y le dijo: “¿Por qué no has hecho que los levitas traigan de Judá y Jerusalén el impuesto sagrado que ordenó Moisés, el siervo de Jehová, el impuesto sagrado de la congregación de Israel para la tienda del Testimonio?

**7** Los hijos de Atalía, esa mujer perversa, se metieron por la fuerza en la casa del Dios verdadero y usaron todas las cosas santas de la casa de Jehová para los Baales”.

**8** Entonces, por orden del rey, hicieron un cofre y lo pusieron por fuera de la puerta de la casa de Jehová.

**9** Después de eso, anunciaron por todo Judá y Jerusalén que había que traerle a Jehová el impuesto sagrado que Moisés —el siervo del Dios verdadero— había establecido para Israel en el desierto.

**10** Todo el pueblo y todos los príncipes se alegraron. Traían contribuciones y las echaban en el cofre hasta llenarlo.

**11** Cuando los levitas traían el cofre para entregárselo al rey y veían que había una gran cantidad de dinero dentro, el secretario del rey y el ayudante del sacerdote principal venían, vaciaban el cofre y lo volvían a poner en su lugar. Esto es lo que hacían todos los días, y así reunieron muchísimo dinero.

**12** El rey y Jehoiadá entonces se lo daban a los que supervisaban el trabajo relacionado con el servicio de la casa de Jehová, y ellos contrataban a los picapedreros y artesanos para renovar la casa de Jehová, y también a los que trabajaban con hierro y cobre para reparar la casa de Jehová.

**13** Los que supervisaban el trabajo comenzaron con las obras, y la reparación siguió avanzando bajo la supervisión de ellos. Devolvieron la casa del Dios verdadero a su estado original y la reforzaron.

**14** En cuanto terminaron, les trajeron al rey y a Jehoiadá el dinero que quedaba, y lo usaron para hacer utensilios para la casa de Jehová: utensilios para el servicio y para hacer ofrendas, además de copas y utensilios de oro y plata. Durante todos los días de Jehoiadá, se ofrecieron sacrificios quemados de forma regular en la casa de Jehová.

**15** Satisfecho tras una larga vida, Jehoiadá murió: tenía 130 años al morir.

**16** Así que lo enterraron en la Ciudad de David junto con los reyes, porque había hecho el bien en Israel en lo relacionado con el Dios verdadero y su casa.

**17** Después de la muerte de Jehoiadá, los príncipes de Judá vinieron y se inclinaron ante el rey, y el rey los escuchó.

**18** Abandonaron la casa de Jehová, el Dios de sus antepasados, y se pusieron a servir a los postes sagrados y los ídolos, y con su pecado provocaron la ira de Dios contra Judá y Jerusalén.

**19** Él no dejaba de enviarles profetas para traerlos de vuelta a Jehová. Estos les daban advertencias, pero ellos se negaban a escuchar.

**20** El espíritu de Dios vino sobre Zacarías hijo de Jehoiadá el sacerdote. Él se puso de pie en un lugar más alto que el pueblo y les dijo: “Esto es lo que ha dicho el Dios verdadero: ‘¿Por qué desobedecen los mandamientos de Jehová? ¡Así no conseguirán nada! Ustedes han dejado a Jehová, y por eso él los dejará a ustedes’”.

**21** Pero conspiraron contra él y, por orden del rey, lo apedrearon en el patio de la casa de Jehová.

**22** El rey Jehoás no se acordó del amor leal que había recibido de Jehoiadá, el padre de él, sino que mató a su hijo, quien murió diciendo: “Que Jehová lo vea y te pida cuentas”.

**23** A principios de año, el ejército sirio subió a atacar a Jehoás. Invadieron Judá y Jerusalén, y luego acabaron con todos los príncipes del pueblo y le enviaron todo el botín al rey de Damasco.

**24** Aunque el ejército sirio que los invadió contaba con pocos hombres, Jehová entregó en sus manos un ejército muy grande, pues el pueblo había dejado a Jehová, el Dios de sus antepasados; así ellos ejecutaron la sentencia contra Jehoás.

**25** Cuando se retiraron, dejándolo gravemente herido, sus propios siervos conspiraron contra él porque había derramado la sangre de los hijos del sacerdote Jehoiadá. Lo mataron en su propia cama. Así que murió y lo enterraron en la Ciudad de David, pero no en las sepulturas de los reyes.

**26** Estos fueron los que conspiraron contra él: Zabad hijo de Simeat la ammonita y Jehozabad hijo de Simrit la moabita.

**27** Todo lo relacionado con sus hijos, con las muchas declaraciones hechas contra él y con la renovación de la casa del Dios verdadero está registrado en los escritos del Libro de los Reyes. Y su hijo Amasías se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 10:** O quizás “hasta que todos hubieron dado”.
- **v. 15:** Lit. “Viejo y lleno de días”.
- **v. 19:** O “daban testimonio contra ellos”.
- **v. 20:** Lit. “revistió a”.
- **v. 22:** Es decir, el padre de Zacarías.
- **v. 23:** Lit. “A la vuelta del año”.
- **v. 24:** Es decir, los sirios.
- **v. 25:** O “con muchas enfermedades”.
- **v. 25:** O “del hijo”. Posiblemente el plural indica excelencia.
- **v. 27:** Lit. “fundación”.
- **v. 27:** O “la exposición”, “el comentario”.

---

## Segundo de las Crónicas 25

**1** Amasías tenía 25 años cuando se convirtió en rey, y reinó 29 años en Jerusalén. Su madre se llamaba Jehoadán de Jerusalén.

**2** Él hacía lo que estaba bien a los ojos de Jehová, pero no con un corazón completo.

**3** En cuanto tuvo el reino completamente bajo su control, mató a los siervos suyos que habían asesinado a su padre el rey.

**4** Pero no mató a los hijos de ellos, porque actuó de acuerdo con lo que está escrito en la Ley, en el libro de Moisés, donde Jehová mandó: “Los padres no deben morir por culpa de sus hijos ni los hijos por culpa de sus padres. Cada uno debe morir por su propio pecado”.

**5** Y Amasías reunió a los de Judá e hizo que se colocaran según sus casas paternas, según los jefes de mil y los jefes de cien por todo Judá y Benjamín. Registró a los mayores de 20 años y vio que había 300.000 guerreros adiestrados para servir en el ejército, que sabían usar la lanza y el escudo grande.

**6** Además, contrató 100.000 guerreros poderosos de Israel por 100 talentos de plata.

**7** Pero un hombre del Dios verdadero vino a decirle: “Oh, rey, no dejes que el ejército de Israel vaya contigo, porque Jehová no está con Israel, no está con ninguno de los efraimitas.

**8** Ve tú solo, actúa y sé valiente en la batalla. Porque, si no lo haces, el Dios verdadero puede hacerte caer ante el enemigo, pues Dios tiene poder para ayudar y para hacer caer”.

**9** Ante eso, Amasías le dijo al hombre del Dios verdadero: “Pero ¿y qué pasa con los 100 talentos que les he dado a los soldados de Israel?”. El hombre del Dios verdadero contestó: “Jehová puede darte mucho más que eso”.

**10** Así que Amasías despidió a los soldados que habían venido desde Efraín y los mandó a su casa. Sin embargo, ellos se enojaron mucho con Judá y regresaron a su casa muy furiosos.

**11** Entonces Amasías se armó de valor, dirigió su ejército al valle de la Sal y acabó con 10.000 hombres de Seír.

**12** Y los hombres de Judá capturaron vivos a 10.000. Los llevaron a la cima del peñasco y los arrojaron desde allí; todos se hicieron pedazos.

**13** Pero los miembros de la tropa a quienes Amasías había hecho volver para que no fueran con él a la guerra empezaron a lanzar ataques a las ciudades de Judá, desde Samaria hasta Bet-Horón; mataron a 3.000 personas y se llevaron un gran botín.

**14** Cuando Amasías regresó de derrotar a los edomitas, se trajo consigo los dioses de los hombres de Seír y los puso como sus propios dioses. Empezó a inclinarse ante ellos y a hacerles humo de sacrificio.

**15** Por eso Jehová se enojó mucho con Amasías y le envió un profeta que le dijo: “¿Por qué sigues a los dioses de ese pueblo, esos dioses que no salvaron a su propia gente de tus manos?”.

**16** Mientras le estaba hablando, el rey le dijo: “¿Acaso te nombramos consejero del rey? ¡Para de hablar! ¿O quieres que te maten?”. Entonces el profeta paró, pero antes dijo: “Sé que Dios ha decidido acabar contigo, porque has hecho esto y no has escuchado mi consejo”.

**17** Después de consultarlo con sus consejeros, el rey Amasías de Judá le envió a Jehoás —hijo de Jehoacaz, hijo de Jehú—, el rey de Israel, este mensaje: “¡Ven! Enfréntate a mí en una batalla”.

**18** El rey Jehoás de Israel mandó a decirle al rey Amasías de Judá: “El yerbajo espinoso del Líbano le envió este mensaje al cedro del Líbano: ‘Dale tu hija a mi hijo como esposa’. Pero vino un animal salvaje del Líbano y pisoteó al yerbajo espinoso.

**19** Tú has dicho: ‘¡Mira! Yo derroté a Edom’. Por eso tu corazón se ha vuelto arrogante y quiere recibir gloria. Pero ahora quédate en tu casa. ¿Para qué vas a provocar una desgracia y arrastrar a Judá contigo cuando caigas?”.

**20** Pero Amasías no hizo caso, pues esa era la voluntad del Dios verdadero, quien quiso entregarlos en manos del enemigo por haber seguido a los dioses de Edom.

**21** Así que el rey Jehoás de Israel subió, y él y el rey Amasías de Judá se enfrentaron en una batalla en Bet-Semes, que pertenece a Judá.

**22** Israel derrotó a Judá, de manera que todos huyeron, cada uno a su hogar.

**23** El rey Jehoás de Israel capturó en Bet-Semes al rey Amasías de Judá, hijo de Jehoás, hijo de Jehoacaz. Después lo trajo a Jerusalén, y derrumbó parte de la muralla de Jerusalén, desde la Puerta de Efraín hasta la Puerta de la Esquina. La brecha medía 400 codos.

**24** Se llevó todo el oro, la plata y todos los objetos que estaban en la casa del Dios verdadero con Obed-Edom y en las cámaras del tesoro de la casa del rey, así como rehenes. Luego volvió a Samaria.

**25** Amasías hijo de Jehoás, el rey de Judá, vivió otros 15 años después de la muerte de Jehoás hijo de Jehoacaz, el rey de Israel.

**26** En cuanto al resto de la historia de Amasías, está escrito de principio a fin en el Libro de los Reyes de Judá y de Israel.

**27** Desde el momento en que Amasías dejó de seguir a Jehová, tramaron una conspiración contra él en Jerusalén, y huyó a Lakís, pero mandaron hombres tras él a Lakís, donde lo mataron.

**28** Luego lo llevaron de vuelta a caballo y lo enterraron con sus antepasados en la ciudad de Judá.

### Notas a pie de página
- **v. 5:** Lit. “escogidos”.
- **v. 6:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 17:** O “Encontrémonos cara a cara”.
- **v. 19:** Lit. “Tú heriste”.
- **v. 19:** O “palacio”.
- **v. 22:** Lit. “sus tiendas”.
- **v. 23:** También llamado Ocozías.
- **v. 23:** Unos 178 m (584 ft). Ver apén. B14.
- **v. 24:** O “al cuidado de”.

---

## Segundo de las Crónicas 26

**1** Entonces todo el pueblo de Judá hizo rey a Uzías, que tenía 16 años, para que reinara en lugar de su padre Amasías.

**2** Él reconstruyó Elot y se la devolvió a Judá después de que el rey descansó con sus antepasados.

**3** Uzías tenía 16 años cuando se convirtió en rey, y reinó 52 años en Jerusalén. Su madre se llamaba Jecolías de Jerusalén.

**4** Él hacía lo que estaba bien a los ojos de Jehová, tal como lo había hecho su padre Amasías.

**5** Buscó a Dios durante los días de Zacarías, quien le enseñó a temer al Dios verdadero. Mientras buscó a Jehová, el Dios verdadero hizo que le fuera bien.

**6** Fue a pelear contra los filisteos y logró atravesar las murallas de Gat, de Jabné y de Asdod. Después construyó ciudades en el territorio de Asdod y en el territorio de los filisteos.

**7** El Dios verdadero lo siguió ayudando en la lucha contra los filisteos, contra los árabes que vivían en Gurbaal y contra los meunim.

**8** Los ammonitas empezaron a pagarle tributo a Uzías. Él se hizo tan poderoso que su fama llegó hasta Egipto.

**9** Además, Uzías construyó torres en Jerusalén junto a la Puerta de la Esquina, junto a la Puerta del Valle y junto al Contrafuerte, y las reforzó.

**10** También construyó torres en el desierto y excavó muchas cisternas (porque tenía mucho ganado); hizo lo mismo en la Sefelá y en la llanura. Tenía agricultores y viñadores en las montañas y en el Carmelo, porque le encantaba la agricultura.

**11** Además, Uzías llegó a tener un ejército equipado para la guerra. Salían a hacer sus campañas militares organizados en divisiones. Fueron contados y registrados por el secretario Jeiel y el funcionario Maaseya, bajo el mando de Hananías, uno de los príncipes del rey.

**12** El número total de los jefes de las casas paternas que estaban al mando de estos guerreros poderosos era de 2.600.

**13** Las fuerzas armadas bajo su mando sumaban 307.500 hombres preparados para la guerra, una poderosa fuerza militar para apoyar al rey en contra del enemigo.

**14** Uzías equipó al ejército entero con escudos, lanzas, cascos, corazas, arcos y piedras de honda.

**15** Además, hizo en Jerusalén máquinas de guerra diseñadas por ingenieros; las colocaron en las torres y en las esquinas de las murallas, y podían disparar flechas y grandes piedras. Así su fama se extendió por todas partes, pues recibió ayuda extraordinaria y se hizo fuerte.

**16** Sin embargo, tan pronto como se hizo fuerte, su corazón se hizo arrogante y se buscó su propia ruina, y fue infiel a Jehová su Dios, pues entró en el templo de Jehová para quemar incienso en el altar del incienso.

**17** El sacerdote Azarías y otros 80 sacerdotes valientes de Jehová entraron inmediatamente detrás de él.

**18** Se enfrentaron al rey Uzías y le dijeron: “¡Uzías, a ti no te corresponde quemar incienso para Jehová! Solo los sacerdotes pueden quemar incienso, porque ellos son los descendientes de Aarón, los que han sido santificados. Sal del santuario; has sido infiel y no recibirás ninguna gloria de parte de Jehová Dios con esto que has hecho”.

**19** Pero Uzías, que tenía en la mano un incensario para quemar incienso, se puso furioso. Y, en pleno ataque de furia contra los sacerdotes, le salió lepra en la frente, allí, delante de los sacerdotes en la casa de Jehová al lado del altar del incienso.

**20** Cuando el sacerdote principal Azarías y todos los sacerdotes lo miraron, ¡resulta que le había salido lepra en la frente! Así que rápido lo sacaron de allí, y él mismo se apresuró a salir, porque Jehová lo había herido.

**21** El rey Uzías siguió siendo un leproso hasta el día de su muerte. Vivía como un leproso en una casa aparte, porque había sido excluido de la casa de Jehová. Su hijo Jotán estaba al mando de la casa del rey y juzgaba a la gente del país.

**22** Y el resto de la historia de Uzías lo registró de principio a fin el profeta Isaías hijo de Amoz.

**23** Entonces Uzías descansó con sus antepasados y lo enterraron con sus antepasados, pero en el campo de sepultura que pertenecía a los reyes, porque dijeron: “Es un leproso”. Y su hijo Jotán se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 2:** Es decir, su padre Amasías.
- **v. 10:** O “labró”, probablemente en la roca.
- **v. 10:** O “meseta”.
- **v. 21:** O “del palacio”.

---

## Segundo de las Crónicas 27

**1** Jotán tenía 25 años cuando se convirtió en rey, y reinó 16 años en Jerusalén. Su madre se llamaba Jerusá hija de Sadoc.

**2** Él hacía lo que estaba bien a los ojos de Jehová, tal como lo había hecho su padre Uzías. Y, a diferencia de él, no se metió en el templo de Jehová. No obstante, el pueblo seguía actuando muy mal.

**3** Jotán construyó la puerta superior de la casa de Jehová e hizo muchas obras en la muralla de Ofel.

**4** También construyó ciudades en la región montañosa de Judá, y fortalezas y torres en las zonas de bosque.

**5** Luchó contra el rey de los ammonitas y al final los derrotó. Por eso los ammonitas le dieron aquel año 100 talentos de plata, 10.000 coros de trigo y 10.000 de cebada. El segundo y el tercer año, los ammonitas le volvieron a pagar lo mismo.

**6** Así que Jotán fue haciéndose más poderoso, porque se resolvió a seguir los caminos de Jehová su Dios.

**7** En cuanto al resto de la historia de Jotán, todas sus guerras y sus acciones, está escrito en el Libro de los Reyes de Israel y de Judá.

**8** Tenía 25 años cuando se convirtió en rey, y reinó 16 años en Jerusalén.

**9** Entonces Jotán descansó con sus antepasados, y lo enterraron en la Ciudad de David. Y su hijo Acaz se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 1:** O “Jerusah”. Ver apén. A2.
- **v. 5:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 5:** Un coro equivalía a 220 L (200 dry qt). Ver apén. B14.
- **v. 6:** O “preparó sus caminos delante”.

---

## Segundo de las Crónicas 28

**1** Acaz tenía 20 años cuando se convirtió en rey, y reinó 16 años en Jerusalén. No hizo lo que estaba bien a los ojos de Jehová, como sí lo había hecho su antepasado David.

**2** En vez de eso, siguió los pasos de los reyes de Israel, y hasta hizo estatuas metálicas de los Baales.

**3** Además, hizo humo de sacrificio en el valle del Hijo de Hinón y quemó a sus hijos en el fuego, imitando las prácticas detestables de las naciones que Jehová había expulsado delante de los israelitas.

**4** Además, hacía sacrificios y humo de sacrificio en los lugares altos, en las colinas y debajo de todos los árboles frondosos.

**5** Por eso, Jehová su Dios lo entregó en manos del rey de Siria, de modo que lo vencieron y se llevaron muchos cautivos a Damasco. También fue entregado en manos del rey de Israel, quien lo derrotó con una gran matanza.

**6** En un solo día, Pécah hijo de Remalías mató en Judá a 120.000 hombres —todos ellos valientes—, y es que habían abandonado a Jehová, el Dios de sus antepasados.

**7** Y Zicrí, un guerrero efraimita, mató a Maaseya, el hijo del rey, así como a Azricam, que estaba al mando del palacio, y también a Elcaná, que era el segundo después del rey.

**8** Además, los israelitas se llevaron de entre sus hermanos a 200.000 cautivos —mujeres, hijos e hijas—; también consiguieron un enorme botín y se lo llevaron a Samaria.

**9** Pero un profeta de Jehová llamado Oded estaba allí y salió al encuentro del ejército que venía a Samaria. Les dijo: “¡Miren! Jehová, el Dios de sus antepasados, estaba furioso con Judá y por eso los entregó en manos de ustedes, y ustedes los masacraron con una furia que ha llegado hasta los cielos.

**10** Y ahora ustedes quieren convertir a la gente de Judá y Jerusalén en sus siervos y siervas. Sin embargo, ¿no son también ustedes culpables ante Jehová su Dios?

**11** Ahora escúchenme y devuelvan a los cautivos que se llevaron de entre sus hermanos, porque Jehová está muy furioso con ustedes”.

**12** Ante eso, algunos de los jefes de los efraimitas, Azarías hijo de Jehohanán, Berekías hijo de Mesilemot, Jehizquías hijo de Salum y Amasá hijo de Hadlái, se enfrentaron a los que venían llegando de la campaña militar

**13** y les dijeron: “No traigan aquí a los cautivos, porque eso nos hará culpables ante Jehová. Lo que ustedes quieren hacer aumentará nuestros pecados y nuestra culpa, pues nuestra culpa ya de por sí es grande y Dios está muy furioso con Israel”.

**14** Así que los soldados armados les entregaron tanto los cautivos como el botín a los príncipes y a toda la congregación.

**15** Entonces los hombres que habían sido escogidos por nombre tomaron a los cautivos y sacaron ropa del botín para dársela a todos los que estaban desnudos. De modo que los vistieron, les proporcionaron sandalias, les dieron de comer y de beber y también aceite para la piel. Además, montaron a los débiles en burros y se los llevaron a sus hermanos en Jericó, la ciudad de las palmeras. Luego volvieron a Samaria.

**16** En aquel tiempo el rey Acaz les pidió ayuda a los reyes de Asiria.

**17** Los edomitas de nuevo invadieron y atacaron Judá y se llevaron cautivos.

**18** Los filisteos también atacaron las ciudades de la Sefelá y del Négueb de Judá, y conquistaron Bet-Semes, Ayalón, Guederot, Socó y sus pueblos dependientes, Timná y sus pueblos dependientes, y Guimzó y sus pueblos dependientes; y se establecieron allí.

**19** Jehová humilló a Judá por culpa del rey Acaz de Israel, porque había dejado que Judá se saliera de control, y eso resultó en que hubiera mucha infidelidad hacia Jehová.

**20** Y el rey Tilgat-Pilnéser de Asiria, en vez de ayudarlo, terminó atacándolo y causándole angustia.

**21** Acaz había vaciado la casa de Jehová, la casa del rey y las casas de los príncipes para darle un regalo al rey de Asiria; pero eso no le sirvió de nada.

**22** Y, durante su angustia, el rey Acaz le fue todavía más infiel a Jehová.

**23** Se puso a hacerles sacrificios a los dioses de Damasco que lo habían derrotado. Decía: “Como los dioses de los reyes de Siria les están ayudando, yo les haré sacrificios para que me ayuden a mí”. Pero ellos hicieron que él y todo Israel cayeran en la ruina.

**24** Además, Acaz juntó los utensilios de la casa del Dios verdadero; luego hizo pedazos los utensilios de la casa del Dios verdadero, cerró las puertas de la casa de Jehová y se hizo altares en cada rincón de Jerusalén.

**25** Y en todas las ciudades de Judá hizo lugares altos para hacerles humo de sacrificio a otros dioses, y provocó a Jehová, el Dios de sus antepasados.

**26** En cuanto al resto de su historia, todas las cosas que hizo, ahí está escrito de principio a fin en el Libro de los Reyes de Judá y de Israel.

**27** Entonces Acaz descansó con sus antepasados y lo enterraron en la ciudad, en Jerusalén, pero no lo pusieron en las sepulturas de los reyes de Israel. Y su hijo Ezequías se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 2:** O “de metal fundido”.
- **v. 3:** Ver glosario, Gehena.
- **v. 7:** Lit. “de la casa”.
- **v. 18:** O “cercanos”.
- **v. 18:** O “Timnah”. Ver apén. A2.
- **v. 21:** O “el palacio”.

---

## Segundo de las Crónicas 29

**1** Ezequías se convirtió en rey a los 25 años de edad, y reinó 29 años en Jerusalén. Su madre se llamaba Abías hija de Zacarías.

**2** Él hacía lo que estaba bien a los ojos de Jehová, tal como lo había hecho su antepasado David.

**3** El primer año de su reinado, en el primer mes, abrió las puertas de la casa de Jehová y las reparó.

**4** Luego trajo a los sacerdotes y a los levitas, y los reunió en la plaza que estaba al este.

**5** Les dijo: “Escúchenme, levitas. Ahora santifíquense y santifiquen la casa de Jehová, el Dios de sus antepasados, y quiten del lugar santo lo que es impuro.

**6** Porque nuestros padres fueron infieles e hicieron lo que estaba mal a los ojos de Jehová nuestro Dios. Lo abandonaron, apartaron la vista del tabernáculo de Jehová y a él le dieron la espalda.

**7** También cerraron las puertas del pórtico y apagaron las lámparas. Dejaron de quemar incienso y de ofrecerle sacrificios quemados al Dios de Israel en el lugar santo.

**8** Así que Jehová se indignó con Judá y Jerusalén, de modo que los convirtió en motivo de horror, asombro y silbidos, como ustedes pueden comprobar con sus propios ojos.

**9** Por eso nuestros antepasados murieron a espada, y nuestros hijos, hijas y esposas estuvieron cautivos.

**10** Ahora el deseo de mi corazón es hacer un pacto con Jehová, el Dios de Israel, para que deje de estar furioso con nosotros.

**11** Hijos míos, ahora no es momento de ser negligentes, porque Jehová los escogió para estar de pie delante de él, para servirle y para hacer humear sus sacrificios”.

**12** Ante eso, los levitas pusieron manos a la obra. De los cohatitas: Máhat hijo de Amasái y Joel hijo de Azarías; de los meraritas: Quis hijo de Abdí y Azarías hijo de Jehalelel; de los guersonitas: Joá hijo de Zimá y Edén hijo de Joá;

**13** de los hijos de Elizafán: Simrí y Jeuel; de los hijos de Asaf: Zacarías y Matanías;

**14** de los hijos de Hemán: Jehiel y Simeí; de los hijos de Jedutún: Semaya y Uziel.

**15** Reunieron a sus hermanos, se santificaron y, tal como había mandado el rey de acuerdo con las palabras de Jehová, vinieron a purificar la casa de Jehová.

**16** Entonces los sacerdotes entraron en la casa de Jehová para purificarla, sacaron todas las cosas impuras que encontraron en el templo de Jehová y las llevaron al patio de la casa de Jehová. A su vez, los levitas las sacaron de allí y las llevaron al valle de Cedrón.

**17** Así comenzaron la santificación el primer día del primer mes, y el día ocho del mes llegaron al pórtico de Jehová. Santificaron la casa de Jehová durante ocho días, y terminaron el día 16 del primer mes.

**18** Después entraron adonde estaba el rey Ezequías y le dijeron: “Hemos purificado toda la casa de Jehová, el altar de la ofrenda quemada y todos sus utensilios, y la mesa de los panes apilados y todos sus utensilios.

**19** Y hemos preparado y santificado todos los utensilios que el rey Acaz quitó durante su reinado, cuando fue infiel; ahora están delante del altar de Jehová”.

**20** Y el rey Ezequías se levantó temprano y reunió a los príncipes de la ciudad, y subieron a la casa de Jehová.

**21** Llevaron siete toros, siete carneros, siete corderos y siete machos de las cabras como ofrenda por el pecado a favor del reino, del santuario y de Judá. Y les dijo a los sacerdotes —los descendientes de Aarón— que los ofrecieran en el altar de Jehová.

**22** Entonces mataron los toros, y los sacerdotes recogieron la sangre y la salpicaron en el altar; después mataron los carneros y salpicaron la sangre en el altar, también mataron los corderos y salpicaron la sangre en el altar.

**23** Luego llevaron ante el rey y la congregación los machos de las cabras de la ofrenda por el pecado, y pusieron las manos sobre ellos.

**24** Los sacerdotes entonces los mataron y con su sangre hicieron en el altar una ofrenda por el pecado para hacer expiación por todo Israel, porque el rey dijo que la ofrenda quemada y la ofrenda por el pecado tenían que hacerse a favor de todo Israel.

**25** Entretanto, hizo que los levitas se colocaran en la casa de Jehová con címbalos, instrumentos de cuerda y arpas, de acuerdo con lo que mandaron David, Gad —el hombre de visiones del rey— y el profeta Natán, porque ese mandamiento lo había dado Jehová por medio de sus profetas.

**26** Así que los levitas estaban allí de pie con los instrumentos de David y los sacerdotes con las trompetas.

**27** Entonces Ezequías ordenó que se ofreciera el sacrificio quemado en el altar. Cuando comenzaron a presentar la ofrenda quemada, comenzó la canción de Jehová y también sonaron las trompetas siguiendo la dirección de los instrumentos del rey David de Israel.

**28** Y toda la congregación se inclinó mientras se cantaba la canción y sonaban las trompetas. Todo esto duró hasta que se terminó la ofrenda quemada.

**29** Tan pronto como acabaron de presentar la ofrenda, el rey y todos los que estaban con él se inclinaron y se postraron.

**30** El rey Ezequías y los príncipes les dijeron a los levitas que alabaran a Jehová con las palabras de David y de Asaf, el hombre de visiones. Así que ellos lo alabaron con gran alegría, y se inclinaron y se postraron.

**31** Entonces Ezequías dijo: “Ahora que ustedes han sido separados para el servicio de Jehová, vengan a la casa de Jehová y traigan sacrificios y ofrendas de agradecimiento”. Así que la congregación empezó a traer sacrificios y ofrendas de agradecimiento, y todos los que lo deseaban de corazón trajeron ofrendas quemadas.

**32** La cantidad de ofrendas quemadas que la congregación trajo fue de 70 reses, 100 carneros, 200 corderos —todos estos como ofrenda quemada para Jehová—,

**33** y las ofrendas santas fueron 600 reses y 3.000 ovejas.

**34** Pero no había suficientes sacerdotes para despellejar todas las ofrendas quemadas. Así que sus hermanos los levitas los ayudaron hasta que el trabajo quedó terminado y hasta que los sacerdotes pudieron santificarse, porque los levitas fueron más concienzudos en santificarse que los sacerdotes.

**35** También hubo muchas ofrendas quemadas, además de la grasa de los sacrificios de paz y las ofrendas líquidas para las ofrendas quemadas. Así se restableció el servicio de la casa de Jehová.

**36** Ezequías y todo el pueblo se alegraron mucho por lo que el Dios verdadero había establecido para el pueblo, y es que todo esto había pasado muy de repente.

### Notas a pie de página
- **v. 6:** Lit. “sus rostros”.
- **v. 8:** O “burlas”.
- **v. 11:** O “de descansar”.
- **v. 11:** O “para servir como sus ministros”.
- **v. 18:** Es decir, el pan de la presencia.
- **v. 31:** Lit. “Ahora ustedes han llenado su mano”.
- **v. 34:** Lit. “rectos de corazón”.
- **v. 35:** O “libaciones”.
- **v. 35:** O “preparó”.

---

## Segundo de las Crónicas 30

**1** Ezequías envió mensajeros a todo Israel y Judá, y hasta les escribió cartas a los de Efraín y Manasés, para que vinieran a la casa de Jehová en Jerusalén a celebrar la Pascua para Jehová, el Dios de Israel.

**2** Sin embargo, el rey, sus príncipes y toda la congregación de Jerusalén decidieron celebrar la Pascua en el segundo mes,

**3** pues no habían podido celebrarla en la fecha acostumbrada porque ni se habían santificado suficientes sacerdotes ni el pueblo se había reunido en Jerusalén.

**4** Esta decisión les pareció bien al rey y a toda la congregación.

**5** Así que decidieron hacer un anuncio por todo Israel, desde Beer-Seba hasta Dan, para que la gente viniera a celebrar en Jerusalén la Pascua para Jehová, el Dios de Israel; porque, como grupo, no la habían celebrado de acuerdo con lo que está escrito.

**6** Entonces, tal como mandó el rey, los mensajeros fueron por todo Israel y Judá con las cartas del rey y sus príncipes diciendo: “Gente de Israel, vuelvan a Jehová —el Dios de Abrahán, Isaac e Israel— para que él vuelva a los restantes que escaparon de las manos de los reyes de Asiria.

**7** No sean como sus antepasados ni como sus hermanos, que le fueron infieles a Jehová, el Dios de los antepasados de ellos, y por eso él los convirtió en motivo de horror, tal como ustedes mismos lo ven.

**8** Ahora no sean tercos como sus antepasados. Sométanse a Jehová y vengan a su santuario, que él ha santificado para siempre, y sirvan a Jehová su Dios; así dejará de estar furioso con ustedes.

**9** Porque, cuando ustedes vuelvan a Jehová, los que tienen cautivos a sus hermanos y a sus hijos les mostrarán misericordia a ellos, y les permitirán volver a esta tierra, porque Jehová su Dios es compasivo y misericordioso, y no les dará la espalda a ustedes si vuelven a él”.

**10** Así que los mensajeros fueron de ciudad en ciudad por toda la tierra de Efraín y Manasés, e incluso hasta Zabulón, pero la gente se reía y se burlaba de ellos.

**11** Sin embargo, algunas personas de Aser, Manasés y Zabulón se humillaron y vinieron a Jerusalén.

**12** La mano del Dios verdadero estuvo también en Judá a fin de unirlos para cumplir lo que el rey y los príncipes habían mandado según las palabras de Jehová.

**13** Una multitud se reunió en Jerusalén para celebrar la Fiesta de los Panes Sin Levadura el segundo mes. Era una congregación muy grande.

**14** Se pusieron a quitar los altares que había en Jerusalén, y quitaron todos los altares de incienso y los arrojaron en el valle de Cedrón.

**15** Entonces, el día 14 del segundo mes mataron los animales del sacrificio de la Pascua. Los sacerdotes y los levitas se sentían avergonzados, así que se santificaron y trajeron ofrendas quemadas a la casa de Jehová.

**16** Ocuparon sus puestos habituales, de acuerdo con la Ley de Moisés, el hombre del Dios verdadero; entonces los sacerdotes salpicaban la sangre que recibían de los levitas.

**17** En la congregación había muchos que no se habían santificado, y los levitas se encargaban de matar los animales del sacrificio de la Pascua por todos los que no estaban puros, a fin de santificarlos para Jehová.

**18** Porque muchos del pueblo —especialmente los de Efraín, Manasés, Isacar y Zabulón— no se habían purificado y aun así comieron la Pascua, en contra de lo que está escrito. Pero Ezequías oró por ellos. Dijo: “Que Jehová, que es bueno, les tenga consideración a

**19** todos los que han preparado su corazón para buscar al Dios verdadero, Jehová, el Dios de sus antepasados, aunque no hayan sido purificados de acuerdo con la norma de santidad”.

**20** Y Jehová escuchó a Ezequías y perdonó al pueblo.

**21** Así que los israelitas que estaban en Jerusalén celebraron con gran alegría la Fiesta de los Panes Sin Levadura durante siete días. Los levitas y los sacerdotes alababan a Jehová cada día tocando sus instrumentos con fuerza para Jehová.

**22** Además, Ezequías habló y animó a todos los levitas que servían a Jehová con sabiduría. Y estuvieron comiendo los siete días de la fiesta, ofreciendo sacrificios de paz y dándole gracias a Jehová, el Dios de sus antepasados.

**23** Entonces toda la congregación decidió celebrarla otros siete días, así que la celebraron con alegría siete días más.

**24** Y el rey Ezequías de Judá dio 1.000 toros y 7.000 ovejas para la congregación, y los príncipes dieron 1.000 toros y 10.000 ovejas para la congregación; y había muchos sacerdotes santificándose.

**25** Y toda la congregación de Judá, los sacerdotes, los levitas, toda la congregación que vino de Israel y los residentes extranjeros que vinieron de la tierra de Israel y los que vivían en Judá estaban muy alegres.

**26** La alegría reinaba en Jerusalén, porque desde los días de Salomón hijo de David, el rey de Israel, no había pasado nada igual en Jerusalén.

**27** Finalmente los sacerdotes levitas se pusieron de pie y bendijeron al pueblo; y Dios escuchó su voz, y la oración de ellos llegó a su santa morada, los cielos.

### Notas a pie de página
- **v. 6:** Lit. “corredores”.
- **v. 9:** O “benévolo”.
- **v. 9:** Lit. “no apartará de ustedes el rostro”.
- **v. 10:** Lit. “corredores”.
- **v. 12:** Lit. “darles un solo corazón”.
- **v. 20:** Lit. “sanó”.
- **v. 22:** Lit. “habló al corazón de”.

---

## Segundo de las Crónicas 31

**1** Al terminar todo esto, todos los israelitas que estaban presentes salieron a las ciudades de Judá y destrozaron las columnas sagradas, derribaron los postes sagrados, demolieron los lugares altos y los altares por todo Judá y Benjamín, así como en Efraín y Manasés, hasta que acabaron con ellos por completo. Después de eso, todos los israelitas volvieron a sus ciudades, cada uno a su propiedad.

**2** Entonces Ezequías organizó a los sacerdotes según sus divisiones y a los levitas según sus divisiones, a cada uno de los sacerdotes y de los levitas para su servicio, para las ofrendas quemadas y los sacrificios de paz, para servir y para dar gracias y alabanza en las puertas de los patios de Jehová.

**3** Se entregó parte de los bienes del rey para las ofrendas quemadas, incluidas las ofrendas quemadas de la mañana y de la tarde, así como las ofrendas quemadas de los sábados, las lunas nuevas y las fiestas, de acuerdo con lo que está escrito en la Ley de Jehová.

**4** Además, le ordenó a la gente que vivía en Jerusalén que les entregara a los sacerdotes y a los levitas la parte que les correspondía, para que así estos pudieran dedicarse por completo a la ley de Jehová.

**5** En cuanto se dio la orden, los israelitas entregaron las primicias de los cereales, del vino nuevo, del aceite, de la miel y de todos los productos del campo en gran cantidad; trajeron en abundancia la décima parte de todo.

**6** Y la gente de Israel y de Judá que vivía en las ciudades de Judá también trajo la décima parte de las vacas y las ovejas, y la décima parte de las cosas santas, que fueron santificadas para Jehová su Dios. Lo trajeron todo y lo pusieron en muchos montones.

**7** Empezaron a amontonar sus contribuciones en el tercer mes, y acabaron en el séptimo.

**8** Cuando Ezequías y los príncipes vinieron y vieron los montones, alabaron a Jehová y bendijeron a su pueblo Israel.

**9** Ezequías les preguntó a los sacerdotes y los levitas acerca de los montones,

**10** y Azarías, el sacerdote principal de la casa de Sadoc, le dijo: “Desde que comenzaron a traer las contribuciones a la casa de Jehová, la gente ha estado comiendo hasta quedar satisfecha y todavía sobra mucho, porque Jehová ha bendecido a su pueblo, y todo esto es lo que ha sobrado”.

**11** Ante aquello, Ezequías les dijo que prepararan cuartos de almacén en la casa de Jehová. Así que los prepararon.

**12** Siguieron trayendo fielmente las contribuciones, las décimas partes y las cosas santas. A Conanías el levita lo pusieron de supervisor a cargo de todo esto, y su hermano Simeí era el segundo después de él.

**13** Jehiel, Azazías, Náhat, Asahel, Jerimot, Jozabad, Eliel, Ismakías, Máhat y Benaya eran ayudantes de Conanías y de su hermano Simeí, por orden del rey Ezequías, y Azarías era supervisor de la casa del Dios verdadero.

**14** Y Coré hijo de Imná, el portero levita del lado este, estaba encargado de las ofrendas voluntarias del Dios verdadero y distribuía la contribución hecha a Jehová y las cosas santísimas.

**15** Y bajo su dirección estaban Edén, Miniamín, Jesúa, Semaya, Amarías y Secanías, en las ciudades de los sacerdotes. Ocupaban cargos de confianza para distribuir por igual las porciones entre sus hermanos en las divisiones, tanto a grande como a pequeño.

**16** Y esto era aparte de la distribución que se hacía entre los varones inscritos en el registro genealógico desde los tres años de edad para arriba, que venían todos los días a servir en la casa de Jehová y a cumplir con los deberes de sus divisiones.

**17** El registro genealógico de los sacerdotes estaba hecho según sus casas paternas, así como el de los levitas de 20 años de edad para arriba, según los deberes de sus divisiones.

**18** El registro genealógico incluía a todas sus esposas, hijos e hijas, incluso los pequeñitos, a toda su congregación —pues ellos se mantenían santificados para lo que era santo debido a su cargo de confianza—,

**19** y también a los descendientes de Aarón, los sacerdotes que vivían en los campos de pasto alrededor de sus ciudades. En todas las ciudades había hombres escogidos por nombre para dar porciones a cada uno de los varones entre los sacerdotes y a todos los inscritos en el registro genealógico de los levitas.

**20** Ezequías hizo esto en todo Judá. Siguió haciendo lo que era bueno, correcto y fiel ante Jehová su Dios.

**21** Y todo lo que emprendió para buscar a su Dios —ya sea relacionado con el servicio de la casa del Dios verdadero o con la Ley y los mandamientos— lo hizo con todo su corazón, y le fue bien.

### Notas a pie de página
- **v. 2:** Lit. “campamentos”.
- **v. 4:** O “adherirse estrictamente”.
- **v. 11:** O “comedores”.
- **v. 12:** O “los diezmos”.
- **v. 14:** O “Qoré”. Ver apén. A2.
- **v. 14:** O “Imnah”. Ver apén. A2.

---

## Segundo de las Crónicas 32

**1** Después de estas cosas y de estas muestras de fidelidad, el rey Senaquerib de Asiria vino a invadir Judá. Cercó las ciudades fortificadas decidido a entrar por la fuerza y conquistarlas.

**2** Cuando Ezequías vio que Senaquerib había venido y quería luchar contra Jerusalén,

**3** consultó a sus príncipes y a sus guerreros, y decidió tapar los manantiales de agua que estaban fuera de la ciudad, y ellos lo apoyaron.

**4** Reunieron a mucha gente, y se pusieron a tapar todas las fuentes y el arroyo que pasaba por aquella tierra. Decían: “¿Por qué vamos a dejar que los reyes de Asiria lleguen y encuentren tanta agua?”.

**5** Además, con mucha determinación, reconstruyó toda la muralla que estaba derrumbada y levantó torres en ella. Y por fuera hizo otra muralla. También reparó el Montículo de la Ciudad de David y fabricó muchísimas armas y escudos.

**6** Entonces nombró jefes militares sobre el pueblo, los reunió en la plaza de la puerta de la ciudad y los animó diciendo:

**7** “Sean fuertes y valientes. No tengan miedo ni se aterroricen por el rey de Asiria y toda la multitud que está con él, porque son más los que están con nosotros que los que están con él.

**8** Él cuenta con un brazo de carne, pero con nosotros está Jehová nuestro Dios para ayudarnos y para pelear nuestras batallas”. Y las palabras del rey Ezequías de Judá fortalecieron al pueblo.

**9** Después de esto, el rey Senaquerib de Asiria —que estaba en Lakís con todo su poder imperial— envió a sus siervos a Jerusalén, al rey Ezequías de Judá y a todos los de Judá que estaban en Jerusalén, para decir:

**10** “Esto es lo que dice el rey Senaquerib de Asiria: ‘¿En qué confían ustedes para quedarse en Jerusalén mientras la están cercando?

**11** ¿No ven que, cuando Ezequías les dice “Jehová nuestro Dios nos librará de las manos del rey de Asiria”, los está engañando y los hará morir de hambre y sed?

**12** ¿No es este el mismo Ezequías que quitó los lugares altos y los altares del Dios de ustedes y luego le dijo a Judá y Jerusalén “Deben inclinarse delante de un solo altar y en él deben hacer humear sus sacrificios”?

**13** ¿No saben ustedes lo que mis antepasados y yo les hicimos a todos los pueblos de otras tierras? ¿Acaso los dioses de las naciones de esas tierras pudieron librar sus territorios de mis manos?

**14** ¿Cuál de todos los dioses de esas naciones que mis antepasados destruyeron fue capaz de librar a su pueblo de mis manos? Entonces, ¿cómo podrá librarlos de mis manos el Dios de ustedes?

**15** ¡No se dejen engañar ni engatusar por Ezequías! No pongan su fe en él. Si ningún dios de ninguna nación o reino fue capaz de librar a su pueblo de mis manos ni de las manos de mis antepasados, ¡mucho menos los va a librar de mis manos el Dios de ustedes!’”.

**16** Sus siervos siguieron diciendo todavía más cosas contra Jehová, el Dios verdadero, y contra su siervo Ezequías.

**17** También escribió cartas para insultar a Jehová, el Dios de Israel, y para hablar en contra de él. Decía: “Igual que los dioses de otras naciones no libraron a su pueblo de mis manos, el Dios de Ezequías tampoco librará a su pueblo de mis manos”.

**18** A la gente de Jerusalén que estaba en la muralla no dejaban de gritarle en el idioma de los judíos, para meterles miedo y aterrorizarlos, y así conquistar la ciudad.

**19** Hablaron contra el Dios de Jerusalén igual que contra los dioses de los pueblos de la tierra, que están hechos por manos de hombre.

**20** Pero el rey Ezequías y el profeta Isaías hijo de Amoz oraron sobre esto y clamaron a los cielos por ayuda.

**21** Entonces Jehová envió un ángel y acabó con todos los guerreros poderosos, líderes y jefes del campamento del rey de Asiria, quien volvió humillado a su propia tierra. Más tarde, entró en el templo de su dios, y algunos de sus propios hijos lo mataron allí a espada.

**22** Así Jehová salvó a Ezequías y a los habitantes de Jerusalén de las manos del rey Senaquerib de Asiria y de las manos de todos los demás, y les dio paz en todos lados.

**23** Y muchos trajeron regalos para Jehová en Jerusalén y cosas selectas para el rey Ezequías de Judá, quien fue muy respetado por las naciones después de eso.

**24** En aquellos días, Ezequías se enfermó y estaba al borde de la muerte. Le oró a Jehová, y él le contestó y le dio una señal.

**25** Pero Ezequías no mostró aprecio por el bien que se le había hecho. Su corazón se hizo arrogante, provocando que Dios se indignara con él y con Judá y Jerusalén.

**26** Sin embargo, Ezequías se humilló por la arrogancia de su corazón, tanto él como los habitantes de Jerusalén, y Jehová no se indignó con ellos en los días de Ezequías.

**27** Y Ezequías llegó a tener muchísimas riquezas y gloria; y se hizo almacenes para la plata, el oro, las piedras preciosas, el aceite balsámico, los escudos y todos los objetos valiosos.

**28** También preparó lugares para almacenar la producción de cereal, vino nuevo y aceite, así como compartimientos para los diferentes tipos de ganado y corrales para los rebaños.

**29** Además, obtuvo ciudades y mucho ganado, rebaños y manadas, porque Dios le dio muchísimos bienes.

**30** Ezequías fue quien tapó la salida superior de las aguas de Guihon y las dirigió directamente hacia abajo, hacia el oeste, a la Ciudad de David. Ezequías tuvo éxito en todo lo que hizo.

**31** Pero, cuando los portavoces de los príncipes de Babilonia fueron enviados para preguntarle sobre la señal que había ocurrido en el país, el Dios verdadero lo dejó solo, para ponerlo a prueba y saber todo lo que había en su corazón.

**32** En cuanto al resto de la historia de Ezequías y sus actos de amor leal, están escritos en la visión del profeta Isaías, el hijo de Amoz, en el Libro de los Reyes de Judá y de Israel.

**33** Finalmente Ezequías descansó con sus antepasados, y lo enterraron en la subida a las sepulturas de los hijos de David. Cuando murió, todo Judá y los habitantes de Jerusalén lo honraron. Y su hijo Manasés se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 5:** O “Miló”. Un término hebreo que significa ‘relleno’.
- **v. 5:** O “muchísimos proyectiles”.
- **v. 6:** Lit. “habló al corazón de ellos”.
- **v. 8:** O “con poder humano”.
- **v. 9:** O “con todo su poder militar y esplendor”.
- **v. 12:** Lit. “los lugares altos y los altares de él”.
- **v. 14:** O “entregaron a la destrucción”.
- **v. 22:** O “descanso”.
- **v. 24:** O “un portento presagioso”.
- **v. 31:** O “el portento presagioso”.

---

## Segundo de las Crónicas 33

**1** Manasés tenía 12 años cuando llegó a ser rey, y reinó 55 años en Jerusalén.

**2** Él hizo lo que estaba mal a los ojos de Jehová, imitando las prácticas detestables de las naciones que Jehová había expulsado delante del pueblo de Israel.

**3** Reconstruyó los lugares altos que su padre Ezequías había demolido, les construyó altares a los Baales e hizo postes sagrados. Además, se inclinó ante todo el ejército de los cielos y se puso a servirle.

**4** También construyó altares en la casa de Jehová, sobre la que Jehová había dicho “En Jerusalén estará mi nombre para siempre”.

**5** Y le construyó altares a todo el ejército de los cielos en dos patios de la casa de Jehová.

**6** Y a sus propios hijos los quemó en el fuego en el valle del Hijo de Hinón; practicó magia y hechicería, usó la adivinación y nombró médiums y adivinos. Hizo a gran escala lo que estaba mal a los ojos de Jehová para provocarlo.

**7** Y la imagen tallada que hizo la metió en la casa del Dios verdadero, de la cual Dios les había dicho a David y a su hijo Salomón: “En esta casa y en Jerusalén, el lugar que elegí de todas las tribus de Israel, pondré mi nombre de manera permanente.

**8** Y nunca volveré a quitar los pies de Israel del país que les asigné a sus antepasados, siempre y cuando obedezcan con cuidado todo lo que les he mandado, toda la Ley, las normas y las decisiones judiciales que recibieron mediante Moisés”.

**9** Manasés siguió descarriando a Judá y a los habitantes de Jerusalén llevándolos a hacer cosas todavía peores que las naciones que Jehová había aniquilado delante de los israelitas.

**10** Jehová les hablaba a Manasés y a su pueblo, pero no hicieron caso.

**11** Así que Jehová hizo que los jefes del ejército del rey de Asiria vinieran contra ellos. Capturaron a Manasés con garfios, lo sujetaron con dos grilletes de cobre y se lo llevaron a Babilonia.

**12** En su angustia, le suplicó a Jehová su Dios y estuvo humillándose profundamente delante del Dios de sus antepasados.

**13** Le siguió orando, y Dios se sintió conmovido por su ruego y escuchó su súplica, y lo devolvió a su reinado en Jerusalén. Entonces Manasés llegó a saber que Jehová es el Dios verdadero.

**14** Después de esto, él construyó una muralla exterior para la Ciudad de David —al oeste de Guihon, en el valle— hasta la Puerta del Pescado. Hizo que diera la vuelta hasta Ofel, y la hizo muy alta. Además, nombró jefes del ejército en todas las ciudades fortificadas de Judá.

**15** Entonces quitó los dioses extranjeros y la imagen-ídolo de la casa de Jehová, así como todos los altares que había construido en la montaña de la casa de Jehová y en Jerusalén, y mandó arrojarlos fuera de la ciudad.

**16** Además, preparó el altar de Jehová y empezó a ofrecer en él sacrificios de paz y sacrificios de agradecimiento, y le dijo a Judá que sirviera a Jehová, el Dios de Israel.

**17** Sin embargo, el pueblo todavía hacía sacrificios en los lugares altos, aunque solo para Jehová su Dios.

**18** En cuanto al resto de la historia de Manasés, su oración a su Dios y las palabras de los hombres de visiones que le hablaron en el nombre de Jehová, el Dios de Israel, está todo registrado en la historia de los reyes de Israel.

**19** También su oración y cómo su ruego se le concedió, todos sus pecados y su infidelidad, los sitios en los que antes de humillarse construyó lugares altos y levantó postes sagrados e imágenes esculpidas, está todo escrito entre las palabras de sus hombres de visiones.

**20** Entonces Manasés descansó con sus antepasados, y lo enterraron junto a su casa; y su hijo Amón se convirtió en el nuevo rey.

**21** Amón tenía 22 años cuando se convirtió en rey, y reinó dos años en Jerusalén.

**22** Hacía lo que estaba mal a los ojos de Jehová, tal como lo había hecho su padre Manasés; y Amón les hacía sacrificios a todas las imágenes esculpidas que Manasés su padre había hecho, y les servía.

**23** Pero no se humilló ante Jehová, como sí lo hizo su padre Manasés; en vez de eso, Amón se hizo más y más culpable.

**24** Finalmente, sus siervos conspiraron contra él y lo mataron en su propia casa.

**25** Pero la gente del país mató a todos los que habían conspirado contra el rey Amón, y convirtieron a su hijo Josías en el nuevo rey.

### Notas a pie de página
- **v. 6:** O “hizo pasar por”.
- **v. 11:** O quizás “en los huecos”.
- **v. 12:** O “ablandó el rostro de”.
- **v. 14:** O “wadi”.

---

## Segundo de las Crónicas 34

**1** Josías tenía ocho años cuando se convirtió en rey, y reinó 31 años en Jerusalén.

**2** Hizo lo que estaba bien a los ojos de Jehová y siguió los mismos pasos de su antepasado David. No se desvió ni a la derecha ni a la izquierda.

**3** Y en el octavo año de su reinado, siendo todavía un muchacho, comenzó a buscar al Dios de su antepasado David; y en el año 12 comenzó a limpiar Judá y Jerusalén quitando los lugares altos y los postes sagrados, las imágenes esculpidas y las estatuas de metal.

**4** Además, derribaron en su presencia los altares de los Baales. Y los altares de incienso que estaban encima de ellos los derribó. También hizo pedazos los postes sagrados, las imágenes esculpidas y las estatuas de metal; los convirtió en polvo, y ese polvo lo esparció sobre las tumbas de los que solían hacerles sacrificios.

**5** Y quemó los huesos de los sacerdotes en sus altares. Así limpió Judá y Jerusalén.

**6** Y en las ciudades de Manasés, Efraín, Simeón y hasta Neftalí, en las ruinas alrededor de ellas,

**7** derribó los altares y trituró los postes sagrados y las imágenes esculpidas hasta convertirlos en polvo; derribó todos los altares de incienso en toda la tierra de Israel, y después de eso regresó a Jerusalén.

**8** En el año 18 de su reinado, después de haber limpiado el país y el templo, envió a Safán hijo de Azalías, a Maaseya —el jefe de la ciudad— y al registrador Joá hijo de Joacaz para reparar la casa de Jehová su Dios.

**9** Ellos fueron a ver al sumo sacerdote Hilquías y le dieron el dinero que se había traído a la casa de Dios, el dinero que los levitas que servían de porteros habían recogido de Manasés, Efraín y del resto de Israel, así como de Judá, Benjamín y de los habitantes de Jerusalén.

**10** Entonces ellos se lo dieron a los que supervisaban el trabajo en la casa de Jehová. Y los trabajadores de la casa de Jehová lo usaron para restaurar y reparar la casa.

**11** Se lo dieron a los artesanos y los obreros para comprar piedra labrada y madera para soportes, y para levantar con vigas los edificios que los reyes de Judá habían dejado deteriorarse.

**12** Los hombres hicieron fielmente su trabajo. Por encima de ellos se nombró a los levitas Jáhat y Abdías —de los meraritas—, y a Zacarías y Mesulam —de los cohatitas—, para que fueran supervisores. Y los levitas, que eran todos músicos competentes,

**13** estaban al mando de los trabajadores comunes y eran supervisores de todos los que trabajaban en los diversos tipos de servicio; y algunos de los levitas eran secretarios, funcionarios y porteros.

**14** Mientras sacaban el dinero que se había traído a la casa de Jehová, el sacerdote Hilquías encontró el libro de la Ley de Jehová, que se había entregado mediante Moisés.

**15** Así que Hilquías le dijo al secretario Safán: “Encontré el libro de la Ley en la casa de Jehová”, e Hilquías le dio el libro a Safán.

**16** Entonces Safán fue a llevarle el libro al rey; le dijo: “Tus siervos están haciendo todo lo que se les encargó.

**17** Recogieron el dinero que había en la casa de Jehová y se lo dieron a los supervisores y a los trabajadores”.

**18** El secretario Safán también le dijo al rey: “El sacerdote Hilquías me dio un libro”. Y se puso a leerlo delante del rey.

**19** En cuanto el rey escuchó las palabras de la Ley, se rasgó la ropa.

**20** Entonces el rey les dio esta orden a Hilquías, a Ahicam hijo de Safán, a Abdón hijo de Miqueas, al secretario Safán y a Asaya, el siervo del rey:

**21** “Vayan, consulten a Jehová por mí y por los que quedan en Israel y Judá sobre lo que dice el libro que han encontrado, porque la furia que Jehová derramará sobre nosotros es muy grande, pues nuestros antepasados no obedecieron las palabras de Jehová, no cumplieron con todo lo que está escrito en este libro”.

**22** Así que Hilquías, junto con los que había enviado el rey, fue a ver a la profetisa Huldá. Ella era la esposa de Salum —hijo de Ticvá, hijo de Harhás—, el encargado del guardarropa. Vivía en el Segundo Barrio de Jerusalén, y allí hablaron con ella.

**23** Ella les dijo: “Esto es lo que dice Jehová, el Dios de Israel: ‘Díganle al hombre que los envió a verme:

**24** “Esto es lo que dice Jehová: ‘A este lugar y a sus habitantes les mandaré una calamidad, todas las maldiciones que están escritas en el libro que leyeron delante del rey de Judá.

**25** Por haberme abandonado y estar haciendo humear sus sacrificios para otros dioses a fin de provocarme con todas sus obras, mi furia se derramará sobre este lugar y no se apagará’”.

**26** Pero díganle al rey de Judá, quien los envió para consultar a Jehová: “Esto es lo que dice Jehová, el Dios de Israel: ‘En cuanto a las palabras que has escuchado,

**27** como tu corazón fue sensible y te humillaste ante Dios cuando escuchaste sus palabras sobre este lugar y sus habitantes, y te humillaste delante de mí, te rasgaste la ropa y lloraste ante mí, yo también te he escuchado —declara Jehová—.

**28** Por eso voy a reunirte con tus antepasados, y en paz serás enterrado en tu tumba, y tus ojos no verán toda la calamidad que voy a mandarles a este lugar y a sus habitantes’”’”. Así que fueron a comunicarle la respuesta al rey.

**29** De modo que el rey mandó reunir a todos los ancianos de Judá y de Jerusalén.

**30** Después, el rey subió a la casa de Jehová con todos los hombres de Judá, los habitantes de Jerusalén, los sacerdotes y los levitas —todo el pueblo, grandes y pequeños—, y les leyó todas las palabras del libro del pacto que habían encontrado en la casa de Jehová.

**31** El rey se colocó en su lugar e hizo un pacto ante Jehová en el que se comprometía a seguir a Jehová y obedecer con todo el corazón y con toda el alma sus mandamientos, sus recordatorios y sus normas cumpliendo con las palabras del pacto escritas en ese libro.

**32** Además, hizo que todos los que estaban en Jerusalén y Benjamín se comprometieran a cumplirlo. Y los habitantes de Jerusalén actuaron de acuerdo con el pacto de Dios, el Dios de sus antepasados.

**33** Josías entonces quitó todas las cosas detestables de todas las tierras que les pertenecían a los israelitas, e hizo que todos en Israel sirvieran a Jehová su Dios. Mientras él vivió, no se desviaron de seguir a Jehová, el Dios de sus antepasados.

### Notas a pie de página
- **v. 3:** O “de metal fundido”.
- **v. 4:** O “de metal fundido”.
- **v. 8:** Lit. “la casa”.
- **v. 13:** O “cargadores”.
- **v. 14:** Lit. “por la mano de”.
- **v. 17:** Lit. “Vertieron”.
- **v. 27:** Lit. “blando”.
- **v. 28:** Esta es una forma poética de referirse a la muerte.
- **v. 31:** O “y renovó el pacto”.
- **v. 31:** Ver glosario.
- **v. 33:** O “todos los ídolos”.
- **v. 33:** Lit. “Todos los días de él”.

---

## Segundo de las Crónicas 35

**1** Josías celebró una Pascua para Jehová en Jerusalén, y mataron los animales del sacrificio de la Pascua el día 14 del primer mes.

**2** Colocó a los sacerdotes en sus funciones y los animó a cumplir con su servicio en la casa de Jehová.

**3** Entonces les dijo a los levitas, los instructores de todo Israel, los que eran santos para Jehová: “Pongan el Arca santa en la casa que construyó Salomón hijo de David, el rey de Israel. Ya no tienen que llevarla sobre los hombros. Ahora sirvan a Jehová su Dios y al pueblo de él, Israel.

**4** Y prepárense según sus casas paternas, según sus divisiones, de acuerdo con lo que escribieron el rey David de Israel y su hijo Salomón.

**5** Pónganse en el lugar santo agrupados según las casas paternas de sus hermanos, el resto del pueblo; para cada una de ellas debe haber un grupo de la casa paterna de los levitas.

**6** Maten los animales del sacrificio de la Pascua, santifíquense y hagan preparativos para sus hermanos, a fin de cumplir las palabras de Jehová transmitidas mediante Moisés”.

**7** Josías les dio rebaños —corderos y cabritos— a todos los presentes del pueblo para los sacrificios de la Pascua, 30.000 en total, además de 3.000 reses. Todo esto provenía de los bienes del rey.

**8** Sus príncipes también dieron una contribución como ofrenda voluntaria para el pueblo, los sacerdotes y los levitas. Hilquías, Zacarías y Jehiel, los líderes de la casa del Dios verdadero, les dieron a los sacerdotes 2.600 animales para el sacrificio de la Pascua y 300 reses.

**9** Conanías y sus hermanos Semaya y Netanel, junto con Hasabías, Jeiel y Jozabad, los jefes de los levitas, les dieron a los levitas 5.000 animales para el sacrificio de la Pascua y 500 reses.

**10** Todo quedó preparado para el servicio, los sacerdotes ocuparon sus puestos y los levitas se colocaron según sus divisiones, como lo había mandado el rey.

**11** Mataron los animales del sacrificio de la Pascua y, mientras los levitas los despellejaban, los sacerdotes salpicaban la sangre que recibían de ellos.

**12** Luego prepararon las ofrendas quemadas para distribuirlas entre el resto del pueblo —que estaba agrupado según las casas paternas— para que pudieran ofrecérselas a Jehová como está escrito en el libro de Moisés; e hicieron lo mismo con las reses.

**13** Cocinaron la ofrenda de la Pascua en el fuego, según la costumbre; y las ofrendas santas las cocinaron en ollas, calderos y sartenes, después de lo cual se las llevaron rápido al resto del pueblo.

**14** Entonces los levitas prepararon la comida de la Pascua para sí mismos y para los sacerdotes, porque los sacerdotes —los descendientes de Aarón— estuvieron ofreciendo los sacrificios quemados y la grasa hasta el anochecer. Así que los levitas prepararon la comida para sí mismos y para los sacerdotes, los descendientes de Aarón.

**15** Y los cantores, los hijos de Asaf, estaban en sus puestos de acuerdo con las órdenes de David, Asaf, Hemán y Jedutún, el hombre de visiones del rey; y los porteros estaban en las distintas puertas. No había necesidad de que dejaran su servicio, porque sus hermanos los levitas lo prepararon todo para ellos.

**16** Así que, en aquel día, todo el servicio de Jehová quedó preparado para celebrar la Pascua y ofrecer en el altar de Jehová las ofrendas quemadas, de acuerdo con la orden del rey Josías.

**17** Los israelitas que estaban presentes celebraron la Pascua en aquella ocasión y la Fiesta de los Panes Sin Levadura durante siete días.

**18** Nunca se había celebrado en Israel una Pascua como esa desde los días del profeta Samuel; y ninguno de los otros reyes de Israel había celebrado una Pascua como la que celebraron Josías, los sacerdotes, los levitas y todos los de Judá e Israel que estaban presentes, así como los habitantes de Jerusalén.

**19** Esta Pascua se celebró en el año 18 del reinado de Josías.

**20** Después de todo esto, después de que Josías restauró el templo, el rey Nekó de Egipto subió para pelear en Carquemis, junto al Éufrates. Entonces Josías salió a enfrentarse con él.

**21** Por eso él le envió mensajeros para decirle: “Rey de Judá, ¿qué tiene que ver esto contigo? Hoy no vengo a enfrentarme a ti, voy a luchar contra otra casa, y Dios dice que debo apresurarme. Por tu propio bien, no te opongas a Dios, que está conmigo. Si lo haces, él acabará contigo”.

**22** Pero Josías no quiso retroceder, sino que se disfrazó para pelear contra él. No escuchó las palabras de Nekó, que venían de la boca de Dios, y fue a pelear a la llanura de Meguidó.

**23** Los arqueros le dispararon al rey Josías, y él les dijo a sus siervos: “Sáquenme de aquí, que estoy malherido”.

**24** Así que sus siervos lo sacaron del carro, lo montaron en su segundo carro de guerra y lo trajeron a Jerusalén. Así murió y fue enterrado en la tumba de sus antepasados. Todo Judá y todo Jerusalén se pusieron de duelo por Josías.

**25** Jeremías cantó una canción de lamento por Josías, y hasta el día de hoy todos los cantores y las cantoras siguen cantando sobre Josías en sus canciones de duelo. Se tomó la decisión de que estas debían cantarse en Israel, y están escritas entre las canciones de duelo.

**26** En cuanto al resto de la historia de Josías, sus obras de amor leal al obedecer lo que está escrito en la Ley de Jehová

**27** y las cosas que hizo, está todo escrito de principio a fin en el Libro de los Reyes de Israel y de Judá.

### Notas a pie de página
- **v. 5:** Lit. “los hijos del pueblo”.
- **v. 13:** O quizás “Asaron”.
- **v. 20:** Lit. “la casa”.
- **v. 25:** O “endechas”.

---

## Segundo de las Crónicas 36

**1** Entonces la gente del país hizo rey en Jerusalén a Jehoacaz, hijo de Josías, en lugar de su padre.

**2** Jehoacaz tenía 23 años cuando se convirtió en rey, y reinó tres meses en Jerusalén.

**3** Sin embargo, el rey de Egipto lo destituyó en Jerusalén y le exigió al país 100 talentos de plata y un talento de oro.

**4** Además de eso, el rey de Egipto hizo rey de Judá y Jerusalén a Eliaquim, hermano de Jehoacaz, y le cambió el nombre al de Jehoiaquim. Pero a su hermano Jehoacaz, Nekó se lo llevó a Egipto.

**5** Jehoiaquim tenía 25 años cuando se convirtió en rey, y reinó 11 años en Jerusalén. Hacía lo que estaba mal a los ojos de Jehová su Dios.

**6** El rey Nabucodonosor de Babilonia subió contra él para sujetarlo con dos grilletes de cobre y llevárselo a Babilonia.

**7** Y Nabucodonosor se llevó a Babilonia algunos de los utensilios de la casa de Jehová y los puso en su palacio en Babilonia.

**8** En cuanto al resto de la historia de Jehoiaquim, las cosas detestables que hizo y todo lo que se halló en su contra, está escrito en el Libro de los Reyes de Israel y de Judá; y su hijo Joaquín se convirtió en el nuevo rey.

**9** Joaquín tenía 18 años cuando se convirtió en rey, y reinó 3 meses y 10 días en Jerusalén. Hacía lo que estaba mal a los ojos de Jehová.

**10** A principios de año, el rey Nabucodonosor mandó traerlo a Babilonia junto con objetos valiosos de la casa de Jehová. Además, hizo rey de Judá y Jerusalén a Sedequías, el hermano de su padre.

**11** Sedequías tenía 21 años cuando se convirtió en rey, y reinó 11 años en Jerusalén.

**12** Hacía lo que estaba mal a los ojos de Jehová su Dios. No se humilló ante el profeta Jeremías, quien habló por orden de Jehová.

**13** También se rebeló contra el rey Nabucodonosor, quien le había hecho hacer un juramento por Dios. Fue terco y obstinado, y se negó a volver a Jehová, el Dios de Israel.

**14** Todos los jefes de los sacerdotes y también el pueblo fueron extremadamente infieles al hacer todas las cosas detestables que hacían las naciones, y contaminaron la casa de Jehová, que él había santificado en Jerusalén.

**15** Jehová, el Dios de sus antepasados, siguió advirtiéndoles por medio de sus mensajeros. Les advirtió vez tras vez, porque sentía compasión por su pueblo y por su propia morada.

**16** Pero ellos estuvieron burlándose de los mensajeros del Dios verdadero. Despreciaron las palabras de él y se burlaron de sus profetas, hasta que la furia de Jehová se desató contra su pueblo, hasta que ya no tuvieron remedio.

**17** De modo que él mandó contra ellos al rey de los caldeos, que mató a espada a sus jóvenes en la casa de su santuario. No sintió compasión ni por los jóvenes ni por las vírgenes, ni por los ancianos ni por los débiles. Dios lo entregó todo en sus manos.

**18** Todos los utensilios de la casa del Dios verdadero —tanto grandes como pequeños—, así como los tesoros de la casa de Jehová y los tesoros del rey y sus príncipes, todo se lo llevó a Babilonia.

**19** Quemó la casa del Dios verdadero, derrumbó la muralla de Jerusalén, les prendió fuego a sus torres fortificadas y destruyó todas las cosas de valor.

**20** Se llevó cautivos a Babilonia a los que se salvaron de morir a espada, y llegaron a ser siervos de él y de sus hijos hasta que el reino de Persia tomó el control,

**21** para que se cumplieran las palabras de Jehová que pronunció Jeremías, hasta que la tierra pagó su deuda de sábados. Todos los días que estuvo desolada guardó el sábado, hasta cumplir 70 años.

**22** En el primer año del rey Ciro de Persia, Jehová movió al rey Ciro de Persia a proclamar un decreto por todo su reino para que se cumplieran las palabras de Jehová pronunciadas por Jeremías. El decreto —que también puso por escrito— decía:

**23** “Esto es lo que dice el rey Ciro de Persia: ‘Jehová, el Dios de los cielos, me ha dado todos los reinos de la tierra y me ha encargado que le construya una casa en Jerusalén, que está en Judá. Aquellos de ustedes que formen parte de su pueblo, que Jehová su Dios esté con ellos y que suban para allá’”.

### Notas a pie de página
- **v. 3:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 10:** Posiblemente en la primavera.
- **v. 13:** Lit. “Endureció su cerviz”.
- **v. 20:** O “la realeza”.
- **v. 22:** Lit. “incitó el espíritu del”.
