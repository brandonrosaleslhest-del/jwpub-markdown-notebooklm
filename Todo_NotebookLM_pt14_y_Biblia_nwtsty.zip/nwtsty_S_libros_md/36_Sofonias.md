# El libro de Sofonías (Sofonías)

---

## Información sobre Sofonías

---

**SOFONÍAS**

## CONTENIDO DEL LIBRO

- **1**
  - El día de juicio de Jehová está cerca (1-18)
    - El día de Jehová se aproxima rápidamente (14)
    - Ni la plata ni el oro pueden salvar a nadie (18)
- **2**
  - Busquen a Jehová antes del día de su furia (1-3)
    - Busquen la justicia y la mansedumbre (3)
    - “Probablemente se les oculte” (3)
  - Condena a las naciones vecinas (4-15)
- **3**
  - Jerusalén es una ciudad rebelde y corrupta (1-7)
  - Condena y regreso de los cautivos (8-20)
    - Cambio a un idioma puro (9)
    - Un pueblo humilde y modesto será salvado (12)
    - Jehová se alegrará por Sion (17)

---

## Sofonías 1

**1** Estas son las palabras de Jehová que recibió Sofonías, hijo de Cusí, hijo de Guedalías, hijo de Amarías, hijo de Ezequías, en los días de Josías hijo de Amón, el rey de Judá:

**2** “Exterminaré por completo todo lo que haya en la superficie de la tierra”, afirma Jehová.

**3** “Exterminaré a los hombres y a los animales. Exterminaré a las aves del cielo y a los peces del mar y acabaré con los obstáculos y con los malvados; borraré a los seres humanos de la superficie de la tierra”, afirma Jehová.

**4** “Extenderé mi mano contra Judá y contra todos los habitantes de Jerusalén, y eliminaré de este lugar todo rastro de Baal, el nombre de los sacerdotes de dioses extranjeros junto con los sacerdotes,

**5** y a los que se inclinan en las azoteas ante el ejército de los cielos, a los que se inclinan y le juran lealtad a Jehová al mismo tiempo que le juran lealtad a Malcam,

**6** a los que dejan de seguir a Jehová y a los que no buscan a Jehová ni lo consultan”.

**7** Guarden silencio en presencia del Señor Soberano Jehová, porque el día de Jehová está cerca. Jehová ha preparado un sacrificio; ha santificado a sus invitados.

**8** “El día del sacrificio de Jehová les pediré cuentas a los príncipes, a los hijos del rey y a todos los que llevan ropa extranjera.

**9** Les pediré cuentas a todos los que suban a la plataforma ese día, a los que llenan de violencia y engaño la casa de su amo.

**10** Ese día —afirma Jehová— se oirá un grito desde la Puerta del Pescado, un lamento desde el Segundo Barrio de la ciudad y un gran estruendo desde las colinas.

**11** Laméntense, habitantes de Mactés, porque todos los comerciantes han sido aniquilados; todos los que pesan plata han sido destruidos.

**12** En ese tiempo examinaré cuidadosamente a Jerusalén con lámparas y les pediré cuentas a los que están satisfechos de sí mismos y dicen en su corazón: ‘Jehová no hará nada bueno ni nada malo’.

**13** Sus riquezas serán saqueadas y sus casas destruidas. Construirán casas, pero no las ocuparán; plantarán viñas, pero no beberán su vino.

**14** ¡El gran día de Jehová está cerca! ¡Está cerca y se aproxima rápidamente! El sonido del día de Jehová es amargo. Ese día hasta los guerreros gritan.

**15** Ese día es un día de furia, un día de sufrimiento y angustia, un día de tormenta y desolación, un día de oscuridad y sombras, un día de nubes y densas tinieblas,

**16** un día de toque de cuerno y de grito de guerra contra las ciudades fortificadas y contra las torres altas de las esquinas.

**17** Haré que los seres humanos se angustien, y ellos andarán como ciegos, porque han pecado contra Jehová. Su sangre será derramada como polvo y sus intestinos como estiércol.

**18** Ni su plata ni su oro podrán salvarlos el día de la furia de Jehová; el fuego de su celo consumirá toda la tierra, porque él exterminará de un modo terrible a todos los habitantes de la tierra”.

### Notas a pie de página
- **v. 1:** Que significa ‘Jehová ha ocultado (atesorado)’.
- **v. 3:** Al parecer, se refiere a actividades y objetos relacionados con la idolatría.
- **v. 5:** O “terrazas”.
- **v. 9:** O “al podio”, “al umbral”. Posiblemente la plataforma del trono del rey.
- **v. 11:** Al parecer, un sector de Jerusalén cercano a la Puerta del Pescado.
- **v. 11:** O “mercaderes”.
- **v. 11:** Lit. “silenciados”.
- **v. 12:** Lit. “a los que se espesan sobre sus sedimentos”, como puede pasar en un recipiente para el vino.
- **v. 14:** O “se apresura con rapidez”.
- **v. 17:** O “su carne”.

---

## Sofonías 2

**1** Júntense, sí, reúnanse todos, oh, nación que no tiene vergüenza.

**2** Antes de que se cumpla el decreto, antes de que el día pase como la paja llevada por el viento, antes de que caiga sobre ustedes la ardiente furia de Jehová, antes de que caiga sobre ustedes el día de la furia de Jehová,

**3** busquen a Jehová todos ustedes, los mansos de la tierra, los que obedecen sus justos decretos. Busquen la justicia, busquen la mansedumbre. Probablemente se les oculte durante el día de la furia de Jehová.

**4** Gaza será una ciudad abandonada y Asquelón será desolada. Asdod será expulsada a plena luz del día y Ecrón será desarraigada.

**5** “¡Ay de los que viven en la costa, la nación de los keretitas! Las palabras de Jehová van contra ustedes. Oh, Canaán, tierra de los filisteos, te voy a destruir de modo que no te quede ningún habitante.

**6** Y la costa se transformará en campos de pasto, con pozos para los pastores y corrales de piedra para las ovejas.

**7** Esa región será para los que queden de la casa de Judá. Allí se alimentarán. Al atardecer se acostarán en las casas de Asquelón. Porque Jehová su Dios se fijará en ellos y traerá de vuelta a los que estén cautivos”.

**8** “He oído las burlas de Moab y los insultos de los ammonitas; ellos se han burlado de mi pueblo y han amenazado con arrogancia su territorio.

**9** Por tanto, tan cierto como que yo vivo —afirma Jehová de los ejércitos, el Dios de Israel—, Moab será como Sodoma y los ammonitas serán como Gomorra, un lugar lleno de ortigas, un hoyo de sal y un terreno permanentemente desolado. Los que queden de mi pueblo los saquearán, y los que queden de mi nación les quitarán su tierra.

**10** Esto es lo que recibirán debido a su orgullo, porque se burlaron y trataron con arrogancia al pueblo de Jehová de los ejércitos.

**11** Jehová será imponente con ellos. Acabará con todos los dioses de la tierra, y todas las islas de las naciones se inclinarán ante él, cada una desde su propio lugar.

**12** Ustedes, etíopes, también morirán por mi espada.

**13** Él extenderá su mano hacia el norte y destruirá Asiria. Desolará Nínive; la dejará tan seca como un desierto.

**14** En medio de ella se acostarán las manadas, todo tipo de animales salvajes. Tanto el pelícano como el puercoespín pasarán la noche entre los capiteles de sus columnas. Una voz cantará en la ventana. Habrá ruinas sobre sus umbrales. Él dejará al descubierto los paneles de cedro.

**15** Esta es la orgullosa ciudad que se sentaba confiada, que decía en su corazón: ‘Yo soy única, y no hay nadie más que yo’. ¡Y ahora se ha convertido en un motivo de horror, en un lugar de descanso de animales salvajes! Todo el que pase a su lado silbará y agitará el puño”.

### Notas a pie de página
- **v. 2:** O “el tamo llevado”.
- **v. 3:** O “humildes”.
- **v. 3:** Lit. “su juicio”.
- **v. 3:** O “humildad”.
- **v. 3:** O “Es muy posible que”.
- **v. 4:** O “en pleno mediodía”.
- **v. 7:** O “cuidará de”.
- **v. 11:** O “aterrador”.
- **v. 11:** O “Hará pasar hambre a”.
- **v. 11:** O “lo adorarán”.
- **v. 14:** Lit. “todos los animales de una nación”.

---

## Sofonías 3

**1** ¡Ay de la ciudad rebelde, contaminada y opresiva!

**2** No ha obedecido ninguna voz ni ha aceptado ninguna disciplina. No ha confiado en Jehová ni se ha acercado a su Dios.

**3** En medio de ella sus príncipes son leones rugientes. Sus jueces son lobos que cazan en la noche; no dejan ni un solo hueso para roer al día siguiente.

**4** Sus profetas son insolentes, hombres traicioneros. Sus sacerdotes contaminan lo que es santo; ellos violan la ley.

**5** Jehová es justo en medio de ella; él no hace nada que esté mal. Mañana tras mañana da a conocer sus decisiones judiciales, tal como no falla el amanecer. Pero el injusto no siente vergüenza.

**6** “Arrasé naciones; sus torres de las esquinas quedaron desoladas. Destruí sus calles para que nadie pasara por ellas. Sus ciudades quedaron en ruinas, sin nadie, sin un solo habitante.

**7** ‘Sin duda me temerás y aceptarás la disciplina’, dije yo para que el lugar de su residencia no fuera destruido, pues tengo que pedirle cuentas por todas estas cosas. Pero ellos tenían todavía más ganas de actuar de manera corrupta.

**8** ‘Así que espérenme con paciencia —afirma Jehová— hasta el día en que me levante para saquear, porque mi decisión judicial es reunir naciones, juntar reinos, a fin de derramar sobre ellos mi indignación, toda mi furia ardiente. El fuego de mi celo consumirá toda la tierra.

**9** Y entonces cambiaré el idioma de los pueblos a un idioma puro para que todos ellos puedan invocar el nombre de Jehová y le sirvan hombro a hombro’.

**10** Desde la región de los ríos de Etiopía, los que me suplican, la hija de mis esparcidos, me traerán un regalo.

**11** Ese día no serás avergonzada por todo lo que hiciste para rebelarte contra mí, pues entonces quitaré de en medio de ti a los que presumen con arrogancia; y nunca más mostrarás arrogancia en mi santa montaña.

**12** Dejaré que un pueblo humilde y modesto quede en medio de ti, y ellos se refugiarán en el nombre de Jehová.

**13** Los que queden de Israel no practicarán la injusticia; no dirán mentiras ni tendrán en su boca una lengua que engañe. Se alimentarán y se acostarán, y nadie los asustará”.

**14** ¡Grita de alegría, oh, hija de Sion! ¡Da gritos de triunfo, oh, Israel! ¡Sé feliz y alégrate con todo tu corazón, oh, hija de Jerusalén!

**15** Jehová ha anulado las sentencias que hay contra ti. Ha apartado a tu enemigo. El Rey de Israel, Jehová, está en medio de ti. Nunca más tendrás miedo de la calamidad.

**16** Ese día se le dirá a Jerusalén: “No tengas miedo, oh, Sion. No te desanimes.

**17** Jehová tu Dios está en medio de ti. Como un poderoso guerrero, él salvará. Se alegrará por ti y se sentirá muy feliz. Se quedará en silencio debido a su amor. Estará contento por ti y gritará de felicidad.

**18** Reuniré a los que están tristes por no asistir a tus fiestas; estaban lejos de ti debido a las burlas que soportaban por ella.

**19** ¡Mira! En ese tiempo actuaré en contra de los que te oprimen; salvaré a los que cojean y reuniré a los que están dispersados. Haré que ellos reciban alabanzas y tengan fama en todos los lugares donde los avergonzaron.

**20** En ese tiempo haré que ustedes regresen, en ese tiempo los reuniré. Porque haré que tengas fama y recibas alabanzas en todos los pueblos de la tierra cuando ante tus ojos traiga de vuelta a tus cautivos”, dice Jehová.

### Notas a pie de página
- **v. 7:** O “corrección”.
- **v. 7:** O “castigarla”.
- **v. 8:** O “manténganse en expectación de mí”.
- **v. 8:** O quizás “como testigo”.
- **v. 9:** O “lo adoren en unidad”.
- **v. 13:** O “Pastarán”.
- **v. 16:** O “No dejes caer tus manos”.
- **v. 17:** O “tranquilo”, “en paz”, “satisfecho”.
- **v. 19:** Lit. “un nombre”.
- **v. 20:** Lit. “un nombre”.
