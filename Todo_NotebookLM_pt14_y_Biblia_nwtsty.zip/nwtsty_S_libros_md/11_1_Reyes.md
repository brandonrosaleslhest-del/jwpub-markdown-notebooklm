# Primer Libro de los Reyes (Primero de los Reyes)

---

## Información sobre 1 Reyes

---

**1 REYES**

## CONTENIDO DEL LIBRO

- **1**
  - David y Abisag (1-4)
  - Adonías intenta subir al trono (5-10)
  - Natán y Bat-Seba intervienen (11-27)
  - David ordena que unjan a Salomón (28-40)
  - Adonías huye al altar (41-53)
- **2**
  - David le da instrucciones a Salomón (1-9)
  - David muere; Salomón sube al trono (10-12)
  - El plan de Adonías lo lleva a la muerte (13-25)
  - Se expulsa a Abiatar; matan a Joab (26-35)
  - Matan a Simeí (36-46)
- **3**
  - Salomón se casa con la hija del faraón (1-3)
  - Jehová se le aparece a Salomón en un sueño (4-15)
    - Salomón pide sabiduría (7-9)
  - Salomón juzga el caso de dos madres (16-28)
- **4**
  - La administración del reino de Salomón (1-19)
  - Prosperidad durante su reinado (20-28)
    - Viven seguros bajo la vid y la higuera (25)
  - Sabiduría y proverbios de Salomón (29-34)
- **5**
  - El rey Hiram proporciona materiales de construcción (1-12)
  - Salomón recluta trabajadores (13-18)
- **6**
  - Salomón construye el templo (1-38)
    - El cuarto más interior (19-22)
    - Los querubines (23-28)
    - Las figuras talladas, las puertas, el patio interior (29-36)
    - El templo se termina en unos siete años (37, 38)
- **7**
  - El palacio de Salomón (1-12)
  - Hiram, un trabajador muy hábil, ayuda a Salomón (13-47)
    - Las dos columnas de cobre (15-22)
    - El Mar hecho de metal fundido (23-26)
    - Los 10 carritos y las palanganas de cobre (27-39)
  - Se terminan los muebles y utensilios de oro (48-51)
- **8**
  - Traen el Arca al templo (1-13)
  - Salomón le habla al pueblo (14-21)
  - La oración de Salomón en la dedicación del templo (22-53)
  - Salomón bendice al pueblo (54-61)
  - Los sacrificios y la fiesta de la dedicación (62-66)
- **9**
  - Jehová se le aparece a Salomón de nuevo (1-9)
  - El regalo de Salomón al rey Hiram (10-14)
  - Construcciones de Salomón (15-28)
- **10**
  - La reina de Saba visita a Salomón (1-13)
  - Las riquezas de Salomón (14-29)
- **11**
  - Las esposas de Salomón le desvían el corazón (1-13)
  - Los enemigos de Salomón (14-25)
  - Jeroboán recibirá 10 tribus (26-40)
  - Salomón muere; Rehoboam se convierte en rey (41-43)
- **12**
  - Rehoboam responde con dureza (1-15)
  - Rebelión de las 10 tribus (16-19)
  - Jeroboán se convierte en rey de Israel (20)
  - Rehoboam no debe pelear contra Israel (21-24)
  - Jeroboán hace unos becerros para adorarlos (25-33)
- **13**
  - La profecía contra el altar de Betel (1-10)
    - El altar se parte (5)
  - El hombre de Dios desobedece (11-34)
- **14**
  - La profecía de Ahíya contra Jeroboán (1-20)
  - Rehoboam reina en Judá (21-31)
    - La invasión de Sisac (25, 26)
- **15**
  - Abiyam, rey de Judá (1-8)
  - Asá, rey de Judá (9-24)
  - Nadab, rey de Israel (25-32)
  - Baasá, rey de Israel (33, 34)
- **16**
  - La sentencia de Jehová contra Baasá (1-7)
  - Elá, rey de Israel (8-14)
  - Zimrí, rey de Israel (15-20)
  - Omrí, rey de Israel (21-28)
  - Acab, rey de Israel (29-33)
  - Hiel reconstruye Jericó (34)
- **17**
  - El profeta Elías predice una sequía (1)
  - Es alimentado por cuervos (2-7)
  - Va adonde vive una viuda en Sarepta (8-16)
  - El hijo de la viuda muere y es resucitado (17-24)
- **18**
  - Elías se encuentra con Abdías y Acab (1-18)
  - Se enfrenta a los profetas de Baal en el Carmelo (19-40)
    - “Cojeando entre dos opiniones” (21)
  - La sequía de tres años y medio termina (41-46)
- **19**
  - Elías huye de la furia de Jezabel (1-8)
  - Jehová se le aparece a Elías en Horeb (9-14)
  - Elías debe ungir a Hazael, Jehú y Eliseo (15-18)
  - Eliseo es nombrado sucesor de Elías (19-21)
- **20**
  - Los sirios luchan contra Acab (1-12)
  - Acab vence a los sirios (13-34)
  - Profecía en contra de Acab (35-43)
- **21**
  - Acab quiere quedarse con la viña de Nabot (1-4)
  - Jezabel trama la muerte de Nabot (5-16)
  - Mensaje de Elías contra Acab (17-26)
  - Acab se humilla (27-29)
- **22**
  - La alianza de Jehosafat con Acab (1-12)
  - Micaya profetiza una derrota (13-28)
    - Un espíritu engaña a Acab (21, 22)
  - Matan a Acab en Ramot-Galaad (29-40)
  - El reinado de Jehosafat en Judá (41-50)
  - Ocozías, rey de Israel (51-53)

---

## Primero de los Reyes 1

**1** El rey David ya era mayor, estaba entrado en años, y por más que lo arropaban no se calentaba.

**2** De modo que sus siervos le dijeron: “Hay que buscarle a mi señor el rey una joven, una virgen, para que sea su enfermera y lo atienda. Ella se acostará en los brazos de mi señor el rey para darle calor”.

**3** Así que se pusieron a buscar una joven hermosa por todo el territorio de Israel y encontraron a Abisag la sunamita, y se la trajeron al rey.

**4** La joven, que era bellísima, se convirtió en la enfermera del rey y lo atendía, pero el rey no tuvo relaciones sexuales con ella.

**5** Mientras tanto, Adonías hijo de Haguit se engrandecía diciendo: “¡Yo seré el rey!”. Se mandó hacer un carruaje y se consiguió jinetes y 50 hombres para que fueran corriendo delante de él.

**6** Ahora bien, su padre nunca se había enfrentado a él diciéndole: “¿Por qué has hecho esto?”. Adonías había nacido después de Absalón y también era muy atractivo.

**7** Resulta que Adonías habló con Joab hijo de Zeruyá y con el sacerdote Abiatar, quienes le ofrecieron su ayuda y apoyo.

**8** Pero el sacerdote Sadoc, Benaya hijo de Jehoiadá, el profeta Natán, Simeí, Reí y los guerreros poderosos de David no apoyaron a Adonías.

**9** Tiempo después, Adonías sacrificó animales engordados, ovejas y reses junto a la piedra de Zohélet, que está cerca de En-Roguel. Invitó a todos sus hermanos, los hijos del rey, así como a todos los hombres de Judá, los siervos del rey.

**10** Pero no invitó al profeta Natán ni a Benaya ni a los guerreros poderosos ni a su hermano Salomón.

**11** Entonces Natán le dijo a Bat-Seba, la madre de Salomón: “¿No te has enterado? Adonías hijo de Haguit se convirtió en rey, y nuestro señor David no sabe nada.

**12** Así que ven, por favor, y déjame aconsejarte para que salves tu vida y la de tu hijo Salomón.

**13** Ve a ver al rey David y dile: ‘¿No fuiste tú, mi señor el rey, quien me juró “Tu hijo Salomón será rey después de mí, y será él quien se siente en mi trono”? Entonces, ¿por qué Adonías se ha convertido en rey?’.

**14** Y, mientras todavía estés hablando con el rey, yo llegaré. Entraré después de ti y le confirmaré tus palabras”.

**15** De modo que Bat-Seba fue a ver al rey a su cuarto privado. El rey ya era muy mayor, y Abisag la sunamita lo estaba atendiendo.

**16** Entonces Bat-Seba se inclinó y se postró ante el rey, y el rey le preguntó: “¿Qué deseas?”.

**17** Ella le contestó: “Señor mío, tú fuiste quien me juró por Jehová tu Dios diciéndome ‘Tu hijo Salomón será rey después de mí, y será él quien se siente en mi trono’.

**18** Pero, ¡mira!, Adonías se ha convertido en rey, y mi señor el rey no sabe nada.

**19** Sacrificó muchos toros, animales engordados y ovejas, e invitó a todos los hijos del rey, al sacerdote Abiatar y a Joab, el jefe del ejército; pero no invitó a tu siervo Salomón.

**20** Y ahora los ojos de todo Israel están pendientes de ti, mi señor el rey, para que les digas quién se sentará en el trono después de mi señor el rey.

**21** De lo contrario, en cuanto mi señor el rey descanse con sus antepasados, a mi hijo Salomón y a mí nos verán como traidores”.

**22** Y, mientras ella todavía estaba hablando con el rey, llegó el profeta Natán.

**23** Enseguida le dijeron al rey: “¡El profeta Natán está aquí!”. Él entró adonde estaba el rey y se postró ante él rostro a tierra.

**24** Entonces Natán le dijo: “Mi señor el rey, ¿acaso tú dijiste ‘Adonías será rey después de mí, y será él quien se siente en mi trono’?

**25** Porque hoy bajó para sacrificar muchos toros, animales engordados y ovejas, e invitó a todos los hijos del rey, a los jefes del ejército y al sacerdote Abiatar. Todos están allí, comiendo y bebiendo con él, y no dejan de decir: ‘¡Viva el rey Adonías!’.

**26** Pero a mí, tu siervo, no me invitó, y tampoco invitó al sacerdote Sadoc ni a Benaya hijo de Jehoiadá ni a tu siervo Salomón.

**27** ¿Acaso mi señor el rey ha autorizado esto sin decirle a este siervo suyo quién se sentará en el trono después de él?”.

**28** El rey David contestó: “Llamen a Bat-Seba”. Ella enseguida entró y se quedó de pie ante el rey.

**29** El rey entonces juró: “Tan cierto como que vive Jehová —quien me libró de toda angustia—,

**30** hoy mismo haré lo que juré por Jehová, el Dios de Israel, cuando dije ‘¡Tu hijo Salomón será rey después de mí, y será él quien se siente en mi trono en lugar de mí!’”.

**31** Entonces Bat-Seba se inclinó rostro a tierra, se postró ante el rey y dijo: “¡Que mi señor el rey David viva para siempre!”.

**32** Al instante, el rey David dijo: “Llamen al sacerdote Sadoc, al profeta Natán y a Benaya hijo de Jehoiadá”. Así que ellos entraron adonde estaba el rey.

**33** El rey les dijo: “Llévense a mis siervos con ustedes, hagan que mi hijo Salomón cabalgue en mi mula y bajen con él a Guihon.

**34** El sacerdote Sadoc y el profeta Natán lo ungirán allí como rey de Israel. Después toquen el cuerno y digan: ‘¡Viva el rey Salomón!’.

**35** Y, al regresar, vayan siguiéndolo. Él vendrá y se sentará en mi trono. Será rey en mi lugar, y lo nombraré líder de Israel y de Judá”.

**36** Enseguida Benaya hijo de Jehoiadá le contestó al rey: “¡Amén! Que Jehová, el Dios de mi señor el rey, lo confirme.

**37** Que Jehová esté con Salomón igual que estuvo con mi señor el rey, y que engrandezca su trono más que el trono de mi señor el rey David”.

**38** Entonces el sacerdote Sadoc, el profeta Natán, Benaya hijo de Jehoiadá, los keretitas y los peletitas bajaron e hicieron que Salomón cabalgara en la mula del rey David, y lo llevaron a Guihon.

**39** El sacerdote Sadoc sacó de la tienda el cuerno de aceite y ungió a Salomón. Empezaron a tocar el cuerno, y todo el pueblo se puso a gritar: “¡Viva el rey Salomón!”.

**40** Después de eso, todo el pueblo subió detrás de él tocando la flauta con gran alegría. Era tal el alboroto que la tierra se partía.

**41** Adonías y todos sus invitados ya habían terminado de comer cuando oyeron el alboroto. En cuanto Joab escuchó el sonido del cuerno, dijo: “¿A qué viene ese escándalo en la ciudad?”.

**42** Mientras todavía estaba hablando, llegó Jonatán hijo de Abiatar el sacerdote. Y Adonías le dijo: “Entra, porque eres un hombre bueno, y seguro que traes buenas noticias”.

**43** Pero Jonatán le respondió a Adonías: “¡Todo lo contrario! Nuestro señor el rey David ha hecho rey a Salomón.

**44** El rey envió con él al sacerdote Sadoc, al profeta Natán, a Benaya hijo de Jehoiadá, a los keretitas y a los peletitas, y ellos hicieron que cabalgara en la mula del rey.

**45** Entonces el sacerdote Sadoc y el profeta Natán lo ungieron como rey en Guihon. Después subieron desde allí con alegría, y la ciudad está alborotada. Ese es el bullicio que ustedes oyeron.

**46** Además, Salomón se ha sentado en el trono real.

**47** Y otra cosa: los siervos del rey han ido a felicitar a nuestro señor el rey David. Le dijeron: ‘¡Que tu Dios haga que el nombre de Salomón sea más famoso que el tuyo, y que engrandezca su trono más que el tuyo!’. Entonces el rey se inclinó sobre la cama.

**48** Y el rey también dijo: ‘¡Alabado sea Jehová, el Dios de Israel, que hoy ha permitido que alguien se siente en mi trono y me ha concedido verlo con mis propios ojos!’”.

**49** A todos los invitados de Adonías les entró pánico. Se levantaron y cada uno se fue por su lado.

**50** Adonías también tuvo miedo de Salomón, así que se levantó, fue adonde estaba el altar y se agarró de los cuernos del altar.

**51** A Salomón le informaron: “Adonías tiene miedo del rey Salomón. Se ha agarrado de los cuernos del altar y dice: ‘Que primero me jure el rey Salomón que no matará a espada a este siervo suyo’”.

**52** Al oír esto, Salomón dijo: “Si él se comporta de una manera digna, no se le tocará ni un pelo. Pero, si hace algo malo, tendrá que morir”.

**53** Así que Salomón mandó que lo bajaran del altar. Entonces Adonías fue y se inclinó ante el rey Salomón, y Salomón le dijo: “Vete a tu casa”.

### Notas a pie de página
- **v. 1:** Lit. “días”.
- **v. 6:** O “había herido sus sentimientos”, “lo había reprendido”.
- **v. 29:** O “redimió mi alma”.
- **v. 39:** O “carpa”.
- **v. 42:** O “respetable”.
- **v. 52:** O “ni un solo cabello suyo caerá al suelo”.

---

## Primero de los Reyes 2

**1** Cuando a David le faltaba poco para morir, le dio a su hijo Salomón estas instrucciones:

**2** “Yo estoy a punto de morir, así que sé fuerte y pórtate como un hombre.

**3** Cumple con la obligación que tienes con Jehová tu Dios andando en sus caminos y obedeciendo sus estatutos, sus mandamientos, sus decisiones judiciales y sus recordatorios tal como están escritos en la Ley de Moisés. Así tendrás éxito en todo lo que hagas y dondequiera que vayas.

**4** Y Jehová cumplirá esta promesa que me hizo: ‘Si tus hijos prestan atención a sus pasos andando fielmente en mis caminos con todo su corazón y con toda su alma, siempre habrá un descendiente tuyo sentado en el trono de Israel’.

**5** ”También sabes muy bien lo que me hizo Joab hijo de Zeruyá, lo que les hizo a dos jefes de los ejércitos de Israel: Abner hijo de Ner y Amasá hijo de Jéter. Los mató, y así derramó sangre de guerra en tiempo de paz y manchó con esa sangre el cinturón que llevaba en la cintura y las sandalias de sus pies.

**6** Ahora tú tienes que usar tu sabiduría y no dejar que sus canas bajen en paz a la Tumba.

**7** ”Pero a los hijos de Barzilái el galaadita muéstrales amor leal. Ellos estuvieron a mi lado cuando hui de tu hermano Absalón, así que deberás tenerlos entre los que coman a tu mesa.

**8** ”También está contigo Simeí hijo de Guerá el benjaminita de Bahurim. Fue él quien me maldijo con una cruel maldición el día en que yo iba a Mahanaim. Pero, cuando bajó a mi encuentro al Jordán, le juré por Jehová: ‘No te mataré a espada’.

**9** Ahora tú, que eres un hombre sabio y sabes lo que le debes hacer, no lo dejes sin castigo. Tienes que hacer bajar sus canas con sangre a la Tumba”.

**10** Finalmente David descansó con sus antepasados y lo enterraron en la Ciudad de David.

**11** El tiempo que David reinó sobre Israel fue de 40 años. En Hebrón reinó 7 años, y en Jerusalén reinó 33 años.

**12** Salomón entonces se sentó en el trono de David su padre. Con el tiempo, su reinado llegó a estar firmemente establecido.

**13** Pasado el tiempo, Adonías hijo de Haguit vino a ver a Bat-Seba, la madre de Salomón. Ella le preguntó: “¿Vienes en son de paz?”. Y él le contestó: “Sí, vengo en son de paz”.

**14** Luego añadió: “Tengo algo que decirte”. “Dime”, le dijo ella.

**15** Él continuó: “Tú sabes muy bien que el reinado iba a ser mío, y todos los de Israel esperaban que yo fuera el rey. Pero el reinado se me escapó de las manos y pasó a ser de mi hermano, porque Jehová quiso que fuera suyo.

**16** Y ahora quiero pedirte una sola cosa. No me la niegues”. Ella le contestó: “Dime”.

**17** Entonces él le dijo: “Por favor, pídele al rey Salomón —porque a ti no te lo negará— que me dé por esposa a Abisag la sunamita”.

**18** Bat-Seba le respondió: “De acuerdo. Hablaré por ti con el rey”.

**19** De modo que Bat-Seba se presentó ante el rey Salomón para hablar con él de parte de Adonías. Enseguida el rey se levantó para ir a su encuentro y se inclinó ante ella. Luego se sentó en su trono y mandó traerle un trono a la madre del rey para que ella se sentara a su derecha.

**20** Ella entonces le dijo: “Tengo que pedirte un pequeño favor. No me lo niegues”. Por lo tanto el rey le dijo: “Pídemelo, madre. No te lo voy a negar”.

**21** Ella le dijo: “Deja que a tu hermano Adonías se le dé por esposa a Abisag la sunamita”.

**22** Pero el rey Salomón le respondió a su madre: “¿Por qué pides a Abisag la sunamita para Adonías? Solo falta que pidas también el reinado para él, porque es mi hermano mayor y tiene el apoyo del sacerdote Abiatar y de Joab hijo de Zeruyá”.

**23** Con eso, el rey Salomón juró por Jehová: “Que Dios me castigue severamente si, por haber pedido esto, Adonías no lo paga con su propia vida.

**24** Y ahora, tan cierto como que vive Jehová —que me ha establecido firmemente y me ha sentado en el trono de David mi padre y que me hizo una casa, tal como me prometió—, juro que hoy Adonías morirá”.

**25** Inmediatamente el rey Salomón envió a Benaya hijo de Jehoiadá, quien salió, atacó a Adonías y lo mató.

**26** Al sacerdote Abiatar el rey le dijo: “¡Vete a tus campos en Anatot! Mereces morir, pero no te voy a matar hoy, porque llevaste el Arca del Señor Soberano Jehová delante de David mi padre y porque sufriste junto a mi padre todas sus dificultades”.

**27** De modo que Salomón expulsó a Abiatar para que dejara de ser sacerdote de Jehová y que así se cumplieran las palabras que Jehová había dicho contra la familia de Elí en Siló.

**28** Cuando Joab se enteró de la noticia, huyó a la tienda de Jehová y se agarró de los cuernos del altar (porque, aunque Joab no había apoyado a Absalón, sí había apoyado a Adonías).

**29** Entonces le informaron al rey Salomón: “Joab ha huido a la tienda de Jehová, y ahí está, al lado del altar”. Así que Salomón envió a Benaya hijo de Jehoiadá y le dijo: “¡Ve y mátalo!”.

**30** Benaya fue a la tienda de Jehová y le dijo: “Esto es lo que dice el rey: ‘¡Sal de ahí!’”. Pero él contestó: “¡No! Moriré aquí”. Benaya regresó y le informó al rey lo que Joab le había contestado.

**31** Entonces el rey le dijo: “Haz lo que te dice. Mátalo y entiérralo. Aparta de mí y de la casa de mi padre la sangre que Joab ha derramado injustamente.

**32** Jehová lo hará responsable de su propia muerte porque, sin que David mi padre lo supiera, atacó y mató a espada a dos hombres más justos y mejores que él: Abner hijo de Ner, jefe del ejército de Israel, y Amasá hijo de Jéter, jefe del ejército de Judá.

**33** La culpa de la muerte de ellos recaerá para siempre sobre Joab y sus descendientes; pero que Jehová les dé paz para siempre a David, sus descendientes, su casa y su trono”.

**34** Entonces Benaya hijo de Jehoiadá subió, atacó a Joab y lo mató. Y lo enterraron junto a su propia casa, en el desierto.

**35** Después el rey puso a Benaya hijo de Jehoiadá en el puesto de Joab, al mando del ejército, y al sacerdote Sadoc lo puso en el puesto de Abiatar.

**36** Entonces el rey mandó llamar a Simeí y le dijo: “Hazte una casa en Jerusalén y vive en ella. No salgas de la ciudad a ningún lado.

**37** El día que salgas y cruces el valle de Cedrón, puedes estar seguro de que morirás. Serás responsable de tu propia muerte”.

**38** Simeí le respondió al rey: “Lo que dices es justo. Tu siervo hará lo que mi señor el rey ha dicho”. Así que Simeí se quedó en Jerusalén por un buen tiempo.

**39** Pero, tres años más tarde, dos esclavos de Simeí se escaparon y fueron adonde estaba Akís hijo de Maacá, el rey de Gat. Cuando le avisaron a Simeí “¡Oye! Tus esclavos están en Gat”,

**40** Simeí enseguida ensilló su burro y fue a Gat para ver a Akís y encontrar a sus esclavos. Cuando Simeí regresó de Gat con sus esclavos,

**41** le informaron a Salomón: “Simeí ha salido de Jerusalén. Fue a Gat y volvió”.

**42** Al oír esto, el rey mandó llamar a Simeí y le dijo: “¿No te hice jurar por Jehová y te advertí ‘El día que salgas de aquí a algún lado, puedes estar seguro de que morirás’? ¿Y acaso no me respondiste ‘Lo que dices es justo, te obedeceré’?

**43** Entonces, ¿por qué no cumpliste el juramento que hiciste ante Jehová ni el mandato que te impuse?”.

**44** Después el rey le dijo a Simeí: “Tú sabes en tu corazón todo el mal que le hiciste a David mi padre. Y Jehová hará que el mal que hiciste se vuelva contra ti.

**45** Pero Jehová bendecirá al rey Salomón y establecerá firmemente el trono de David para siempre”.

**46** Con eso, el rey le dio la orden a Benaya hijo de Jehoiadá, quien fue, lo atacó y lo mató. Así el reino fue firmemente establecido en manos de Salomón.

### Notas a pie de página
- **v. 2:** Lit. “Yo me voy por el camino de toda la tierra”.
- **v. 3:** O “actuarás sabiamente”.
- **v. 4:** Ver glosario.
- **v. 4:** Lit. “no será cortado de ti un hombre”.
- **v. 6:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 9:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 11:** Lit. “Los días”.
- **v. 15:** Lit. “habían fijado sus rostros en”.
- **v. 24:** O “dinastía”.
- **v. 25:** O “se lanzó sobre”.
- **v. 27:** Lit. “casa”.
- **v. 32:** Lit. “hará volver su sangre sobre su cabeza”.
- **v. 33:** O “Su sangre volverá sobre la cabeza de Joab y de su descendencia por siempre”.
- **v. 37:** Lit. “Tu sangre estará sobre tu cabeza”.
- **v. 44:** Lit. “sobre tu cabeza”.

---

## Primero de los Reyes 3

**1** Salomón hizo una alianza matrimonial con el faraón, el rey de Egipto. Se casó con la hija del faraón y la llevó a la Ciudad de David en lo que terminaba de construir su propia casa, así como la casa de Jehová y la muralla alrededor de Jerusalén.

**2** Ahora bien, el pueblo seguía haciendo sacrificios en los lugares altos, porque para aquel entonces todavía no se había construido una casa para el nombre de Jehová.

**3** Salomón mostraba que amaba a Jehová al andar según los estatutos de su padre David. Solo que hacía sacrificios y hacía humear las ofrendas en los lugares altos.

**4** El rey fue a Gabaón para ofrecer sacrificios allí, porque aquel era el lugar alto más importante. Salomón ofreció 1.000 sacrificios quemados sobre aquel altar.

**5** En Gabaón, Jehová se le apareció a Salomón de noche en un sueño. “Pídeme lo que quieras”, le dijo Dios.

**6** Salomón respondió: “Tú le demostraste gran amor leal a tu siervo David, mi padre, porque él anduvo en tus caminos con fidelidad, justicia y rectitud de corazón. Has seguido demostrándole ese gran amor leal hasta el día de hoy al haberle dado un hijo que se siente en su trono.

**7** Y ahora, Jehová mi Dios, tú me has hecho rey a mí, tu siervo, en el lugar de David mi padre aunque solo soy un joven inexperto.

**8** Tu siervo está entre tu pueblo, al que tú escogiste, un pueblo tan grande que no se puede numerar ni contar.

**9** Concédele a tu siervo un corazón obediente para juzgar a tu pueblo, para distinguir entre lo bueno y lo malo, porque ¿quién es capaz de juzgar a este pueblo tuyo tan numeroso?”.

**10** A Jehová le gustó que Salomón le pidiera esto.

**11** Entonces Dios le dijo: “Como has pedido esto y no una vida larga ni riquezas ni la muerte de tus enemigos, sino entendimiento para escuchar casos judiciales,

**12** haré lo que pides. Te daré un corazón sabio y capaz de entender. Tanto es así que nunca antes habrá existido alguien como tú ni volverá a existir.

**13** Es más, te daré hasta lo que no has pedido: riquezas y gloria. Mientras vivas, no habrá ningún rey como tú.

**14** Y, si andas en mis caminos obedeciendo mis normas y mis mandamientos —tal como hizo tu padre David—, también te daré una larga vida”.

**15** Cuando Salomón se despertó, se dio cuenta de que aquello había sido un sueño. Entonces fue a Jerusalén, se presentó ante el arca del pacto de Jehová y ofreció sacrificios quemados y ofrendas de paz. También preparó un banquete para todos sus siervos.

**16** En aquel tiempo, dos prostitutas fueron y se presentaron ante el rey.

**17** La primera mujer dijo: “Disculpa, señor mío. Esta mujer y yo vivimos en la misma casa, y yo di a luz mientras ella estaba en la casa.

**18** Al tercer día de dar a luz, esta mujer también dio a luz. Estábamos juntas, las dos solas. No había nadie más con nosotras en la casa.

**19** Durante la noche, el hijo de esta mujer se murió porque ella se acostó encima de él.

**20** Así que ella se levantó a mitad de la noche, se llevó a mi hijo de mi lado mientras tu esclava estaba dormida y lo acostó en sus brazos, y a su hijo muerto lo acostó en los míos.

**21** Cuando me levanté por la mañana para darle el pecho a mi hijo, vi que estaba muerto. Pero entonces me fijé bien en él y descubrí que no era el hijo que yo había dado a luz”.

**22** Pero la otra mujer protestó: “¡No, mi hijo es el que está vivo y tu hijo es el muerto!”. Y la primera mujer decía: “No, tu hijo es el muerto y el mío es el vivo”. Así estuvieron discutiendo delante del rey.

**23** Finalmente el rey dijo: “Esta dice ‘¡Mi hijo es el que está vivo y tu hijo es el muerto!’, y la otra asegura ‘¡No, tu hijo es el muerto y el mío es el vivo!’”.

**24** El rey entonces dijo: “Tráiganme una espada”. Así que le trajeron una espada.

**25** Y el rey ordenó: “Corten al niño vivo en dos, y denle una mitad a una mujer y la otra mitad a la otra”.

**26** Enseguida, la madre del hijo vivo, movida por su instinto maternal, le suplicó al rey: “¡Por favor, señor mío! ¡Que le den a ella el niño vivo! ¡Por lo que más quieras, que no lo maten!”. Pero la otra mujer decía: “¡Ni mío ni tuyo! ¡Que lo corten por la mitad!”.

**27** Al oír esto, el rey dijo: “¡Denle el niño vivo a la primera mujer! No lo maten; ella es su madre”.

**28** Todo Israel se enteró del juicio que el rey había dictado y se quedaron impresionados con el rey, porque vieron que Dios le había dado sabiduría para hacer justicia.

### Notas a pie de página
- **v. 1:** O “Tomó a”.
- **v. 4:** Lit. “gran lugar alto”.
- **v. 7:** Lit. “un muchachito, y no sé salir y entrar”.
- **v. 9:** O quizás “difícil”. Lit. “pesado”.
- **v. 11:** Lit. “muchos días”.
- **v. 13:** Lit. “Todos tus días”.
- **v. 14:** Lit. “alargaré tus días”.
- **v. 15:** O “de comunión”.
- **v. 20:** Lit. “su seno”.
- **v. 28:** Lit. “atemorizados”.

---

## Primero de los Reyes 4

**1** El rey Salomón gobernaba en todo Israel.

**2** Estos eran sus altos funcionarios: Azarías hijo de Sadoc era el sacerdote;

**3** Elihóref y Ahíya, hijos de Sisá, eran secretarios; Jehosafat hijo de Ahilud era el registrador;

**4** Benaya hijo de Jehoiadá estaba al mando del ejército; Sadoc y Abiatar eran sacerdotes;

**5** Azarías hijo de Natán estaba al mando de los comisarios; Zabud hijo de Natán era sacerdote y amigo del rey;

**6** Ahisar estaba a cargo de la casa, y Adoniram hijo de Abdá estaba al mando de los reclutados para trabajo obligatorio.

**7** Salomón tenía 12 comisarios al frente de todo Israel. Ellos proporcionaban alimento al rey y su casa, y cada uno tenía el deber de proporcionarlo un mes al año.

**8** Estos eran sus nombres: el hijo de Hur, en la región montañosa de Efraín;

**9** el hijo de Déquer, en Macaz, en Saalbim, en Bet-Semes y en Elón-Bet-Hanán;

**10** el hijo de Hésed, en Arubot (a él le correspondía Socó y toda la tierra de Héfer);

**11** el hijo de Abinadab, en todas las laderas de Dor (Tafat, hija de Salomón, llegó a ser su esposa);

**12** Baaná hijo de Ahilud, en Taanac, en Meguidó y en todo Bet-Seán, que está al lado de Zaretán, más abajo de Jezreel, desde Bet-Seán hasta Abel-Meholá, hasta la región de Jocmeam;

**13** el hijo de Guéber, en Ramot-Galaad (a él le correspondían las aldeas de tiendas de Jaír hijo de Manasés, que están en Galaad; también le correspondía la región de Argob, que está en Basán: 60 ciudades grandes con murallas y barras de cobre);

**14** Ahinadab hijo de Idó, en Mahanaim;

**15** Ahimáaz, en Neftalí (él se casó con Basemat, otra hija de Salomón);

**16** Baaná hijo de Husái, en Aser y Bealot;

**17** Jehosafat hijo de Parúah, en Isacar;

**18** Simeí hijo de Elá, en Benjamín;

**19** Guéber hijo de Urí, en la tierra de Galaad, es decir, la tierra de Sehón, rey de los amorreos, y de Og, rey de Basán. También había un comisario al mando de todos estos otros comisarios del país.

**20** La gente de Judá e Israel era tan numerosa como los granos de arena que hay junto al mar; comían, bebían y vivían felices.

**21** Salomón tenía bajo su dominio todos los reinos desde el Río hasta la tierra de los filisteos y hasta la frontera de Egipto. Estos reinos le llevaban tributo y le sirvieron todos los días de su vida.

**22** La cantidad de comida que Salomón recibía cada día era de 30 coros de harina fina y 60 coros de harina común,

**23** 10 reses engordadas, 20 reses de pasto y 100 ovejas, además de algunos ciervos, gacelas, corzos y cuclillos engordados.

**24** Él dominaba todo lo que había a este lado del Río, desde Tifsá hasta Gaza, incluidos todos los reyes de este lado del Río. Y disfrutaba de paz en todas las regiones que tenía a su alrededor.

**25** Durante todo el reinado de Salomón, la gente de Judá e Israel vivió segura, cada uno debajo de su propia vid y debajo de su propia higuera, desde Dan hasta Beer-Seba.

**26** Y Salomón tenía en sus establos 4.000 compartimientos para los caballos de sus carros y 12.000 caballos.

**27** Los comisarios les proporcionaban comida al rey Salomón y a todos los que comían a su mesa. Cada uno era responsable del mes que le tocaba y se encargaba de que no faltara nada.

**28** También llevaban cebada y paja, cada uno según su cuota, adonde se necesitara para los caballos, incluidos los caballos de los carros.

**29** Dios le dio a Salomón muchísima sabiduría y discernimiento, y un corazón con tanto entendimiento como la cantidad de arena que hay a la orilla del mar.

**30** La sabiduría de Salomón superaba la sabiduría de todos los orientales y toda la sabiduría de Egipto.

**31** Era más sabio que cualquier otro hombre, más que Etán el ezrahíta y que Hemán, Calcol y Dardá, los hijos de Mahol; y su fama se extendió entre todas las naciones vecinas.

**32** Compuso 3.000 proverbios y 1.005 canciones.

**33** Hablaba acerca de los árboles, desde el cedro del Líbano hasta el hisopo que crece en la pared; hablaba acerca de los animales, las aves, los animales que se arrastran y los peces.

**34** Venía gente de todas las naciones, incluidos reyes de toda la tierra que habían oído hablar de su sabiduría, para escuchar la sabiduría de Salomón.

### Notas a pie de página
- **v. 2:** O “sus príncipes”.
- **v. 10:** O “Socoh”. Ver apén. A2.
- **v. 21:** Es decir, el río Éufrates.
- **v. 22:** Un coro equivalía a 220 L (200 dry qt). Ver apén. B14.
- **v. 23:** O “venados”.
- **v. 26:** Este número aparece en algunos manuscritos y en el relato paralelo. Otros manuscritos dicen 40.000.
- **v. 26:** O “jinetes”.
- **v. 29:** Lit. “una amplitud de corazón”.
- **v. 32:** O “Habló”.
- **v. 33:** O “cuadrúpedos”.
- **v. 33:** O “los animales voladores”.
- **v. 33:** Posiblemente incluyen reptiles e insectos.

---

## Primero de los Reyes 5

**1** Cuando Hiram, el rey de Tiro, se enteró de que Salomón había sido ungido rey como sucesor de su padre, le envió a sus siervos. Y es que Hiram siempre había sido amigo de David.

**2** Entonces Salomón le mandó a Hiram este mensaje:

**3** “Tú bien sabes que David mi padre no pudo construir una casa para el nombre de Jehová su Dios por culpa de las guerras que pelearon contra él desde todos lados, hasta que Jehová puso a sus enemigos debajo de las plantas de sus pies.

**4** Pero ahora Jehová mi Dios me ha dado paz en todos lados. No hay nadie en contra de mí y no está pasando nada malo.

**5** Así que tengo planes de construir una casa para el nombre de Jehová mi Dios, tal como se lo prometió Jehová a David mi padre cuando dijo: ‘Tu hijo, a quien pondré en tu trono en lugar de ti, él es el que construirá la casa para mi nombre’.

**6** Ahora manda a tu gente a que corten cedros del Líbano para mí. Mis siervos trabajarán con los tuyos y yo pagaré el salario de tus siervos, el que tú digas. Porque tú bien sabes que no hay nadie entre nosotros que sepa cortar árboles como los sidonios”.

**7** Cuando Hiram oyó las palabras de Salomón, se alegró mucho y dijo: “¡Alabado sea Jehová hoy, porque le ha dado a David un hijo sabio que gobierne a este gran pueblo!”.

**8** Así que Hiram le mandó decir a Salomón: “Recibí tu mensaje. Haré todo lo que desees, te proporcionaré la madera de cedro y la madera de enebro.

**9** Mis siervos la bajarán del Líbano al mar, y haré que hagan balsas con los troncos para transportarlos por mar hasta el lugar que tú me indiques. Haré que los desaten allí para que tú puedas llevártelos. Y, a cambio, tú me darás el alimento que yo te pida para los de mi casa”.

**10** Así que Hiram le suministró a Salomón toda la madera de cedro y enebro que él quería.

**11** Y cada año Salomón le daba a Hiram 20.000 coros de trigo como provisiones para los de su casa y 20 coros de aceite de oliva de primera calidad.

**12** Jehová le dio a Salomón sabiduría, tal como le había prometido. Hiram y Salomón llegaron a un acuerdo y hubo paz entre ellos.

**13** El rey Salomón reclutó a 30.000 hombres de todo Israel para trabajo obligatorio.

**14** Los enviaba al Líbano en grupos de 10.000 al mes. Estaban un mes en el Líbano y dos meses en sus hogares. Y Adoniram estaba al mando de los reclutados para trabajo obligatorio.

**15** Salomón llegó a tener 70.000 trabajadores comunes y 80.000 picapedreros en las montañas,

**16** además de los 3.300 comisarios principales de Salomón que supervisaban a los trabajadores.

**17** El rey mandó que sacaran de la cantera piedras grandes, piedras costosas, para hacer los cimientos de la casa con piedras labradas.

**18** Así que los obreros de Salomón y de Hiram, junto con los guebalitas, cortaron las piedras y prepararon las maderas y las piedras para construir la casa.

### Notas a pie de página
- **v. 1:** O “había querido a”.
- **v. 4:** Lit. “descanso”.
- **v. 7:** O “numeroso”.
- **v. 11:** Un coro equivalía a 220 L (200 dry qt). Ver apén. B14.
- **v. 11:** O “aceite de aceitunas machacadas”.
- **v. 12:** O “hicieron un pacto”.
- **v. 15:** O “cargadores”.

---

## Primero de los Reyes 6

**1** En el año 480 después de que los israelitas salieron de la tierra de Egipto, en el cuarto año del reinado de Salomón en Israel, en el mes de ziv (es decir, el segundo mes), Salomón empezó a construir la casa de Jehová.

**2** La casa que el rey Salomón le construyó a Jehová medía 60 codos de largo, 20 de ancho y 30 de alto.

**3** El pórtico en la parte delantera del templo tenía el mismo ancho que la casa: 20 codos. El pórtico le añadía 10 codos al largo de la casa.

**4** Él hizo para la casa ventanas con marcos que se estrechaban.

**5** Además, pegada a la pared de la casa, construyó una estructura lateral que rodeaba las paredes de la casa, las del templo y del cuarto más interior, e hizo habitaciones laterales alrededor.

**6** La planta baja de las habitaciones laterales medía 5 codos de ancho, la planta de en medio medía 6 y la tercera medía 7, porque fue escalonando las paredes alrededor de la casa para no fijar las vigas en ellas.

**7** La casa se hizo con piedras de cantera previamente labradas, de modo que no se oyó en la casa el ruido de martillos ni de hachas ni de ninguna herramienta de hierro durante la construcción.

**8** La entrada a la planta baja de las habitaciones laterales estaba al lado sur de la casa. Había una escalera de caracol que iba de allí a la planta de en medio, y de la planta de en medio a la tercera.

**9** Él siguió construyendo la casa, la terminó y le hizo un techo de vigas de cedro e hileras de tablas de cedro.

**10** Construyó las habitaciones laterales alrededor de la casa. Cada una medía 5 codos de alto y estaban unidas a la casa por maderas de cedro.

**11** Por aquel tiempo, Salomón recibió este mensaje de Jehová:

**12** “En cuanto a la casa que estás construyendo, si andas según mis estatutos, si cumples mis decisiones judiciales y si obedeces todos mis mandamientos y vives de acuerdo con ellos, yo cumpliré contigo lo que le prometí a tu padre David

**13** y residiré en medio de los israelitas y no abandonaré a mi pueblo Israel”.

**14** Y Salomón siguió construyendo la casa para terminarla.

**15** Revistió las paredes interiores de la casa con planchas de cedro. Las revistió de madera desde el suelo hasta las vigas del techo, y el suelo de la casa lo recubrió con planchas de enebro.

**16** Y construyó con planchas de cedro una habitación de 20 codos en la parte de atrás de la casa; desde el suelo hasta las vigas. Así construyó en ella el cuarto más interior: el Santísimo.

**17** Y el templo —la parte de la casa que estaba delante— medía 40 codos.

**18** La madera de cedro en el interior de la casa tenía talladas calabazas y flores abiertas. Todo aquello era de cedro; no se veía la piedra.

**19** Y preparó el cuarto más interior dentro de la casa para poner allí el arca del pacto de Jehová.

**20** El cuarto más interior medía 20 codos de largo, 20 codos de ancho y 20 codos de alto, y él lo revistió de oro puro. El altar lo recubrió con madera de cedro.

**21** Salomón revistió de oro puro el interior de la casa y colocó cadenas de oro delante del cuarto más interior, que estaba revestido de oro.

**22** Revistió de oro toda la casa, la casa entera. También revistió de oro todo el altar, que estaba cerca del cuarto más interior.

**23** En el cuarto más interior hizo dos querubines de madera de pino. Cada uno medía 10 codos de alto.

**24** Un ala del querubín medía 5 codos, y la otra también medía 5 codos. Había 10 codos desde la punta de un ala hasta la punta de la otra.

**25** El segundo querubín también medía 10 codos. Los dos querubines tenían el mismo tamaño y la misma forma.

**26** Un querubín medía 10 codos de alto, y el otro también.

**27** Entonces puso los querubines dentro de la casa interior. Las alas de los querubines estaban extendidas de tal manera que el ala de un querubín llegaba a una pared y la del otro querubín llegaba a la otra pared. Las otras dos alas se extendían hacia el centro de la casa y se tocaban entre sí.

**28** Además, revistió de oro los querubines.

**29** Y en todas las paredes de la casa, las del cuarto interior y del cuarto exterior, talló figuras de querubines, de palmeras y de flores abiertas.

**30** El suelo de la casa lo revistió de oro, tanto el del cuarto interior como el del cuarto exterior.

**31** Para la entrada del cuarto más interior, hizo puertas de madera de pino, columnas laterales y los postes de las puertas, como una quinta parte.

**32** Las dos puertas eran de madera de pino, y en ellas talló figuras de querubines, palmeras y flores abiertas. Las revistió de oro y martilló el oro sobre los querubines y las palmeras.

**33** Para la entrada del templo, hizo de la misma manera los postes de madera de pino, que pertenecían a una cuarta parte.

**34** Hizo dos puertas de madera de enebro. Cada puerta tenía dos hojas que giraban sobre pivotes.

**35** Talló figuras de querubines, palmeras y flores abiertas, y las revistió con lámina de oro.

**36** Construyó el muro del patio interior con tres filas de piedras labradas y una hilera de vigas de cedro.

**37** En el cuarto año, en el mes de ziv, se colocaron los cimientos de la casa de Jehová;

**38** y en el año 11, en el mes de bul (es decir, el octavo mes), la casa se terminó con todos sus detalles y de acuerdo con los planos. Le tomó siete años construirla.

### Notas a pie de página
- **v. 1:** Lit. “hijos de Israel”.
- **v. 1:** Ver apén. B15.
- **v. 1:** Ver apén. B8.
- **v. 2:** Un codo equivalía a 44,5 cm (17,5 in). Ver apén. B14.
- **v. 3:** Lit. “templo de la casa”.
- **v. 4:** O “ventanas biseladas (abocinadas)”.
- **v. 5:** Aquí se refiere al Santo.
- **v. 6:** O “fue formando repisas”.
- **v. 8:** Lit. “derecho”.
- **v. 11:** O “la palabra”.
- **v. 15:** Lit. “Construyó”.
- **v. 16:** Es decir, en la casa.
- **v. 17:** Es decir, el Santo, que estaba delante del Santísimo.
- **v. 23:** Lit. “madera oleífera”. Posiblemente, pino de Alepo.
- **v. 27:** Es decir, del Santísimo.
- **v. 29:** Lit. “por dentro y por fuera”.
- **v. 31:** O “las jambas”.
- **v. 31:** Quizás se refiera a la estructura del marco de las puertas o al tamaño de las puertas.
- **v. 33:** Aquí se refiere al Santo.
- **v. 33:** O “las jambas”.
- **v. 33:** Quizás se refiera a la estructura del marco de las puertas o al tamaño de las puertas.
- **v. 37:** Ver apén. B15.
- **v. 38:** Ver apén. B15.

---

## Primero de los Reyes 7

**1** Y a Salomón le tomó 13 años construir su propia casa hasta dejarlo todo terminado.

**2** Construyó la Casa del Bosque del Líbano —que medía 100 codos de largo, 50 codos de ancho y 30 codos de alto— sobre cuatro hileras de columnas de cedro. Y sobre las columnas había vigas de cedro.

**3** Se revistió de cedro la parte superior, por encima de las vigas que se apoyaban en las columnas; había 45 en total, 15 por hilera.

**4** Había tres filas de ventanas con marcos. Cada ventana estaba frente a otra ventana, en tres niveles.

**5** Todas las entradas y los postes de las puertas tenían marcos cuadrados, igual que la parte delantera de las ventanas que estaban unas frente a otras en tres niveles.

**6** Hizo la Sala de las Columnas de 50 codos de largo y 30 codos de ancho. Y delante había un pórtico con columnas y un cobertizo.

**7** También construyó la Sala del Trono —la Sala de Juicio—, donde él juzgaba, y la revistieron de cedro desde el suelo hasta las vigas.

**8** La casa donde iba a vivir, en el otro patio, estaba separada de la Sala y era del mismo estilo. También construyó una casa parecida a esa Sala para la hija del faraón, con quien Salomón se había casado.

**9** Todas estas construcciones —desde los cimientos hasta lo más alto de las paredes, y también la parte exterior, hasta llegar al gran patio— estaban hechas de piedras costosas labradas a medida, cortadas con sierras para piedras, tanto por dentro como por fuera.

**10** Los cimientos eran de piedras costosas muy grandes; algunas piedras medían 10 codos, y otras, 8 codos.

**11** Y encima de estas había piedras costosas, labradas a medida, y también había madera de cedro.

**12** Alrededor del gran patio había un muro de tres filas de piedras labradas y una hilera de vigas de cedro, igual que en el patio interior de la casa de Jehová y el pórtico de la casa.

**13** El rey Salomón mandó traer a Hiram desde Tiro.

**14** Era el hijo de una viuda de la tribu de Neftalí. Su padre, que era de Tiro, era un artesano del cobre; era muy hábil y tenía muchos conocimientos y experiencia en todo tipo de trabajos en cobre. Así que se presentó ante el rey Salomón e hizo todo lo que se le encargó.

**15** Hizo las dos columnas de cobre fundido. Cada columna medía 18 codos de alto y se necesitaba un cordón de medir de 12 codos para rodear cada una de las dos columnas.

**16** También hizo dos capiteles de cobre fundido para ponerlos sobre las columnas. Uno medía cinco codos de alto, y el otro también medía cinco codos de alto.

**17** Los capiteles que estaban sobre las columnas tenían una malla hecha de cadenillas trenzadas; había siete en un capitel y siete en el otro capitel.

**18** E hizo dos hileras de granadas alrededor de cada malla para cubrir los capiteles que estaban sobre las columnas; hizo lo mismo en ambos capiteles.

**19** Los capiteles sobre las columnas del pórtico tenían un diseño de lirio que medía cuatro codos de alto.

**20** Los capiteles estaban sobre las dos columnas, justo encima de la parte redondeada que estaba junto a la malla. Y había 200 granadas en hileras alrededor de cada capitel.

**21** Levantó las columnas del pórtico del templo. Levantó la columna de la derecha, a la que llamó Jakín, y luego levantó la columna de la izquierda, a la que llamó Boaz.

**22** Y la parte superior de las columnas tenía un diseño de lirio. Así se terminaron de hacer las columnas.

**23** Entonces hizo el Mar de metal fundido. Era circular, medía 10 codos de borde a borde, tenía 5 codos de alto y se necesitaba un cordón de 30 codos para rodearlo.

**24** Y debajo de su borde lo rodeaban adornos de calabazas; había 10 por codo y rodeaban todo el Mar; tenía dos filas de calabazas fundidas con él en una sola pieza.

**25** Estaba apoyado en 12 toros: 3 que miraban al norte, 3 que miraban al oeste, 3 que miraban al sur y 3 que miraban al este. El Mar descansaba sobre ellos, y todos estaban de espaldas al centro.

**26** El grosor del Mar era de un palmo menor y su borde era como el borde de una copa, como una flor de lirio. Contenía 2.000 batos de agua.

**27** Entonces hizo los 10 carritos de cobre. Cada carrito medía 4 codos de largo, 4 codos de ancho y 3 codos de alto.

**28** Los carritos estaban hechos de esta manera: tenían paneles a cada lado, y esos paneles estaban entre los travesaños.

**29** Y en los paneles que estaban entre los travesaños había leones, toros y querubines, y ese diseño también estaba en los travesaños. Arriba y abajo de los leones y los toros había relieves de guirnaldas.

**30** Y cada carrito tenía cuatro ruedas de cobre con ejes de cobre, y cuatro piezas en las esquinas que les servían de soporte. Debajo de la palangana estaban los soportes, fundidos con adornos de guirnaldas a los lados.

**31** Su abertura quedaba por dentro de la corona y tenía un codo de alto. La abertura era redonda y junto con los soportes formaba una estructura que medía un codo y medio de alto, y en su boca tenía figuras talladas. Y sus paneles laterales no eran redondos, sino cuadrados.

**32** Las cuatro ruedas estaban por debajo de los paneles laterales, y los soportes de las ruedas estaban unidos al carrito. Cada rueda medía un codo y medio de alto.

**33** Y las ruedas eran como las ruedas de un carro. Sus soportes, aros, rayos y cubos eran de metal fundido.

**34** Había cuatro soportes en las cuatro esquinas de cada carrito. Los soportes formaban una sola pieza con el carrito.

**35** En la parte superior del carrito había una banda circular de medio codo de alto, y los marcos y los paneles laterales de la parte superior del carrito formaban una sola pieza con él.

**36** Sobre sus marcos y sobre sus paneles laterales talló querubines, leones y palmeras según el espacio que había en cada uno, con guirnaldas alrededor.

**37** Así hizo los 10 carritos. Todos fueron fundidos de la misma manera, con la misma medida y forma.

**38** Hizo 10 palanganas de cobre. Cada una tenía una capacidad de 40 batos y medía 4 codos. Había una palangana para cada uno de los 10 carritos.

**39** Entonces puso cinco carritos al lado derecho de la casa y cinco al lado izquierdo. Y puso el Mar al lado derecho de la casa, al sureste.

**40** Hiram también hizo los recipientes, las palas y los tazones. Así Hiram terminó todos los trabajos de la casa de Jehová para el rey Salomón:

**41** las dos columnas y los dos capiteles en forma de tazón sobre las columnas; las dos mallas que cubrían los dos capiteles en forma de tazón sobre las columnas;

**42** las 400 granadas para las dos mallas —dos filas de granadas para cada malla— que cubrían los dos capiteles en forma de tazón sobre las dos columnas;

**43** los 10 carritos y las 10 palanganas sobre los carritos;

**44** el Mar y los 12 toros debajo del Mar;

**45** y los baldes, las palas, los tazones y todos los utensilios, que Hiram hizo de cobre pulido para el rey Salomón, para la casa de Jehová.

**46** El rey mandó que los fundieran en moldes de arcilla en el distrito del Jordán, entre Sucot y Zaretán.

**47** La cantidad de utensilios era tan grande que Salomón no los pesó. No se llegó a saber el peso del cobre.

**48** Salomón hizo todos los utensilios para la casa de Jehová: el altar de oro; la mesa de oro para poner el pan de la presencia;

**49** los candelabros de oro puro, cinco a la derecha y cinco a la izquierda delante del cuarto más interior; las flores, lámparas y despabiladeras de oro;

**50** los recipientes, apagadores, tazones, copas y braserillos de oro puro, y las bases donde se encajaban tanto las puertas de la casa interior, es decir, del Santísimo, como las puertas de la casa del templo, también de oro.

**51** El rey Salomón terminó todo el trabajo que tenía que hacer para la casa de Jehová. Entonces trajo las cosas que su padre David había santificado y guardó la plata, el oro y los objetos en las cámaras del tesoro de la casa de Jehová.

### Notas a pie de página
- **v. 1:** O “propio palacio”.
- **v. 2:** Un codo equivalía a 44,5 cm (17,5 in). Ver apén. B14.
- **v. 5:** O “las jambas”.
- **v. 5:** O “de cuatro lados”, “rectangulares”.
- **v. 6:** O “el Pórtico”.
- **v. 7:** O “el Pórtico”.
- **v. 8:** Lit. “casa de la Sala”.
- **v. 14:** O “bronce”, aquí y en el resto del capítulo.
- **v. 15:** O “cada una de las dos columnas tenía 12 codos de circunferencia”.
- **v. 21:** Aquí se refiere al Santo.
- **v. 21:** O “del sur”.
- **v. 21:** Que significa ‘que él [es decir, Jehová] establezca firmemente’.
- **v. 21:** O “del norte”.
- **v. 21:** Que posiblemente significa ‘con fuerza’.
- **v. 23:** O “depósito”.
- **v. 23:** O “tenía 30 codos de circunferencia”.
- **v. 26:** Unos 7,4 cm (2,9 in). Ver apén. B14.
- **v. 26:** Un bato equivalía a 22 L (5,81 gal). Ver apén. B14.
- **v. 27:** O “carritos para llevar agua”.
- **v. 33:** O “llantas”.
- **v. 34:** O “estaban fundidos”.
- **v. 35:** O “estaban fundidos”.
- **v. 38:** O “4 codos de diámetro”.
- **v. 49:** O “pinzas”.

---

## Primero de los Reyes 8

**1** Por aquel tiempo, Salomón reunió a los ancianos de Israel: a todos los jefes de las tribus y los jefes de las casas paternas de Israel. Vinieron a ver al rey Salomón a Jerusalén para subir el arca del pacto de Jehová desde la Ciudad de David, es decir, Sion.

**2** Todos los hombres de Israel se reunieron delante del rey Salomón durante la fiesta, en el mes de etanim, es decir, el séptimo mes.

**3** Así que todos los ancianos de Israel vinieron, y los sacerdotes levantaron el Arca.

**4** Subieron el Arca de Jehová, la tienda de reunión y todos los utensilios santos que había en la tienda. Los subieron los sacerdotes y los levitas.

**5** El rey Salomón y toda la asamblea de Israel, que fue convocada para reunirse con él, estaban delante del Arca. Las ovejas y las reses que se estaban sacrificando eran tantas que no se podían contar ni numerar.

**6** Entonces los sacerdotes llevaron el arca del pacto de Jehová a su lugar, dentro del cuarto más interior de la casa, el Santísimo, debajo de las alas de los querubines.

**7** Las alas de los querubines estaban extendidas sobre el lugar donde estaba el Arca, de manera que los querubines cubrían el Arca y sus varas.

**8** Las varas eran tan largas que sus puntas se podían ver desde el Santo, delante del cuarto más interior, pero no se podían ver desde fuera. Y allí siguen hasta el día de hoy.

**9** No había nada en el Arca excepto las dos tablas de piedra que Moisés había puesto allí en Horeb, cuando Jehová hizo un pacto con el pueblo de Israel al salir de la tierra de Egipto.

**10** Cuando los sacerdotes salieron del lugar santo, la nube llenó la casa de Jehová.

**11** Los sacerdotes no pudieron quedarse allí para realizar su servicio por causa de la nube, porque la gloria de Jehová llenó la casa de Jehová.

**12** Entonces Salomón dijo: “Jehová dijo que él residiría entre densas nubes.

**13** He logrado construir para ti una casa majestuosa, un lugar permanente donde mores para siempre”.

**14** Luego el rey se dio la vuelta y se puso a bendecir a toda la congregación de Israel, que estaba allí de pie.

**15** Y dijo: “Alabado sea Jehová, el Dios de Israel, quien cumplió con su mano lo que le prometió con su boca a David mi padre:

**16** ‘Desde el día en que saqué de Egipto a mi pueblo Israel, no había escogido ninguna ciudad de todas las tribus de Israel para construir en ella una casa para que mi nombre permanezca allí. Pero ahora he escogido a David para gobernar a mi pueblo Israel’.

**17** Y fue el deseo de corazón de David mi padre construir una casa para el nombre de Jehová, el Dios de Israel.

**18** Pero Jehová le dijo a David mi padre: ‘Deseaste en tu corazón construir una casa para mi nombre, y fue bueno que desearas eso en tu corazón.

**19** Sin embargo, tú no construirás la casa. El hijo que vas a tener es quien construirá la casa para mi nombre’.

**20** Jehová ha cumplido su promesa, porque he sucedido a David mi padre y me siento en el trono de Israel, tal como lo prometió Jehová. También he construido la casa para el nombre de Jehová, el Dios de Israel,

**21** y en ella he preparado un lugar para el Arca, que contiene el pacto que Jehová hizo con nuestros antepasados cuando los sacó de la tierra de Egipto”.

**22** Entonces Salomón se puso de pie frente al altar de Jehová, delante de toda la congregación de Israel. Extendiendo las manos a los cielos,

**23** dijo: “Oh, Jehová, Dios de Israel. No hay ningún Dios como tú arriba en los cielos ni abajo en la tierra. Tú cumples el pacto y les muestras amor leal a tus siervos, los que andan en tus caminos con todo su corazón.

**24** Has cumplido la promesa que le hiciste a tu siervo David, mi padre. Hiciste la promesa con tu boca y hoy la has cumplido con tu mano.

**25** Y ahora, oh, Jehová, Dios de Israel, cumple la promesa que le hiciste a tu siervo David, mi padre, cuando le dijiste: ‘Si tus hijos prestan atención a sus pasos andando en mis caminos como lo has hecho tú, siempre habrá delante de mí un descendiente tuyo que se siente en el trono de Israel’.

**26** Y ahora, oh, Dios de Israel, por favor, que se cumpla la promesa que le hiciste a tu siervo David, mi padre.

**27** ”Pero ¿acaso morará Dios en la tierra? Si ni los cielos, ni siquiera el cielo de los cielos, pueden contenerte, ¡mucho menos esta casa que he construido!

**28** Ahora presta atención a la oración y la súplica de este siervo tuyo. Oh, Jehová mi Dios, escucha los ruegos por ayuda y la oración que tu siervo está haciendo hoy delante de ti.

**29** Que tus ojos miren día y noche esta casa —el lugar del que dijiste ‘Mi nombre estará ahí’— para escuchar la oración que tu siervo haga hacia este lugar.

**30** Y escucha la súplica de tu siervo y las súplicas que haga tu pueblo Israel hacia este lugar. Escúchalas desde tu morada en los cielos. Escúchalas y perdónanos.

**31** ”Si alguien peca contra otra persona y se le obliga a hacer un juramento —y tiene que asumir las consecuencias de ese juramento— y entonces, estando bajo el juramento, se presenta ante tu altar en esta casa,

**32** escúchalo desde los cielos y actúa. Juzga a tus siervos: declara culpable al malo y haz que sus actos recaigan sobre su propia cabeza; declara inocente al justo y recompénsalo de acuerdo con su justicia.

**33** ”Cuando tu pueblo Israel sea derrotado por un enemigo por haber seguido pecando contra ti, y se vuelvan a ti, glorifiquen tu nombre, oren y te supliquen en esta casa,

**34** entonces escúchalos desde los cielos, perdona el pecado de tu pueblo Israel y tráelos de vuelta a la tierra que les diste a sus antepasados.

**35** ”Cuando los cielos estén cerrados y no llueva por haber seguido pecando ellos contra ti, y oren hacia este lugar, glorifiquen tu nombre y dejen su pecado porque tú los volviste humildes,

**36** entonces escúchalos desde los cielos y perdona el pecado de tus siervos, de tu pueblo Israel —porque les enseñarás el buen camino en que deben andar—, y haz llover sobre la tierra que le diste a tu pueblo en herencia.

**37** ”Si en el país hay hambre, una epidemia, un viento abrasador, tizón, plagas de langostas o langostas voraces, o si el enemigo los cerca en alguna de las ciudades del país, o si ocurre cualquier otra clase de plaga o enfermedad,

**38** sea cual sea la oración, sea cual sea la súplica que haga cualquier persona o todo tu pueblo Israel cuando extienda las manos hacia esta casa (porque cada uno sabe cuál es la plaga de su propio corazón),

**39** entonces escucha desde los cielos, desde tu morada, perdónalos y actúa. Págale a cada uno según su conducta, porque tú conoces su corazón (solo tú conoces bien el corazón de cada persona),

**40** para que te teman todos los días que vivan en la tierra que les diste a nuestros antepasados.

**41** ”Además, respecto al extranjero que no es parte de tu pueblo Israel y que viene de una tierra distante por tu nombre

**42** (porque oirán de tu gran nombre, tu poderosa mano y tu poderoso brazo), y viene y ora hacia esta casa,

**43** escúchalo desde los cielos, desde tu morada, y haz todo lo que el extranjero te pida, para que todos los pueblos de la tierra conozcan tu nombre, te teman —como lo hace tu pueblo Israel— y sepan que tu nombre ha sido invocado sobre esta casa que he construido.

**44** ”Si tu pueblo va a la guerra a luchar contra su enemigo por el camino en que los envíes y oran a Jehová en dirección a la ciudad que has escogido y hacia la casa que he construido para tu nombre,

**45** entonces escucha desde los cielos su oración y su súplica, y hazles justicia.

**46** ”Si pecan contra ti (porque no hay nadie que no peque) y tú te enfureces con ellos y los entregas a un enemigo y sus vencedores se los llevan cautivos al país del enemigo, sea lejos o cerca,

**47** y ellos recobran el juicio en el país al que los llevaron cautivos y se vuelven a ti y te suplican en el país de sus vencedores diciendo ‘Hemos pecado y hemos fallado, hemos actuado muy mal’,

**48** y se vuelven a ti con todo su corazón y con toda su alma en el país de los enemigos que se los llevaron cautivos y te oran en dirección a la tierra que les diste a sus antepasados y la ciudad que has escogido y la casa que he construido para tu nombre,

**49** entonces escucha desde los cielos, desde tu morada, la oración y la súplica de ellos, y hazles justicia

**50** y perdona a tu pueblo, que pecó contra ti. Perdona todas las ofensas que cometieron contra ti. Harás que sus vencedores los traten con compasión y les tengan lástima

**51** (porque ellos son tu pueblo y tu herencia, que sacaste de Egipto, del horno para fundir hierro).

**52** Presta atención a la súplica de tu siervo y de tu pueblo Israel, y escúchalos siempre que te llamen.

**53** Porque tú los separaste como herencia tuya de todos los pueblos de la tierra, tal como declaraste mediante tu siervo Moisés cuando sacaste de Egipto a nuestros antepasados, oh, Señor Soberano Jehová”.

**54** En cuanto Salomón acabó de ofrecerle a Jehová toda esta oración y súplica frente al altar de Jehová, se levantó de allí, donde había estado arrodillado con las manos extendidas a los cielos.

**55** Ya de pie, bendijo a toda la congregación de Israel diciendo con voz fuerte:

**56** “Alabado sea Jehová, quien le ha dado a su pueblo Israel un lugar donde descansar, tal como lo prometió. No ha fallado ni una sola palabra de toda la buena promesa que hizo mediante su siervo Moisés.

**57** Que Jehová nuestro Dios esté con nosotros tal como estuvo con nuestros antepasados. Que no nos deje ni nos abandone.

**58** Que atraiga nuestros corazones hacia él, para que andemos en todos sus caminos y obedezcamos los mandamientos, las normas y las decisiones judiciales que mandó obedecer a nuestros antepasados.

**59** Y que Jehová nuestro Dios tenga presentes día y noche estas palabras con las que le he suplicado a Jehová, para que él haga justicia a su siervo y a su pueblo Israel según haga falta cada día.

**60** Así todos los pueblos de la tierra sabrán que Jehová es el Dios verdadero. ¡No hay otro!

**61** Sirvan con un corazón completo a Jehová nuestro Dios andando según sus normas y obedeciendo sus mandamientos como lo están haciendo ahora”.

**62** El rey y todo Israel ofrecieron un gran sacrificio delante de Jehová.

**63** Salomón le ofreció a Jehová los sacrificios de paz: 22.000 reses y 120.000 ovejas. Así el rey y todos los israelitas inauguraron la casa de Jehová.

**64** Aquel día, el rey tuvo que santificar el centro del patio que está delante de la casa de Jehová, porque tuvo que ofrecer allí los sacrificios quemados, las ofrendas de grano y la grasa de los sacrificios de paz. Y es que el altar de cobre que está delante de Jehová era demasiado pequeño para contener los sacrificios quemados, las ofrendas de grano y la grasa de los sacrificios de paz.

**65** En aquella ocasión, Salomón celebró la fiesta delante de Jehová nuestro Dios con todo Israel, una gran congregación de gente que venía de tan lejos como Lebó-Hamat y el torrente de Egipto. La fiesta duró 7 días y después otros 7 días, 14 días en total.

**66** Al día siguiente despidió al pueblo, y ellos bendijeron al rey y se fueron a sus hogares con gran alegría y el corazón contento por toda la bondad que Jehová les había mostrado a su siervo David y a su pueblo Israel.

### Notas a pie de página
- **v. 1:** Lit. “cabezas”.
- **v. 2:** Es decir, la Fiesta de las Cabañas.
- **v. 2:** Ver apén. B15.
- **v. 11:** O “ministrar”.
- **v. 19:** Lit. “Tu hijo, el que saldrá de tus lomos”.
- **v. 31:** O “y esta le impone una maldición”. Es decir, un juramento que conllevaba una maldición como castigo si se juraba falsamente o si no se cumplía.
- **v. 31:** Lit. “la maldición”.
- **v. 31:** Lit. “la maldición”.
- **v. 32:** Lit. “malo”.
- **v. 32:** Lit. “justo”.
- **v. 35:** O “los afligiste”.
- **v. 37:** O “saltamontes”.
- **v. 37:** Lit. “en la tierra de las puertas de él”.
- **v. 38:** O “aflicción”.
- **v. 41:** O “fama”.
- **v. 48:** Ver glosario.
- **v. 52:** Lit. “Que tus ojos estén abiertos”.
- **v. 52:** O “escucha todo lo que te pidan”.
- **v. 61:** O “completamente dedicado”.
- **v. 65:** O “la entrada de Hamat”.
- **v. 65:** O “wadi”.
- **v. 66:** Lit. “octavo”. Es decir, el día después del segundo periodo de 7 días.

---

## Primero de los Reyes 9

**1** En cuanto Salomón terminó de construir la casa de Jehová, la casa del rey y todo lo que quería hacer,

**2** Jehová se le apareció a Salomón por segunda vez, igual que se le había aparecido en Gabaón.

**3** Jehová le dijo: “He oído tu oración y la súplica que hiciste delante de mí. He santificado esta casa que construiste al poner en ella mi nombre de manera permanente, y mis ojos y mi corazón siempre estarán allí.

**4** Y, si tú andas en mis caminos como lo hizo tu padre David, con un corazón íntegro y con rectitud, y haces todo lo que te he mandado y obedeces mis normas y mis decisiones judiciales,

**5** entonces yo estableceré el trono de tu reino sobre Israel para siempre, tal como le prometí a tu padre David cuando dije ‘Siempre habrá un descendiente tuyo sentado en el trono de Israel’.

**6** Pero, si ustedes y sus hijos dejan de seguirme y no obedecen los mandamientos y los estatutos que les he dado, y se van a servir a otros dioses y a inclinarse ante ellos,

**7** entonces eliminaré a Israel de la tierra que les he dado, y quitaré de mi vista la casa que he santificado para mi nombre, e Israel se convertirá en objeto de desprecio y motivo de burla entre todos los pueblos.

**8** Y esta casa llegará a ser un montón de ruinas. Todo el que pase junto a ella se quedará mirando asombrado, silbará y preguntará: ‘¿Por qué Jehová les hizo eso a esta tierra y a esta casa?’.

**9** Entonces responderán: ‘Fue porque abandonaron a Jehová su Dios, quien sacó a sus antepasados de la tierra de Egipto. Se aferraron a otros dioses y se inclinaron ante ellos y les sirvieron. Por eso Jehová les trajo toda esta calamidad’”.

**10** Al cabo de 20 años, en los cuales Salomón construyó las dos casas —la casa de Jehová y la casa del rey—,

**11** el rey Salomón le dio a Hiram, el rey de Tiro, 20 ciudades en la tierra de Galilea. Hiram le había ayudado suministrándole madera de cedro y de enebro, y todo el oro que quiso.

**12** Así que Hiram salió de Tiro para ver las ciudades que Salomón le había dado, pero no le gustaron.

**13** Dijo: “¿Qué ciudades son estas que me diste, mi hermano?”. Por eso las llaman Tierra de Cabul hasta el día de hoy.

**14** Hiram le envió al rey 120 talentos de oro.

**15** Este es el registro de aquellos a los que el rey Salomón reclutó para trabajo obligatorio a fin de construir la casa de Jehová, así como su propia casa, el Montículo, la muralla de Jerusalén, Hazor, Meguidó y Guézer.

**16** (El faraón, rey de Egipto, había subido y conquistado la ciudad de Guézer. La había quemado y también había matado a los cananeos que vivían en ella. De modo que se la dio como regalo de despedida a su hija, la esposa de Salomón).

**17** Salomón reconstruyó Guézer, Bet-Horón Baja,

**18** Baalat, Tamar, en el desierto del país,

**19** así como todas las ciudades de almacenamiento de Salomón, las ciudades de los carros, las ciudades para los jinetes y todo lo que Salomón quiso construir en Jerusalén, en el Líbano y en toda la tierra bajo su dominio.

**20** En cuanto a toda la gente que quedó de los amorreos, los hititas, los perizitas, los heveos y los jebuseos, que no eran parte del pueblo de Israel,

**21** Salomón reclutó a los descendientes de ellos que quedaron en el país —aquellos a quienes los israelitas no habían podido eliminar— para que hicieran trabajos forzados como esclavos, y así siguen hasta el día de hoy.

**22** Pero Salomón no convirtió en esclavo a ningún israelita, pues ellos eran sus guerreros, siervos, príncipes, oficiales y los jefes de sus conductores de carros y de sus jinetes.

**23** Había 550 jefes de los comisarios que supervisaban la obra de Salomón, los capataces de la gente que trabajaba en la obra.

**24** La hija del faraón subió de la Ciudad de David a su propia casa, que Salomón le había hecho. Entonces él construyó el Montículo.

**25** Salomón ofrecía tres veces al año sacrificios quemados y sacrificios de paz en el altar que le había construido a Jehová, y también hacía humo de sacrificio sobre el altar, que estaba delante de Jehová. Así pues, terminó la casa.

**26** El rey Salomón también hizo una flota de barcos en Ezión-Guéber, que está junto a Elot, a la orilla del mar Rojo, en la tierra de Edom.

**27** Hiram mandó a sus propios siervos, marineros de experiencia, con la flota de barcos para trabajar con los siervos de Salomón.

**28** Fueron a Ofir y de allí trajeron 420 talentos de oro y se los entregaron al rey Salomón.

### Notas a pie de página
- **v. 1:** O “el palacio”.
- **v. 7:** Lit. “un proverbio”.
- **v. 12:** Lit. “no fueron apropiadas a sus ojos”.
- **v. 13:** O quizás “Tierra que No Vale Nada”.
- **v. 14:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 15:** O “Miló”. Un término hebreo que significa ‘relleno’.
- **v. 16:** O “regalo de bodas”, “dote”.
- **v. 17:** O “fortificó”.
- **v. 21:** O “entregar a la destrucción”.

---

## Primero de los Reyes 10

**1** La reina de Saba oyó hablar de la fama que Salomón había alcanzado por el nombre de Jehová. Así que vino a ponerlo a prueba con preguntas difíciles.

**2** Llegó a Jerusalén con un séquito muy impresionante, con camellos que traían aceite balsámico, muchísimo oro y piedras preciosas. Se presentó ante Salomón y le dijo todo lo que ella tenía en la mente.

**3** Salomón le contestó todas sus preguntas. No hubo nada demasiado difícil para el rey. Pudo explicárselo todo.

**4** Cuando la reina de Saba vio toda la sabiduría de Salomón, la casa que había construido,

**5** los alimentos de su mesa, la manera como estaban sentados sus siervos, el servicio de los meseros y su atuendo, cuando vio a sus coperos y los sacrificios quemados que él ofrecía con regularidad en la casa de Jehová, ella se quedó sin aliento.

**6** Así que le dijo al rey: “Todo lo que escuché en mi país sobre tus logros y tu sabiduría era cierto.

**7** Pero yo no creí lo que decían hasta que vine y lo vi con mis propios ojos. Y la verdad es que no me habían contado ni la mitad. Tu sabiduría y tu riqueza superan por mucho lo que escuché.

**8** ¡Felices tus hombres y felices tus siervos, que están siempre contigo escuchando tu sabiduría!

**9** Alabado sea Jehová tu Dios, que te vio con agrado y te sentó en el trono de Israel. Por el amor eterno que le tiene a Israel, Jehová te ha nombrado rey para que gobiernes con justicia y rectitud”.

**10** Entonces le dio al rey 120 talentos de oro y una gran cantidad de aceite balsámico y piedras preciosas. Nunca más se llegó a traer tanta cantidad de aceite balsámico como la que la reina de Saba le dio al rey Salomón.

**11** La flota de barcos de Hiram, que traía oro de Ofir, también trajo de Ofir una gran cantidad de madera de sándalo, así como piedras preciosas.

**12** Con la madera de sándalo, el rey hizo postes de baranda para la casa de Jehová y para la casa del rey, y también arpas e instrumentos de cuerda para los cantores. Nunca más se ha traído ni se ha visto una madera de sándalo como esa hasta el día de hoy.

**13** El rey Salomón también le dio a la reina de Saba todo lo que ella quiso y pidió, además de las cosas que su propia generosidad lo motivó a darle. Después de eso, ella se fue y regresó a su país junto con sus siervos.

**14** El peso del oro que el rey Salomón recibía cada año era de 666 talentos de oro,

**15** aparte de lo que recibía de los mercaderes y de las ganancias de los comerciantes, así como de todos los reyes de los árabes y los gobernadores del país.

**16** El rey Salomón hizo 200 escudos grandes de oro aleado (cada escudo tenía 600 siclos de oro)

**17** y 300 escudos pequeños de oro aleado (cada escudo tenía tres minas de oro). Entonces el rey los puso en la Casa del Bosque del Líbano.

**18** Además, el rey hizo un gran trono de marfil y lo revistió de oro refinado.

**19** Había seis escalones para subir al trono, y sobre él había una cubierta redondeada. El asiento tenía un brazo a cada lado, y un león de pie junto a cada brazo.

**20** Y había 12 leones de pie sobre los seis escalones, uno en cada extremo de los seis escalones. Ningún otro reino tenía algo así.

**21** Todas las copas del rey Salomón eran de oro, y todos los utensilios de la Casa del Bosque del Líbano eran de oro puro. No había nada que fuera de plata, porque en los días de Salomón no se le daba ningún valor a la plata.

**22** El rey tenía en el mar una flota de barcos de Tarsis junto con la flota de Hiram. Cada tres años, los barcos de Tarsis venían cargados de oro, plata, marfil, monos y pavos reales.

**23** El rey Salomón era más rico y más sabio que todos los demás reyes de la tierra.

**24** Gente de toda la tierra quería visitar a Salomón para oír la sabiduría que Dios le había puesto en el corazón.

**25** Todos le traían regalos: objetos de plata, objetos de oro, ropa, armas, aceite balsámico, caballos y mulas. Esto sucedía año tras año.

**26** Salomón siguió acumulando carros y caballos. Llegó a tener 1.400 carros y 12.000 caballos, y los tenía estacionados en las ciudades de los carros y en Jerusalén, cerca del rey.

**27** El rey hizo que en Jerusalén la plata fuera tan abundante como las piedras y que la madera de cedro fuera tan abundante como los sicómoros en la Sefelá.

**28** Los caballos de Salomón eran importados de Egipto; los mercaderes del rey compraban caballos por manadas a un precio establecido.

**29** Cada carro importado de Egipto costaba 600 piezas de plata, y cada caballo costaba 150. Entonces los exportaban a todos los reyes de los hititas y los reyes de Siria.

### Notas a pie de página
- **v. 1:** O “Seba”.
- **v. 1:** O “enigmas”.
- **v. 2:** O “una caravana”.
- **v. 2:** O “en el corazón”.
- **v. 3:** Lit. “nada escondido”.
- **v. 5:** Lit. “no hubo más espíritu en ella”.
- **v. 6:** O “palabras”.
- **v. 10:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 12:** O “el palacio”.
- **v. 13:** Lit. “según la mano del rey Salomón”.
- **v. 16:** Un siclo equivalía a 11,4 g (0,367 oz tr). Ver apén. B14.
- **v. 17:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 17:** La mina que se menciona en las Escrituras Hebreas equivalía a 570 g (18,35 oz tr). Ver apén. B14.
- **v. 24:** Lit. “buscaba el rostro de”.
- **v. 26:** O “jinetes”.
- **v. 26:** O “jinetes”.
- **v. 28:** O quizás “de Egipto y de Coa; los mercaderes del rey los compraban de Coa”, que tal vez se refiere a Cilicia.

---

## Primero de los Reyes 11

**1** Pero el rey Salomón amó a muchas extranjeras además de la hija del faraón: mujeres moabitas, ammonitas, edomitas, sidonias e hititas.

**2** Eran de las naciones de las que Jehová les había dicho a los israelitas: “No vayan a mezclarse con ellas, y ellas no deben venir a mezclarse con ustedes, porque les desviarán el corazón para que sigan a sus dioses”. Pero Salomón se apegó a ellas y las amó.

**3** Tuvo 700 esposas, que eran princesas, y 300 concubinas. Y, poco a poco, sus esposas le desviaron el corazón.

**4** Cuando Salomón ya estaba viejo, sus esposas le desviaron el corazón para que siguiera a otros dioses, y no sirvió a Jehová su Dios con un corazón completo como el de su padre David.

**5** Y Salomón siguió a Astoret, la diosa de los sidonios, y a Milcom, el repugnante dios de los ammonitas.

**6** Salomón hizo lo que estaba mal a los ojos de Jehová, y no siguió a Jehová plenamente como su padre David.

**7** Fue entonces cuando Salomón le construyó un lugar alto a Kemós, el repugnante dios de Moab, y otro a Mólek, el repugnante dios de los ammonitas, en la montaña que estaba enfrente de Jerusalén.

**8** Hizo lo mismo por todas las esposas extranjeras de él que hacían humo de sacrificio y les ofrecían sacrificios a sus dioses.

**9** Jehová se puso furioso con Salomón porque su corazón se había desviado y alejado de Jehová, el Dios de Israel, quien se le había aparecido dos veces

**10** y le había advertido precisamente que no siguiera a otros dioses. Pero él no obedeció lo que Jehová había mandado.

**11** Así que Jehová le dijo a Salomón: “Por haber hecho esto, y por no cumplir con mi pacto y con mis estatutos tal como te mandé, puedes estar seguro de que te arrebataré el reino y se lo daré a uno de tus siervos.

**12** Sin embargo, por consideración a tu padre David, no lo haré mientras tú vivas. Se lo arrebataré de las manos a tu hijo.

**13** Pero no le arrebataré todo el reino. Le daré una tribu a tu hijo por consideración a mi siervo David y a Jerusalén, la ciudad que elegí”.

**14** Jehová hizo que a Salomón le saliera un enemigo: Hadad el edomita, de la familia real de Edom.

**15** Cuando David derrotó a Edom, Joab, el jefe del ejército, subió a enterrar a los que habían muerto y trató de acabar con todos los varones de Edom.

**16** (Joab y todo el ejército de Israel se quedaron allí seis meses, hasta que él acabó con todos los varones en Edom).

**17** Pero Hadad huyó con algunos siervos edomitas de su padre, y se fueron a Egipto. Hadad era entonces un niño.

**18** Salieron de Madián y llegaron a Parán. Se llevaron consigo a algunos hombres de Parán y llegaron a Egipto, adonde estaba el faraón, el rey de Egipto, quien le dio a Hadad una casa, alimento y tierras.

**19** Al faraón le cayó tan bien Hadad que le dio como esposa a la hermana de su propia esposa, la reina Tahpenés.

**20** Con el tiempo, la hermana de Tahpenés tuvo un hijo con él, llamado Guenubat, y Tahpenés lo crio en la casa del faraón. Guenubat vivió en la casa del faraón con los hijos del faraón.

**21** Hadad oyó en Egipto que David ya descansaba con sus antepasados y que Joab, el jefe del ejército, había muerto. Así que Hadad le dijo al faraón: “Deja que me vaya a mi tierra”.

**22** Pero el faraón le dijo: “¿Qué te falta aquí conmigo para que ahora quieras irte a tu tierra?”. Él le respondió: “Nada, pero, por favor, deja que me vaya”.

**23** Dios hizo que a Salomón le saliera otro enemigo más: Rezón hijo de Eliadá, que había huido de su señor, Hadadézer, el rey de Zobá.

**24** Cuando David derrotó a los hombres de Zobá, Rezón reunió un grupo de hombres y se convirtió en el jefe de una banda de saqueadores. Ellos se fueron a Damasco, se quedaron a vivir allí y empezaron a reinar en Damasco.

**25** Y él fue enemigo de Israel todos los días de Salomón, y causó otros problemas aparte de los que ya causaba Hadad. Le tuvo mucho odio a Israel durante el tiempo que él reinó sobre Siria.

**26** Jeroboán hijo de Nebat, un efraimita de Zeredá, empezó a rebelarse también contra el rey. Él era un siervo de Salomón, y su madre, que era viuda, se llamaba Zeruá.

**27** La razón por la que se rebeló contra el rey fue la siguiente. Salomón había construido el Montículo y había cerrado la brecha de la Ciudad de David, su padre.

**28** Y resulta que Jeroboán era un hombre muy capaz. Cuando Salomón vio que era un joven trabajador, lo puso a supervisar todo el servicio obligatorio de los de la casa de José.

**29** Por aquel tiempo, Jeroboán salió de Jerusalén, y el profeta Ahíya el silonita lo encontró por el camino. Ahíya llevaba un manto nuevo, y los dos estaban solos en el campo.

**30** Ahíya agarró el manto nuevo que llevaba y lo rasgó en 12 pedazos.

**31** Entonces le dijo a Jeroboán: “Quédate con 10 pedazos, porque esto es lo que ha dicho Jehová, el Dios de Israel: ‘A Salomón le arrancaré de las manos el reino, y a ti te daré 10 tribus.

**32** Pero una tribu seguirá siendo suya por consideración a mi siervo David y a Jerusalén, la ciudad que elegí de todas las tribus de Israel.

**33** Haré esto porque mi pueblo me ha dejado y se está inclinando ante Astoret, la diosa de los sidonios, ante Kemós, el dios de Moab, y ante Milcom, el dios de los ammonitas. Y no ha andado en mis caminos, no ha hecho lo que está bien a mis ojos ni ha obedecido mis estatutos y mis decisiones judiciales como lo hizo David, el padre de Salomón.

**34** Pero no le quitaré de las manos el reino entero a Salomón. Lo mantendré como jefe toda su vida, por consideración a mi siervo David, a quien yo elegí, porque él obedeció mis mandamientos y mis estatutos.

**35** Pero a su hijo le quitaré de las manos el reinado y te lo daré a ti; te daré 10 tribus.

**36** A su hijo le daré una tribu para que mi siervo David siempre tenga una lámpara delante de mí en Jerusalén, la ciudad que yo elegí para poner allí mi nombre.

**37** Te elegiré y tú reinarás sobre todo lo que desees, y serás rey de Israel.

**38** Y, si obedeces todo lo que yo te mande, andas en mis caminos y haces lo que está bien a mis ojos obedeciendo mis estatutos y mis mandamientos, así como lo hizo mi siervo David, entonces yo también estaré contigo. Te haré una casa duradera, igual que a David, y te daré Israel.

**39** Y humillaré a la descendencia de David debido a esto, pero no para siempre’”.

**40** Así que Salomón intentó matar a Jeroboán, pero Jeroboán huyó a Egipto, adonde Sisac, el rey de Egipto, y se quedó en Egipto hasta que Salomón murió.

**41** En cuanto al resto de la historia de Salomón, todo lo que hizo y su sabiduría, está escrito en el libro de la historia de Salomón.

**42** El tiempo que Salomón reinó en Jerusalén sobre todo Israel fue de 40 años.

**43** Entonces Salomón descansó con sus antepasados y fue enterrado en la Ciudad de David, su padre; y su hijo Rehoboam se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 2:** O “No formen matrimonios mixtos con ellas”.
- **v. 2:** O “ellos”, tal vez refiriéndose a los ídolos.
- **v. 3:** O “Y sus esposas tuvieron una fuerte influencia en él”.
- **v. 4:** O “completamente dedicado”.
- **v. 19:** Se refiere a una reina que no gobierna.
- **v. 20:** O quizás “destetó”.
- **v. 24:** Lit. “los mató”.
- **v. 26:** Lit. “alzar su mano”.
- **v. 38:** Se refiere a una dinastía real.
- **v. 42:** Lit. “Los días”.

---

## Primero de los Reyes 12

**1** Rehoboam fue a Siquem, pues todo Israel había venido a Siquem para hacerlo rey.

**2** Y Jeroboán hijo de Nebat se enteró de eso (él seguía en Egipto porque había huido debido al rey Salomón y estaba viviendo en Egipto).

**3** Justo entonces mandaron a buscar a Jeroboán. Después de eso, él y toda la congregación de Israel fueron a ver a Rehoboam y le dijeron:

**4** “Tu padre hizo que nuestro yugo fuera duro. Pero, si tú aligeras el duro servicio y el pesado yugo que nos impuso tu padre, nosotros te serviremos”.

**5** Él les contestó: “Márchense y regresen a verme en tres días”. De modo que la gente se fue.

**6** El rey Rehoboam entonces consultó a los ancianos que le habían servido a su padre Salomón cuando todavía vivía. Les preguntó: “¿Qué me aconsejan que le responda a este pueblo?”.

**7** Ellos le contestaron: “Si hoy te pones al servicio de este pueblo, le haces caso y le das una respuesta favorable, ellos siempre serán tus siervos”.

**8** Sin embargo, él rechazó el consejo que le dieron los ancianos y consultó a los jóvenes que se habían criado con él y que ahora eran sus ayudantes.

**9** Les preguntó: “¿Qué me aconsejan? Esta gente me dijo: ‘Haz más ligero el yugo que tu padre nos impuso’. ¿Qué debemos contestarles?”.

**10** Los jóvenes que se habían criado con él le dijeron: “A esa gente que te ha dicho: ‘Tu padre hizo pesado nuestro yugo; hazlo tú más ligero’, debes contestarle esto: ‘Mi meñique será más grueso que las caderas de mi padre.

**11** Mi padre les impuso a ustedes un yugo pesado, pero yo se lo haré más pesado. Mi padre los castigó con látigos, pero yo los castigaré con látigos de puntas afiladas’”.

**12** Jeroboán y todos los demás fueron a ver a Rehoboam al tercer día, tal como les había indicado el rey cuando dijo “Regresen a verme dentro de tres días”.

**13** Pero el rey le contestó a la gente con dureza, pasando por alto el consejo que le habían dado los ancianos.

**14** Siguiendo el consejo de los jóvenes, les dijo: “Mi padre hizo pesado el yugo de ustedes, pero yo se lo haré más pesado. Mi padre los castigó con látigos, pero yo los castigaré con látigos de puntas afiladas”.

**15** Así que el rey no escuchó al pueblo, porque Jehová hizo que las cosas ocurrieran así, a fin de cumplir las palabras que Jehová le había dicho a Jeroboán hijo de Nebat mediante Ahíya el silonita.

**16** Cuando todo Israel vio que el rey no quiso escucharlos, el pueblo le respondió al rey: “¿Qué tenemos que ver con David? No tenemos ninguna herencia con el hijo de Jesé. Vamos, Israel, vete con tus dioses. ¡David, ocúpate ahora de tu propia casa!”. Entonces los de Israel volvieron a sus hogares.

**17** Pero Rehoboam siguió reinando sobre los israelitas que vivían en las ciudades de Judá.

**18** Entonces el rey Rehoboam les envió a Adoram, que estaba al mando de los reclutados para trabajo obligatorio, pero todo Israel lo mató a pedradas. El rey Rehoboam logró subirse a su carro para huir a Jerusalén.

**19** Y los israelitas han estado en rebelión contra la casa de David hasta el día de hoy.

**20** En cuanto todo Israel oyó que Jeroboán había vuelto, lo convocaron a la asamblea y lo hicieron rey sobre todo Israel. Nadie siguió a los de la casa de David excepto la tribu de Judá.

**21** Cuando Rehoboam llegó a Jerusalén, inmediatamente reunió a toda la casa de Judá y a la tribu de Benjamín, 180.000 guerreros adiestrados, para pelear contra la casa de Israel y devolverle el reinado a Rehoboam hijo de Salomón.

**22** Entonces Semaya, el hombre del Dios verdadero, recibió este mensaje del Dios verdadero:

**23** “Diles a Rehoboam hijo de Salomón —el rey de Judá—, a toda la casa de Judá, a Benjamín y al resto del pueblo:

**24** ‘Esto es lo que dice Jehová: “No suban a pelear contra sus hermanos israelitas. Que cada uno vuelva a su casa, porque yo hice que esto pasara”’”. Así que ellos obedecieron las palabras de Jehová y volvieron a su casa, tal como Jehová les dijo.

**25** Jeroboán entonces reconstruyó Siquem en la región montañosa de Efraín y se quedó a vivir allí. Después salió de allí y reconstruyó Penuel.

**26** Jeroboán dijo en su corazón: “Ahora el reino volverá a la casa de David.

**27** Si la gente sigue subiendo a Jerusalén a ofrecer sacrificios en la casa de Jehová, entonces el corazón de este pueblo volverá con su señor, el rey Rehoboam de Judá. Seguro que me matarán y volverán con el rey Rehoboam de Judá”.

**28** Después de pedir consejo, el rey hizo dos becerros de oro y le dijo al pueblo: “Subir a Jerusalén es demasiado para ustedes. Oh, Israel, aquí está tu Dios, quien te sacó de la tierra de Egipto”.

**29** Entonces puso uno en Betel y otro en Dan.

**30** Esto hizo que ellos pecaran. La gente iba hasta Dan para adorar al becerro que estaba allí.

**31** Y él hizo templos en los lugares altos y puso como sacerdotes a hombres del pueblo que no eran levitas.

**32** Jeroboán también instituyó una fiesta en el octavo mes, en el día 15 del mes, una fiesta como la de Judá. En el altar que hizo en Betel les ofreció sacrificios a los becerros que había hecho. Y nombró sacerdotes en Betel para los lugares altos que había hecho.

**33** El día 15 del octavo mes, el mes que había elegido por su cuenta, empezó a hacer ofrendas en el altar que había hecho en Betel. Instituyó una fiesta para el pueblo de Israel y subió al altar para hacer ofrendas y humo de sacrificio.

### Notas a pie de página
- **v. 4:** O “el opresivo”.
- **v. 6:** Ver glosario.
- **v. 8:** Ver glosario.
- **v. 13:** Ver glosario.
- **v. 16:** Lit. “tiendas”.
- **v. 21:** Lit. “escogidos”.
- **v. 22:** O “la palabra”.
- **v. 25:** O “fortificó”.
- **v. 25:** O “fortificó”.
- **v. 28:** O “terneros”.

---

## Primero de los Reyes 13

**1** Por orden de Jehová, un hombre de Dios vino a Betel desde Judá mientras Jeroboán estaba de pie junto al altar para hacer humo de sacrificio.

**2** Entonces, por orden de Jehová, gritó contra el altar: “¡Oh, altar, altar! Esto es lo que dice Jehová: ‘¡Mira! ¡A la casa de David le nacerá un hijo llamado Josías! Él sacrificará sobre ti a los sacerdotes de los lugares altos que hacen humo de sacrificio sobre ti, y quemará huesos humanos sobre ti’”.

**3** Y aquel día dio una señal cuando dijo: “Esta es la señal que Jehová ha anunciado: el altar se partirá y las cenizas que están sobre él se desparramarán”.

**4** En cuanto el rey oyó las palabras que el hombre del Dios verdadero gritó contra el altar en Betel, Jeroboán quitó la mano del altar y, señalando al hombre, dijo: “¡Agárrenlo!”. Enseguida la mano que había extendido se le paralizó y ya no pudo moverla.

**5** Entonces el altar se partió y las cenizas del altar se desparramaron, según la señal que el hombre del Dios verdadero había dado por orden de Jehová.

**6** El rey ahora le dijo al hombre del Dios verdadero: “Por favor, suplícale a Jehová tu Dios y pídele por mí para que se me cure la mano”. Así que el hombre del Dios verdadero le suplicó a Jehová, y la mano del rey se curó y quedó como antes.

**7** El rey entonces le dijo al hombre del Dios verdadero: “Ven a mi casa y quédate a comer, y déjame hacerte un regalo”.

**8** Pero el hombre del Dios verdadero le dijo al rey: “Aunque me dieras la mitad de tu casa, yo no iría contigo ni comería pan ni bebería agua en este lugar.

**9** Porque recibí esta orden de Jehová: ‘No comas pan ni bebas agua, y no regreses por el camino por donde viniste’”.

**10** Así que se fue por otro camino; no regresó por el camino por donde había venido a Betel.

**11** Y había un profeta ya viejo viviendo en Betel, y sus hijos fueron adonde él y le contaron a su padre todas las cosas que el hombre del Dios verdadero había hecho aquel día en Betel y lo que le había dicho al rey. Después de contarle esto,

**12** su padre les preguntó: “¿Por qué camino se fue?”. Sus hijos le mostraron el camino por donde se fue el hombre del Dios verdadero que había venido de Judá.

**13** Él ahora les dijo a sus hijos: “Prepárenme el burro”. Así que le prepararon el burro y él se montó encima.

**14** Siguió al hombre del Dios verdadero y se lo encontró sentado debajo de un gran árbol. Entonces le dijo: “¿Eres tú el hombre del Dios verdadero que vino de Judá?”. Él le contestó: “Sí, soy yo”.

**15** El profeta viejo le dijo: “Vente a mi casa y come pan”.

**16** Pero él respondió: “No puedo volver contigo ni aceptar tu invitación; tampoco puedo comer pan ni beber agua contigo en este lugar.

**17** Porque recibí esta orden de Jehová: ‘No comas pan ni bebas agua allí. No regreses por el camino por donde viniste’”.

**18** Entonces el otro le contestó: “Yo también soy profeta como tú, y un ángel me dijo por orden de Jehová: ‘Hazlo volver contigo a tu casa para que coma pan y beba agua’”. (Lo engañó).

**19** De modo que regresó con él para comer pan y beber agua en su casa.

**20** Mientras estaban sentados a la mesa, el profeta que lo había traído de vuelta recibió un mensaje de Jehová

**21** y le dijo con voz fuerte al hombre del Dios verdadero que había venido de Judá: “Esto es lo que dice Jehová: ‘Porque te rebelaste contra la orden de Jehová y no obedeciste lo que Jehová tu Dios te mandó,

**22** sino que volviste para comer pan y beber agua en este lugar aunque se te dijo “No comas pan ni bebas agua”, por eso, tu cadáver no será enterrado en la tumba de tus antepasados’”.

**23** Después de que el hombre del Dios verdadero bebió y comió pan, el profeta viejo que lo había traído de vuelta le preparó el burro.

**24** Entonces se fue, pero un león lo sorprendió por el camino y lo mató. Su cadáver quedó tendido en el camino y el burro estaba parado junto a él. El león también estaba parado junto al cadáver.

**25** Unos hombres pasaron por allí y vieron el cadáver tendido en el camino y al león parado junto al cadáver. Entraron en la ciudad donde vivía el profeta viejo y contaron lo que habían visto.

**26** Cuando el profeta que lo había traído de vuelta se enteró de esto, enseguida dijo: “Es el hombre del Dios verdadero que se rebeló contra la orden de Jehová. Y por eso, de acuerdo con las palabras que Jehová le dijo, Jehová se lo entregó al león para que lo atacara y lo matara”.

**27** Entonces les dijo a sus hijos: “Prepárenme el burro”. Y ellos se lo prepararon.

**28** Él se puso en marcha y encontró el cadáver tendido en el camino. El burro y el león estaban parados a su lado, y el león no se había comido el cadáver ni había atacado al burro.

**29** El profeta levantó el cadáver del hombre del Dios verdadero, lo puso en el burro y lo llevó de vuelta a su propia ciudad para hacer duelo por él y enterrarlo.

**30** Así que puso el cadáver en su propia tumba. Lloraban por él diciendo: “¡Qué lástima, hermano mío!”.

**31** Después de enterrarlo, les dijo a sus hijos: “Cuando yo me muera, entiérrenme donde está enterrado el hombre del Dios verdadero. Pongan mis huesos junto a los de él.

**32** Lo que él dijo por orden de Jehová contra el altar de Betel y contra todos los templos de los lugares altos que están en las ciudades de Samaria se cumplirá sin falta”.

**33** Jeroboán no dejó su mal camino, ni siquiera después de que pasó esto. Siguió nombrando a hombres comunes del pueblo para que fueran sacerdotes de los lugares altos. Le daba el puesto de sacerdote a cualquiera que lo quisiera y decía: “Que este sea otro sacerdote para los lugares altos”.

**34** Este pecado de la casa de Jeroboán resultó en que fuera destruida y exterminada de la faz de la tierra.

### Notas a pie de página
- **v. 3:** O “un portento presagioso”.
- **v. 3:** O “Este es el portento presagioso”.
- **v. 3:** O “cenizas grasosas”, es decir, cenizas empapadas en la grasa de los sacrificios.
- **v. 4:** Lit. “secó”.
- **v. 5:** O “el portento presagioso”.
- **v. 6:** O “ablanda el rostro de”.
- **v. 20:** O “la palabra”.
- **v. 33:** Lit. “Llenaba la mano de”.

---

## Primero de los Reyes 14

**1** Por aquel tiempo se enfermó Abías hijo de Jeroboán.

**2** Entonces Jeroboán le dijo a su esposa: “Anda, por favor, disfrázate para que no se den cuenta de que eres la esposa de Jeroboán, y ve a Siló. Allí está el profeta Ahíya. Él es el que dijo que yo sería rey de este pueblo.

**3** Ve a verlo y llévale 10 panes, tortas rociadas y un frasco de miel. Él entonces te dirá lo que le va a pasar al muchacho”.

**4** La esposa de Jeroboán hizo lo que él le dijo. Se fue a Siló y llegó a la casa de Ahíya. Debido a su edad, Ahíya no veía nada; tenía la mirada fija hacia adelante.

**5** Pero Jehová le había dicho a Ahíya: “Por ahí viene la esposa de Jeroboán a consultarte algo sobre su hijo, porque está enfermo. Yo te diré lo que tienes que decirle. Cuando ella llegue, estará disfrazada”.

**6** En cuanto oyó los pasos de ella acercándose a la entrada, Ahíya dijo: “Entra, esposa de Jeroboán. ¿Por qué estás disfrazada? Se me encargó darte un mensaje severo.

**7** Ve y dile a Jeroboán: ‘Esto es lo que dice Jehová, el Dios de Israel: “Yo te elegí de entre tu gente para hacerte líder de mi pueblo Israel.

**8** Entonces le arrebaté el reino a la casa de David y te lo di a ti. Pero tú no has sido como mi siervo David, que obedeció mis mandamientos y me siguió con todo su corazón haciendo solo lo que está bien a mis ojos.

**9** Tú te has portado peor que todos los que hubo antes de ti. Te hiciste otro dios, imágenes de metal para provocarme, y fue a mí a quien le diste la espalda.

**10** ¡Por eso voy a mandarle una calamidad a la casa de Jeroboán! ¡Exterminaré de Israel a todos los hombres de Jeroboán, incluidos los indefensos y los débiles! ¡Barreré por completo a los de la casa de Jeroboán, como se barre el estiércol hasta que no queda nada!

**11** A los de Jeroboán que mueran en la ciudad se los comerán los perros. Y a los que mueran en el campo se los comerán las aves del cielo, porque así lo ha dicho Jehová”’.

**12** ”Ahora vete a tu casa. Cuando pongas el pie en la ciudad, el muchacho morirá.

**13** Todo Israel llorará por él y lo enterrará. Es el único de la familia de Jeroboán que será enterrado en una tumba, porque es el único de la casa de Jeroboán en quien Jehová, el Dios de Israel, ha encontrado algo bueno.

**14** Jehová hará surgir un rey sobre Israel que eliminará la casa de Jeroboán cuando llegue el día, y ese día ya está aquí.

**15** Jehová sacudirá a Israel, que será como una caña agitada por las aguas. Arrancará de raíz a Israel de la buena tierra que les dio a sus antepasados y los dispersará más allá del Río, porque provocaron a Jehová al hacer los postes sagrados.

**16** Y abandonará a Israel por los pecados que Jeroboán cometió e hizo que Israel cometiera”.

**17** Entonces la esposa de Jeroboán se puso en camino y llegó a Tirzá. Al llegar al umbral de su casa, el muchacho murió.

**18** Lo enterraron y todo Israel se puso a llorar por él, de acuerdo con las palabras que Jehová dijo por medio de su siervo, el profeta Ahíya.

**19** El resto de la historia de Jeroboán, de cómo guerreó y reinó, está escrito en el libro de la historia de los reyes de Israel.

**20** El tiempo que Jeroboán reinó fue de 22 años. Después descansó con sus antepasados y su hijo Nadab se convirtió en el nuevo rey.

**21** Por otro lado, Rehoboam hijo de Salomón se había convertido en rey de Judá. Rehoboam tenía 41 años cuando se convirtió en rey, y reinó 17 años en Jerusalén, la ciudad que Jehová eligió de todas las tribus de Israel para poner allí su nombre. La madre de Rehoboam se llamaba Naamá la ammonita.

**22** Judá hacía lo que estaba mal a los ojos de Jehová, y con sus pecados lo provocaron más que sus antepasados.

**23** También siguieron construyéndose lugares altos, columnas sagradas y postes sagrados en todas las colinas altas y debajo de todos los árboles frondosos.

**24** Además, había prostitutos de templo en el país. Hicieron todas las cosas detestables que hacían las naciones que Jehová había expulsado delante de los israelitas.

**25** En el quinto año del rey Rehoboam, el rey Sisac de Egipto subió a atacar Jerusalén.

**26** Se llevó los tesoros de la casa de Jehová y los tesoros de la casa del rey. Se lo llevó todo, incluidos todos los escudos de oro que Salomón había hecho.

**27** Así que el rey Rehoboam hizo escudos de cobre para reemplazarlos y los puso al cuidado de los jefes de la guardia, que vigilaban la entrada de la casa del rey.

**28** Cada vez que el rey venía a la casa de Jehová, los guardias llevaban los escudos y después volvían a ponerlos en el cuarto de los guardias.

**29** El resto de la historia de Rehoboam, todo lo que hizo, está escrito en el libro de la historia de los reyes de Judá.

**30** Siempre hubo guerra entre Rehoboam y Jeroboán.

**31** Entonces Rehoboam descansó con sus antepasados y fue enterrado con sus antepasados en la Ciudad de David. Su madre se llamaba Naamá la ammonita. Y su hijo Abiyam se convirtió en el nuevo rey.

### Notas a pie de página
- **v. 5:** O “Esto y aquello es”.
- **v. 9:** O “estatuas de metal fundido”.
- **v. 10:** Lit. “los que orinan contra la pared”. Expresión hebrea despectiva para referirse a los varones.
- **v. 15:** Es decir, el río Éufrates.
- **v. 15:** Ver glosario.
- **v. 20:** Lit. “Los días”.
- **v. 26:** O “del palacio”.
- **v. 27:** Lit. “de los corredores”.
- **v. 31:** También llamado Abías.

---

## Primero de los Reyes 15

**1** Abiyam se convirtió en rey de Judá en el año 18 del rey Jeroboán hijo de Nebat.

**2** Reinó tres años en Jerusalén, y su madre era Maacá, la nieta de Abisalom.

**3** Él cometió los mismos pecados que había cometido su padre antes que él. No sirvió a Jehová su Dios con un corazón completo como el de su antepasado David.

**4** Aun así, por consideración a David, Jehová su Dios le dio una lámpara en Jerusalén poniendo a su hijo como sucesor y asegurando la existencia de Jerusalén.

**5** Porque David hizo lo que estaba bien a los ojos de Jehová y no se desvió de nada de lo que le mandó durante todos los días de su vida, salvo por lo de Urías el hitita.

**6** Hubo guerra entre Rehoboam y Jeroboán todos los días de su vida.

**7** En cuanto al resto de la historia de Abiyam, todo lo que hizo, está escrito en el libro de la historia de los reyes de Judá. Entre Abiyam y Jeroboán también hubo guerra.

**8** Entonces Abiyam descansó con sus antepasados y lo enterraron en la Ciudad de David, y su hijo Asá se convirtió en el nuevo rey.

**9** Asá empezó a reinar sobre Judá en el año 20 del rey Jeroboán de Israel.

**10** Reinó en Jerusalén 41 años. Su abuela era Maacá, la nieta de Abisalom.

**11** Asá hizo lo que estaba bien a los ojos de Jehová, como su antepasado David.

**12** Expulsó del país a los prostitutos de templo y quitó todos los ídolos repugnantes que habían hecho sus antepasados.

**13** Incluso le quitó el puesto de reina madre a su abuela Maacá, porque ella había hecho un ídolo obsceno para la adoración del poste sagrado. Asá derribó su ídolo obsceno y lo quemó en el valle de Cedrón.

**14** Pero no se quitaron los lugares altos. Aun así, Asá sirvió a Jehová con un corazón completo toda su vida.

**15** Y trajo a la casa de Jehová las cosas que él y su padre habían santificado: plata, oro y diversos utensilios.

**16** Siempre hubo guerra entre Asá y Baasá, el rey de Israel.

**17** El rey Baasá de Israel fue contra Judá y se puso a fortificar Ramá para no dejar que nadie saliera del territorio del rey Asá de Judá ni entrara en él.

**18** Ante eso, Asá se llevó toda la plata y el oro que quedaban en las cámaras del tesoro de la casa de Jehová y en las cámaras del tesoro de la casa del rey y se los dio a sus siervos. Luego, el rey Asá los envió a Ben-Hadad —hijo de Tabrimón, hijo de Hezión—, el rey de Siria, que estaba viviendo en Damasco. Y le dijo:

**19** “Hay un acuerdo entre tú y yo, y entre tu padre y mi padre. Aquí te envío un regalo de plata y oro. Vamos, rompe tu acuerdo con el rey Baasá de Israel para que se aleje de mí”.

**20** Ben-Hadad le hizo caso al rey Asá y envió a los jefes de sus ejércitos a atacar las ciudades de Israel, y ellos conquistaron Ijón, Dan, Abel-Bet-Maacá, todo Kinéret y toda la tierra de Neftalí.

**21** Cuando Baasá se enteró, enseguida dejó de fortificar Ramá y se quedó en Tirzá.

**22** El rey Asá convocó a todo Judá, sin excepción, y se llevaron de Ramá las piedras y la madera que Baasá había usado para construir, y con ellas el rey Asá fortificó Gueba de Benjamín y también Mizpá.

**23** En cuanto a todo el resto de la historia de Asá, todo su poder, todo lo que hizo y las ciudades que construyó, está escrito en el libro de la historia de los reyes de Judá. Pero ya de viejo le dio una enfermedad en los pies.

**24** Entonces Asá descansó con sus antepasados y fue enterrado con ellos en la Ciudad de David, su antepasado, y su hijo Jehosafat se convirtió en el nuevo rey.

**25** Nadab hijo de Jeroboán llegó a ser rey de Israel en el segundo año del rey Asá de Judá, y reinó sobre Israel por dos años.

**26** Hacía lo que estaba mal a los ojos de Jehová. Siguió los pasos de su padre y cometió sus mismos pecados, los que él había hecho que Israel cometiera.

**27** Cuando Nadab y todo Israel estaban cercando Guibetón, Baasá hijo de Ahíya de la casa de Isacar conspiró contra Nadab y lo mató en Guibetón, que pertenecía a los filisteos.

**28** Baasá lo mató en el tercer año del rey Asá de Judá y se convirtió en el nuevo rey.

**29** Y, en cuanto llegó a ser rey, mató a todos los de la casa de Jeroboán; no dejó que quedara ninguno de ellos con vida. Los aniquiló de acuerdo con las palabras que Jehová había dicho por medio de su siervo Ahíya el silonita.

**30** Esto pasó por los pecados que Jeroboán había cometido y había hecho que Israel cometiera, y por lo mucho que había enfurecido a Jehová, el Dios de Israel.

**31** En cuanto al resto de la historia de Nadab, todo lo que hizo, está escrito en el libro de la historia de los reyes de Israel.

**32** Y siempre hubo guerra entre Asá y el rey Baasá de Israel.

**33** Baasá hijo de Ahíya llegó a ser rey de todo Israel en Tirzá en el tercer año del rey Asá de Judá, y reinó por 24 años.

**34** Pero hacía lo que estaba mal a los ojos de Jehová. Siguió los pasos de Jeroboán y cometió sus mismos pecados, los que él había hecho que Israel cometiera.

### Notas a pie de página
- **v. 3:** O “completamente dedicado”.
- **v. 12:** El término hebreo podría estar relacionado con una palabra para “estiércol”. Se usa como una expresión de desprecio.
- **v. 13:** O “de dama”.
- **v. 14:** O “completamente dedicado”.
- **v. 14:** Lit. “todos sus días”.
- **v. 17:** O “reconstruir”.
- **v. 18:** O “del palacio”.
- **v. 19:** O “pacto”.
- **v. 21:** O “reconstruir”.
- **v. 22:** O “reconstruyó”.
- **v. 23:** O “fortificó”, “reconstruyó”.
- **v. 29:** O “ninguno que respira”.

---

## Primero de los Reyes 16

**1** Jehú hijo de Hananí entonces recibió este mensaje de Jehová en contra de Baasá:

**2** “Te levanté del polvo y te convertí en líder de mi pueblo Israel, pero seguiste los pasos de Jeroboán e hiciste pecar a mi pueblo Israel, de modo que me provocaron con sus pecados.

**3** Por eso voy a barrer por completo a Baasá y a los de su casa, y dejaré su casa como la de Jeroboán hijo de Nebat.

**4** A los de Baasá que mueran en la ciudad se los comerán los perros. Y a los suyos que mueran en el campo se los comerán las aves del cielo”.

**5** En cuanto al resto de la historia de Baasá, de lo que hizo y de su poder, está escrito en el libro de la historia de los reyes de Israel.

**6** Entonces Baasá descansó con sus antepasados y fue enterrado en Tirzá, y su hijo Elá se convirtió en el nuevo rey.

**7** Y por medio del profeta Jehú hijo de Hananí llegó el mensaje de Jehová en contra de Baasá y los de su casa, tanto por toda la maldad que él cometió a los ojos de Jehová —al provocarlo con sus obras y volverse igual que los de la casa de Jeroboán— como también por haberlo matado.

**8** Elá hijo de Baasá llegó a ser rey de Israel en Tirzá en el año 26 del rey Asá de Judá, y reinó por dos años.

**9** Su siervo Zimrí, el jefe de la mitad de sus carros de guerra, conspiró en su contra mientras él estaba en Tirzá emborrachándose en la casa de Arzá, quien era el encargado de la casa del rey en Tirzá.

**10** Zimrí entró, lo atacó y lo mató en el año 27 del rey Asá de Judá, y se convirtió en el nuevo rey.

**11** En cuanto se convirtió en rey y se sentó en su trono, mató a todos los de la casa de Baasá. No dejó que quedara vivo ningún hombre, ya fuera pariente o amigo.

**12** Así Zimrí aniquiló a todos los de la casa de Baasá, de acuerdo con las palabras que Jehová había dicho contra Baasá mediante el profeta Jehú.

**13** Esto sucedió por todos los pecados que Baasá y su hijo Elá habían cometido y los que habían hecho que Israel cometiera al provocar con sus ídolos inútiles a Jehová, el Dios de Israel.

**14** En cuanto al resto de la historia de Elá, todo lo que hizo, está escrito en el libro de la historia de los reyes de Israel.

**15** En el año 27 del rey Asá de Judá, Zimrí llegó a ser rey por siete días en Tirzá mientras las tropas estaban acampadas para luchar contra Guibetón, que pertenecía a los filisteos.

**16** Entonces los soldados que acampaban allí oyeron que se decía: “Zimrí ha conspirado contra el rey y lo ha matado”. Así que aquel día en el campamento todo Israel hizo a Omrí —el jefe del ejército— rey de Israel.

**17** Omrí y todo Israel subieron desde Guibetón y cercaron Tirzá.

**18** Cuando Zimrí vio que habían tomado la ciudad, se metió en la torre fortificada de la casa del rey, le prendió fuego a la casa, se quedó dentro y murió.

**19** Esto sucedió por los pecados que él mismo había cometido al hacer lo que estaba mal a los ojos de Jehová y seguir los pasos de Jeroboán, y por los pecados que había hecho que Israel cometiera.

**20** En cuanto al resto de la historia de Zimrí y su conspiración, está escrito en el libro de la historia de los reyes de Israel.

**21** Fue entonces cuando el pueblo de Israel se dividió en dos bandos. Una parte del pueblo seguía a Tibní hijo de Guinat y quería hacerlo rey, y la otra parte seguía a Omrí.

**22** Pero los que seguían a Omrí vencieron a los que seguían a Tibní hijo de Guinat. Al final, Tibní murió y Omrí se convirtió en rey.

**23** Omrí llegó a ser rey de Israel en el año 31 del rey Asá de Judá, y reinó por 12 años. En Tirzá reinó seis años.

**24** Le compró a Sémer la montaña de Samaria por dos talentos de plata y construyó una ciudad en la montaña. Llamó a la ciudad Samaria en honor a Sémer, el dueño de la montaña.

**25** Omrí hacía lo que estaba mal a los ojos de Jehová y fue peor que todos los que hubo antes de él.

**26** Siguió los mismos pasos de Jeroboán hijo de Nebat y cometió los mismos pecados que él había hecho que Israel cometiera al provocar con sus ídolos inútiles a Jehová, el Dios de Israel.

**27** En cuanto al resto de la historia de Omrí, lo que hizo y sus grandes hazañas, está escrito en el libro de la historia de los reyes de Israel.

**28** Entonces Omrí descansó con sus antepasados y fue enterrado en Samaria, y su hijo Acab se convirtió en el nuevo rey.

**29** Acab hijo de Omrí llegó a ser rey de Israel en el año 38 del rey Asá de Judá, y Acab hijo de Omrí reinó sobre Israel desde Samaria por 22 años.

**30** Acab hijo de Omrí fue peor a los ojos de Jehová que todos los que hubo antes de él.

**31** Y, por si no fuera suficiente con haber cometido los mismos pecados de Jeroboán hijo de Nebat, se casó con Jezabel hija de Etbaal, el rey de los sidonios, y se puso a servir a Baal y a inclinarse ante él.

**32** Además, le hizo un altar a Baal en el templo de Baal que construyó en Samaria.

**33** Acab también hizo el poste sagrado. Hizo más cosas para provocar a Jehová, el Dios de Israel, que todos los reyes de Israel que hubo antes de él.

**34** En los días de Acab, Hiel el betelita reconstruyó Jericó. Colocó sus cimientos a costa de la vida de Abiram, su hijo mayor, y puso sus puertas a costa de la vida de Segub, el menor, de acuerdo con las palabras que Jehová había dicho por medio de Josué hijo de Nun.

### Notas a pie de página
- **v. 1:** O “la palabra”.
- **v. 6:** O “Elah”. Ver apén. A2.
- **v. 7:** O “la palabra”.
- **v. 7:** Es decir, a Nadab, el hijo de Jeroboán.
- **v. 8:** O “Elah”. Ver apén. A2.
- **v. 11:** Lit. “ninguno que orina contra la pared”. Expresión hebrea despectiva para referirse a los varones.
- **v. 11:** O “vengador de sangre”.
- **v. 13:** O “Elah”. Ver apén. A2.
- **v. 14:** O “Elah”. Ver apén. A2.
- **v. 18:** O “del palacio”.
- **v. 24:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 24:** Que significa ‘perteneciente al clan de Sémer’.
- **v. 24:** Lit. “señor”.
- **v. 32:** Lit. “la casa”.

---

## Primero de los Reyes 17

**1** Elías el tisbita, un habitante de Galaad, le dijo a Acab: “¡Tan cierto como que vive Jehová, el Dios de Israel, a quien yo sirvo, no habrá ni rocío ni lluvia durante estos años, a menos que yo lo ordene!”.

**2** Y Elías recibió este mensaje de Jehová:

**3** “Sal de aquí, dirígete hacia el este y escóndete junto al valle de Kerit, al este del Jordán.

**4** Beberás agua del arroyo, y yo les ordenaré a los cuervos que te lleven comida allí”.

**5** Él se fue inmediatamente y actuó de acuerdo con las palabras de Jehová. Se fue y se quedó junto al valle de Kerit, al este del Jordán.

**6** Los cuervos le traían pan y carne por la mañana, y pan y carne al atardecer, y él bebía agua del arroyo.

**7** Pero al cabo de unos días el arroyo se secó porque no llovía en el país.

**8** Entonces recibió este mensaje de Jehová:

**9** “Ve a Sarepta, que pertenece a Sidón, y quédate allí. Yo le ordenaré allí a una viuda que te dé de comer”.

**10** Así que él se fue a Sarepta. Cuando llegó a la entrada de la ciudad, se encontró a una viuda recogiendo leña. La llamó y le dijo: “Por favor, tráeme un vasito de agua para beber”.

**11** Cuando fue a buscárselo, la llamó y le dijo: “Por favor, tráeme también un pedazo de pan”.

**12** Ella le respondió: “Te juro que, tan cierto como que vive Jehová tu Dios, no tengo pan. Lo único que tengo es un puñado de harina en el jarro grande y un poquito de aceite en el jarro pequeño. Ahora estoy recogiendo un poco de leña para entrar a preparar algo para mi hijo y para mí. Será nuestra última comida y después nos moriremos”.

**13** Entonces Elías le dijo: “No tengas miedo. Entra a hacer lo que dijiste. Pero primero hazme un pequeño pan redondo con lo que haya y tráemelo acá afuera. Luego puedes preparar algo para tu hijo y para ti.

**14** Porque esto es lo que dice Jehová, el Dios de Israel: ‘La harina del jarro grande no se acabará y el aceite del jarro pequeño no se terminará hasta el día en que Jehová haga llover sobre el suelo’”.

**15** Así que hizo lo que Elías le dijo, y tanto él como ella y su familia tuvieron comida por muchos días.

**16** La harina del jarro grande no se acabó y el aceite del jarro pequeño no se terminó, de acuerdo con las palabras que Jehová había dicho por medio de Elías.

**17** Tiempo después, el hijo de la dueña de la casa se enfermó, y empeoró tanto que dejó de respirar.

**18** Ante esto, ella le dijo a Elías: “¿Qué tienes en contra de mí, hombre del Dios verdadero? ¿Has venido para recordarme mi culpa y para matar a mi hijo?”.

**19** Pero él le dijo: “Dame a tu niño”. Entonces lo tomó de los brazos de ella y lo llevó a la habitación de la azotea, donde él se estaba quedando, y lo acostó en su propia cama.

**20** Y le rogó a Jehová: “Oh, Jehová mi Dios, ¿vas a hacer sufrir incluso a la viuda con la que me estoy hospedando, haciendo que muera su hijo?”.

**21** Entonces se extendió sobre el niño tres veces y le suplicó a Jehová: “Oh, Jehová mi Dios, devuélvele la vida a este niño, por favor”.

**22** Jehová escuchó la súplica de Elías, así que la vida del niño volvió a él y el niño revivió.

**23** Elías tomó al niño, lo bajó de la habitación de la azotea y lo metió en la casa. Se lo llevó a su madre y le dijo: “Mira, tu hijo está vivo”.

**24** Al ver esto, la mujer le dijo a Elías: “Ahora sé que tú eres realmente un hombre de Dios y que las palabras de Jehová que salen de tu boca son verdad”.

### Notas a pie de página
- **v. 1:** Que significa ‘mi Dios es Jehová’.
- **v. 1:** Lit. “ante quien estoy de pie”.
- **v. 2:** O “la palabra”.
- **v. 3:** O “wadi de Kerit”.
- **v. 8:** O “la palabra”.
- **v. 18:** O “Qué tengo que ver contigo”.
- **v. 19:** O “terraza”.

---

## Primero de los Reyes 18

**1** Algún tiempo después, en el tercer año, Elías recibió este mensaje de Jehová: “Ve a presentarte ante Acab, y yo haré que llueva sobre el suelo”.

**2** Así que Elías fue a presentarse ante Acab. El hambre en Samaria era terrible.

**3** Entretanto, Acab llamó a Abdías, que era el encargado de la casa. (Resulta que Abdías temía mucho a Jehová.

**4** Cuando Jezabel estaba matando a los profetas de Jehová, Abdías escondió a 100 profetas en cuevas. Puso a 50 en una y a 50 en otra, y se encargó de darles pan y agua).

**5** Entonces Acab le dijo a Abdías: “Recorre el país y ve a todos los manantiales y a todos los valles. Tal vez encontremos suficiente pasto para que los caballos y las mulas sigan viviendo y que no se nos mueran todos los animales”.

**6** Así que se repartieron las tierras que iban a recorrer. Acab se fue él solo por un camino y Abdías se fue solo por otro.

**7** Mientras Abdías iba por el camino, Elías vino a su encuentro. Abdías enseguida lo reconoció, cayó rostro a tierra y le dijo: “Mi señor Elías, ¿eres tú?”.

**8** Él le respondió: “Sí, soy yo. Ve a decirle a tu señor: ‘Elías está aquí’”.

**9** Pero Abdías le dijo: “¿Qué pecado ha cometido este siervo tuyo para que me entregues en manos de Acab y entonces me mate?

**10** Tan cierto como que vive Jehová tu Dios, no hay nación ni reino adonde mi señor no haya mandado a alguien a buscarte. Y, cada vez que decían ‘No está aquí’, el rey hacía que ese reino o nación jurara que no había podido encontrarte.

**11** Y ahora tú vienes y me dices: ‘Ve a decirle a tu señor: “Elías está aquí”’.

**12** Cuando me vaya, el espíritu de Jehová te llevará no sé adónde, y, si le aviso a Acab y él no te encuentra, seguro que me mata. Pero este siervo tuyo ha temido a Jehová desde joven.

**13** Mi señor, ¿es que no te han contado lo que hice cuando Jezabel estaba matando a los profetas de Jehová? ¿No te dijeron que escondí en cuevas a 100 profetas de Jehová en grupos de 50, y que me encargaba de darles pan y agua?

**14** Y ahora tú vienes y me dices: ‘Ve a decirle a tu señor: “Elías está aquí”’. Seguro que me mata”.

**15** Sin embargo, Elías le dijo: “Tan cierto como que vive Jehová de los ejércitos, a quien yo sirvo, te juro que hoy me presentaré ante Acab”.

**16** De modo que Abdías fue a ver a Acab y le avisó. Y Acab fue a encontrarse con Elías.

**17** En cuanto Acab vio a Elías, le dijo: “¡Aquí estás! ¡Tú, el que le está causando tanto daño a Israel!”.

**18** Él contestó: “Yo no le he causado daño a Israel. Han sido tú y los de la casa de tu padre. Ustedes dejaron a un lado los mandamientos de Jehová y siguieron a los Baales.

**19** Ahora convoca a todo Israel, así como a los 450 profetas de Baal y a los 400 profetas del poste sagrado, que están comiendo a la mesa de Jezabel, para que se reúnan conmigo en el monte Carmelo”.

**20** Por lo tanto, Acab envió mensajeros a todo el pueblo de Israel y reunió a los profetas en el monte Carmelo.

**21** Entonces Elías se acercó a todo el pueblo y dijo: “¿Hasta cuándo estarán cojeando entre dos opiniones? ¡Si Jehová es el Dios verdadero, síganlo a él! ¡Pero, si Baal lo es, síganlo a él!”. Pero el pueblo no le contestó ni una sola palabra.

**22** Luego Elías le dijo al pueblo: “Soy el único profeta de Jehová que queda, mientras que hay 450 profetas de Baal.

**23** Que nos den dos toros jóvenes y que ellos elijan uno, lo descuarticen y lo pongan en la leña. Sin embargo, no deben prenderle fuego. Yo prepararé el otro toro y lo pondré en la leña sin prenderle fuego.

**24** Después ustedes invocarán el nombre de su dios y yo invocaré el nombre de Jehová. El Dios que responda mandando fuego demostrará que es el Dios verdadero”. Y todo el pueblo contestó: “Está bien”.

**25** Elías ahora les dijo a los profetas de Baal: “Elijan un toro joven y prepárenlo ustedes primero, pues ustedes son la mayoría. Entonces invoquen el nombre de su dios. Pero no le vayan a prender fuego”.

**26** Así que ellos agarraron el toro joven que se les dio, lo prepararon e invocaron el nombre de Baal desde la mañana hasta el mediodía. Decían: “¡Oh, Baal, respóndenos!”. Pero no se oyó ni una voz ni nadie que respondiera. Ellos no dejaban de bailar cojeando alrededor del altar que habían hecho.

**27** Como al mediodía, Elías empezó a burlarse de ellos y a decir: “¡Griten lo más alto que puedan porque, después de todo, es un dios! Tal vez está concentrado en sus pensamientos o se fue a hacer sus necesidades. ¡O quizás está dormido y alguien tiene que despertarlo!”.

**28** Ellos gritaban a todo pulmón y, de acuerdo con sus costumbres, se cortaban con cuchillos y lanzas hasta que la sangre les chorreaba por todo el cuerpo.

**29** Pasó el mediodía y siguieron frenéticos hasta la hora de la ofrenda de grano del atardecer. Pero no se oyó ni una voz ni nadie que respondiera; nadie los escuchaba.

**30** Por fin Elías le dijo a todo el pueblo: “Acérquense a mí”. De modo que todo el pueblo se acercó a él. Entonces reparó el altar de Jehová que había sido demolido.

**31** Elías tomó 12 piedras, que correspondían al número de las tribus de los hijos de Jacob, quien recibió este mensaje de Jehová: “Tu nombre será Israel”.

**32** Con las piedras construyó un altar en honor al nombre de Jehová. Y alrededor del altar hizo una zanja dejando un área lo suficientemente extensa como para sembrar dos seas de semilla.

**33** Después acomodó la leña, descuartizó al toro joven y lo colocó sobre la leña. Y dijo: “Llenen de agua cuatro jarrones y derrámenla sobre la ofrenda quemada y la leña”.

**34** Entonces les dijo: “Háganlo otra vez”. Y lo volvieron a hacer. Nuevamente les dijo: “Háganlo por tercera vez”. Y lo hicieron por tercera vez.

**35** El agua corría alrededor de todo el altar, y él también llenó de agua la zanja.

**36** Hacia la hora de presentar la ofrenda de grano del atardecer, el profeta se acercó al altar y dijo: “Oh, Jehová —Dios de Abrahán, de Isaac y de Israel—, que hoy se sepa que tú eres Dios en Israel, que yo soy tu siervo y que he hecho todo esto porque tú me lo dijiste.

**37** ¡Respóndeme, oh, Jehová! Respóndeme para que este pueblo sepa que tú, Jehová, eres el Dios verdadero y que tú estás haciendo que sus corazones vuelvan a ti”.

**38** Ante eso, el fuego de Jehová cayó de arriba y devoró la ofrenda quemada, la leña, las piedras y el polvo, y lamió el agua de la zanja.

**39** Cuando todo el pueblo vio esto, inmediatamente cayeron rostro a tierra y dijeron: “¡Jehová es el Dios verdadero! ¡Jehová es el Dios verdadero!”.

**40** Entonces Elías les dijo: “¡Agarren a los profetas de Baal! ¡Que no escape ni uno!”. Enseguida los agarraron, y Elías los bajó al arroyo de Cisón, donde los mató.

**41** Elías ahora le dijo a Acab: “Sube a comer y beber, porque ya se oye el ruido de un tremendo aguacero”.

**42** Así que Acab subió a comer y beber. Pero Elías subió a la cima del Carmelo y se agachó hasta el suelo con la cara entre las rodillas.

**43** Entonces le dijo a su ayudante: “Sube, por favor, y mira hacia el mar”. Así que subió, miró y le dijo: “No hay nada de nada”. Elías le dijo siete veces: “Vuelve y mira”.

**44** Y a la séptima vez su ayudante le dijo: “¡Mira! Está subiendo desde el mar una nubecita como del tamaño de una mano”. Elías le dijo: “Ve y dile a Acab: ‘¡Prepara tu carro! ¡Baja para que el aguacero no te detenga!’”.

**45** En eso, el cielo se llenó de nubes negras, se levantó el viento y cayó un tremendo aguacero. Y Acab se fue en su carro a Jezreel.

**46** Pero la mano de Jehová le dio poder a Elías, quien se ajustó la ropa a la cintura y se fue corriendo por delante de Acab todo el camino hasta Jezreel.

### Notas a pie de página
- **v. 1:** O “la palabra”.
- **v. 5:** O “wadis”.
- **v. 15:** Lit. “ante quien estoy de pie”.
- **v. 21:** O “sobre dos muletas”.
- **v. 27:** O quizás “se fue de viaje”.
- **v. 29:** O “portándose como profetas”.
- **v. 31:** O “la palabra”.
- **v. 32:** Un sea equivalía a 7,33 L (6,66 dry qt). Ver apén. B14.
- **v. 40:** O “wadi”.
- **v. 46:** O “se ciñó”.

---

## Primero de los Reyes 19

**1** Entonces Acab le contó a Jezabel todo lo que Elías había hecho y cómo había matado a espada a todos los profetas.

**2** Así que Jezabel mandó un mensajero a decirle a Elías: “¡Que los dioses me castiguen severamente si no hago que mañana a esta hora tú acabes igual que cada uno de ellos!”.

**3** A él le dio tanto miedo que salió huyendo por su vida. Llegó a Beer-Seba, que pertenece a Judá, y dejó allí a su ayudante.

**4** Se adentró en el desierto y caminó durante un día hasta que llegó a una retama y se sentó debajo de ella. Pidió la muerte diciendo: “¡Basta ya! Ay, Jehová, quítame la vida, porque no soy mejor que mis antepasados”.

**5** Entonces se acostó y se quedó dormido debajo de la retama. Pero, de repente, un ángel lo tocó y le dijo: “Levántate y come algo”.

**6** Cuando él miró, vio junto a su cabeza un pan redondo sobre piedras calentadas y una jarra de agua. Comió y bebió, y volvió a recostarse.

**7** Más tarde, el ángel de Jehová volvió por segunda vez, lo tocó y le dijo: “Levántate, come. Si no, el viaje va a ser demasiado para ti”.

**8** Así que se levantó, comió y bebió. Aquella comida le dio fuerzas para caminar 40 días y 40 noches hasta Horeb, la montaña del Dios verdadero.

**9** Allí entró en una cueva y pasó la noche. De pronto, escuchó estas palabras de Jehová: “¿Qué haces aquí, Elías?”.

**10** Él respondió: “He demostrado devoción absoluta por Jehová, el Dios de los ejércitos. El pueblo de Israel ha abandonado tu pacto, ha demolido tus altares, ha matado a tus profetas a espada, y yo soy el único que queda. Y ahora quieren quitarme la vida a mí”.

**11** Pero Dios dijo: “Sal y ponte en la montaña delante de Jehová”. Y resultó que Jehová estaba pasando por allí. Y un viento fuerte y arrasador partía las montañas y destrozaba los peñascos delante de Jehová, pero Jehová no estaba en el viento. Después del viento hubo un terremoto, pero Jehová no estaba en el terremoto.

**12** Después del terremoto hubo fuego, pero Jehová no estaba en el fuego. Y después del fuego se oyó una voz calmada y baja.

**13** Tan pronto como Elías la oyó, se cubrió la cara con su prenda de vestir oficial, salió y se paró a la entrada de la cueva. Entonces la voz le preguntó: “¿Qué haces aquí, Elías?”.

**14** Él respondió: “He demostrado devoción absoluta por Jehová, el Dios de los ejércitos. El pueblo de Israel ha abandonado tu pacto, ha demolido tus altares, ha matado a tus profetas a espada, y yo soy el único que queda. Y ahora quieren quitarme la vida a mí”.

**15** Jehová le dijo: “Regresa y ve al desierto de Damasco. Cuando llegues, unge a Hazael como rey de Siria.

**16** Unge a Jehú, nieto de Nimsí, como rey de Israel. Y a Eliseo hijo de Safat de Abel-Meholá úngelo como profeta para que ocupe tu lugar.

**17** Al que escape de la espada de Hazael lo matará Jehú; y al que escape de la espada de Jehú lo matará Eliseo.

**18** En Israel aún me quedan 7.000 que no se han arrodillado ante Baal ni lo han besado”.

**19** Así que Elías se fue de allí y encontró a Eliseo hijo de Safat, que estaba arando la tierra. Tenía 12 pares de toros delante y él iba con el último par. Elías se le acercó y le echó encima su prenda de vestir oficial.

**20** Eliseo dejó atrás los toros, se fue corriendo tras Elías y le dijo: “Por favor, déjame besar a mi padre y a mi madre, y entonces te seguiré”. Él le respondió: “Anda, vuelve. ¿Acaso te lo estoy impidiendo?”.

**21** Así que volvió, se llevó un par de toros y los sacrificó. Usó la madera del arado y el yugo para cocinar la carne de los toros. Luego se la dio a la gente y comieron. Después se fue, siguió a Elías y empezó a servirle.

### Notas a pie de página
- **v. 4:** O “que su alma muriera”.
- **v. 4:** O “el alma”.
- **v. 16:** Que significa ‘Dios es salvación’.

---

## Primero de los Reyes 20

**1** El rey Ben-Hadad de Siria reunió a todo su ejército y a otros 32 reyes con sus caballos y carros. Entonces subió, cercó Samaria y la atacó.

**2** Luego envió mensajeros a la ciudad para decirle al rey Acab de Israel: “Esto es lo que dice Ben-Hadad:

**3** ‘Tu plata y tu oro son míos, y tus mejores esposas e hijos también’”.

**4** El rey de Israel respondió: “Mi señor el rey, tal como has dicho, yo soy tuyo y todo lo que me pertenece también es tuyo”.

**5** Más tarde, los mensajeros volvieron y dijeron: “Esto es lo que dice Ben-Hadad: ‘Yo te envié este mensaje: “Me darás tu plata, tu oro, tus esposas y tus hijos”.

**6** Pero mañana como a esta hora te enviaré a mis siervos y ellos registrarán tu casa y las casas de tus siervos. Se van a apoderar de todas tus cosas valiosas y se las van a llevar’”.

**7** Ante eso, el rey de Israel llamó a todos los ancianos del país y dijo: “Fíjense. Miren cómo este hombre está empeñado en causarnos problemas. Ya me exigió mis esposas, mis hijos, mi plata y mi oro, y yo no se lo negué”.

**8** Entonces todos los ancianos y todo el pueblo le dijeron: “No obedezcas. No le digas que sí”.

**9** Así que él les dijo a los mensajeros de Ben-Hadad: “Díganle a mi señor el rey: ‘Todo lo que ya le habías pedido a este siervo tuyo lo haré, pero esto no lo puedo hacer’”. Los mensajeros se fueron y le llevaron el mensaje.

**10** Ben-Hadad entonces le mandó decir: “¡Que los dioses me castiguen severamente si en Samaria hay suficiente polvo como para darle un puñado a cada uno de los que están conmigo!”.

**11** El rey de Israel contestó: “Díganle: ‘El que se pone la armadura no debería cantar victoria como el que ya se la está quitando’”.

**12** Cuando a Ben-Hadad le llegó esta respuesta, él y los reyes estaban bebiendo en sus tiendas. De inmediato les dijo a sus siervos: “¡Prepárense para atacar!”. Así que se prepararon para atacar la ciudad.

**13** Pero un profeta fue adonde el rey Acab de Israel y le dijo: “Esto es lo que dice Jehová: ‘¿Ves a todo este gran ejército? Pues hoy lo entregaré en tus manos, y entonces sabrás que yo soy Jehová’”.

**14** “¿Y por medio de quién?”, le preguntó Acab. El profeta le respondió: “Esto es lo que dice Jehová: ‘Por medio de los ayudantes de los príncipes de las provincias’”. “¿Y quién empezará la batalla?”, preguntó. “¡Tú!”, contestó el profeta.

**15** Entonces Acab contó a los ayudantes de los príncipes de las provincias, y eran 232. Después contó a todos los varones israelitas, y eran 7.000.

**16** Salieron al mediodía, mientras Ben-Hadad estaba emborrachándose en las tiendas junto con los 32 reyes que lo ayudaban.

**17** Los ayudantes de los príncipes de las provincias salieron primero y enseguida Ben-Hadad envió mensajeros, que le informaron esto: “Han salido hombres de Samaria”.

**18** A lo que él dijo: “Si salieron en son de paz, captúrenlos vivos. Y, si salieron para pelear, de todos modos captúrenlos vivos”.

**19** Pero, cuando los ayudantes de los príncipes de las provincias y los ejércitos que los seguían salieron de la ciudad,

**20** cada uno mató a su oponente. Entonces los sirios huyeron, e Israel los persiguió. Pero el rey Ben-Hadad de Siria escapó a caballo junto con algunos jinetes.

**21** El rey de Israel salió y estuvo atacando caballos y carros. Hizo que los sirios sufrieran una gran derrota.

**22** Más tarde, el profeta fue adonde el rey de Israel y le dijo: “Ve, refuérzate y piensa bien lo que vas a hacer, pues a principios del próximo año el rey de Siria subirá a atacarte”.

**23** Los siervos del rey de Siria le dijeron: “El Dios de ellos es un Dios de montañas, y por eso nos ganaron. Pero, si peleamos con ellos en terreno llano, nosotros les ganaremos.

**24** También haz lo siguiente: saca a todos los reyes de sus puestos y sustitúyelos con gobernadores.

**25** Luego forma un ejército igual al que perdiste, con la misma cantidad de caballos y carros. Luchemos contra ellos en terreno llano, y seguro que les ganamos”. Él escuchó su consejo e hizo justo eso.

**26** A principios de año, Ben-Hadad reunió a los sirios y subió a Afec para pelear contra Israel.

**27** La gente de Israel, que también fue reunida y recibió suministros, salió al encuentro de ellos. Cuando acampó enfrente de ellos, la gente de Israel parecía dos rebañitos de cabras, mientras que los sirios llenaban toda la tierra.

**28** Entonces el hombre del Dios verdadero fue adonde estaba el rey de Israel y le dijo: “Esto es lo que dice Jehová: ‘Como los sirios han dicho “Jehová es un Dios de montañas y no un Dios de llanuras”, entregaré a todo este gran ejército en tus manos, y ustedes sin falta sabrán que yo soy Jehová’”.

**29** Se quedaron acampados unos frente a otros durante siete días, y al séptimo día comenzó la batalla. En un día, la gente de Israel derribó a 100.000 soldados sirios de a pie.

**30** El resto huyó a Afec y entró en la ciudad. Pero la muralla se desplomó sobre 27.000 de los hombres que quedaban. Ben-Hadad también huyó y entró en la ciudad, y se escondió en un cuarto interior.

**31** Entonces sus siervos le dijeron: “Mira, hemos oído que los reyes de la casa de Israel son reyes compasivos. Por favor, deja que nos pongamos tela de saco alrededor de la cintura y sogas alrededor de la cabeza, y déjanos ir adonde el rey de Israel. Tal vez te perdone la vida”.

**32** De modo que se pusieron tela de saco alrededor de la cintura y sogas alrededor de la cabeza, se presentaron ante el rey de Israel y le dijeron: “Tu siervo Ben-Hadad dice: ‘Por favor, perdóname la vida’”. Y él contestó: “¿Todavía está vivo? Es mi hermano”.

**33** Los hombres lo interpretaron como un buen presagio y enseguida le tomaron la palabra. Le respondieron: “Sí, Ben-Hadad es tu hermano”. A lo que él dijo: “Vayan y tráiganlo”. Entonces Ben-Hadad salió adonde estaba él, y Acab hizo que se subiera al carro.

**34** Ben-Hadad ahora le dijo: “Devolveré las ciudades que mi padre le quitó a tu padre, y podrás establecer mercados para ti en Damasco, tal como mi padre lo hizo en Samaria”. Acab contestó: “Si hacemos este acuerdo, te dejaré ir”. Así que hizo un acuerdo con él y lo dejó ir.

**35** Ahora bien, por orden de Jehová, uno de los hijos de los profetas le dijo a su compañero: “Por favor, golpéame”. Pero este se negó.

**36** Entonces le dijo: “Por no haberle hecho caso a la voz de Jehová, en cuanto te vayas de aquí, te matará un león”. Al irse de allí, apareció un león y lo mató.

**37** El profeta se encontró a otro hombre y le dijo: “Por favor, golpéame”. Y el hombre lo golpeó y lo dejó herido.

**38** Entonces el profeta se fue y se quedó esperando al rey junto al camino. Se disfrazó cubriéndose los ojos con una venda.

**39** Cuando el rey pasó por ahí, el profeta le gritó: “Este siervo tuyo se metió en pleno centro de la batalla, y salió un hombre que traía a otro hombre y dijo: ‘Vigila a este hombre. Si se te escapa, pagarás por su vida con la tuya o, si no, tendrás que pagar un talento de plata’.

**40** Y, mientras este siervo tuyo andaba ocupado de aquí para allá, el hombre desapareció”. El rey de Israel le dijo: “Esa es tu sentencia. Tú mismo la pronunciaste”.

**41** Él rápido se quitó la venda de los ojos, y el rey de Israel se dio cuenta de que era uno de los profetas.

**42** Entonces le dijo al rey: “Esto es lo que dice Jehová: ‘Como dejaste que se te escapara de las manos el hombre que dije que debían matar, pagarás por su vida con la tuya, y tu pueblo pagará por su pueblo’”.

**43** Ante esto, el rey de Israel volvió a su hogar en Samaria decaído y de mal humor.

### Notas a pie de página
- **v. 12:** O “cabañas”.
- **v. 14:** O “los distritos jurisdiccionales (administrativos)”.
- **v. 16:** O “cabañas”.
- **v. 21:** O “matanza”.
- **v. 22:** Es decir, la próxima primavera.
- **v. 25:** Lit. “numera”.
- **v. 26:** Es decir, en la primavera.
- **v. 31:** O “reyes de amor leal”.
- **v. 31:** O “el alma”.
- **v. 33:** O “agüero”.
- **v. 34:** O “escoger calles”.
- **v. 34:** O “pacto”.
- **v. 35:** Al parecer, la expresión los hijos de los profetas hace referencia a una escuela para profetas o a una asociación de profetas.
- **v. 36:** O “golpeará”.
- **v. 39:** O “será tu alma en lugar de su alma”.
- **v. 39:** Un talento equivalía a 34,2 kg (1.101 oz tr). Ver apén. B14.
- **v. 42:** O “será tu alma en lugar de su alma”.

---

## Primero de los Reyes 21

**1** Después de estas cosas, surgió un problema con una viña que pertenecía a Nabot el jezreelita. La viña estaba en Jezreel, cerca del palacio de Acab, el rey de Samaria.

**2** Acab le dijo a Nabot: “Dame tu viña para convertirla en una huerta, porque está cerca de mi casa. A cambio te daré una viña mejor. O, si lo prefieres, te pago su precio en dinero”.

**3** Pero Nabot le dijo a Acab: “Yo jamás te daría la herencia de mis antepasados. Jehová no lo vería bien”.

**4** Entonces Acab entró en su casa decaído y de mal humor por la respuesta de Nabot el jezreelita, que le había dicho “No te daré la herencia de mis antepasados”. Luego se acostó en la cama, escondió la cara y no quiso comer.

**5** Su esposa Jezabel fue a verlo y le preguntó: “¿Por qué estás tan triste que no quieres ni comer?”.

**6** Él le respondió: “Porque le dije a Nabot el jezreelita ‘Véndeme tu viña. O, si lo prefieres, déjame darte otra viña a cambio’. Pero él dijo ‘No te daré mi viña’”.

**7** Entonces su esposa Jezabel le dijo: “¿Acaso no eres tú el rey, el que gobierna en Israel? Levántate, come algo y anímate. Yo te daré la viña de Nabot el jezreelita”.

**8** Así que ella escribió cartas en nombre de Acab, las selló con el sello de él y se las envió a los ancianos y a los nobles que vivían en la ciudad de Nabot.

**9** En las cartas escribió: “Ordenen un ayuno y hagan que Nabot se siente delante del pueblo.

**10** Hagan que dos hombres inútiles se sienten enfrente de él y testifiquen contra él diciendo ‘¡Has maldecido a Dios y al rey!’. Después sáquenlo afuera y mátenlo a pedradas”.

**11** Así que los hombres de su ciudad, los ancianos y los nobles que vivían allí, hicieron justo lo que decían las cartas que Jezabel les envió.

**12** Ordenaron un ayuno e hicieron que Nabot se sentara delante del pueblo.

**13** Entonces llegaron dos hombres inútiles, se sentaron enfrente de Nabot y empezaron a testificar contra él delante del pueblo. Decían: “¡Nabot ha maldecido a Dios y al rey!”. Después lo sacaron a las afueras de la ciudad y lo mataron a pedradas.

**14** Luego le enviaron a Jezabel este mensaje: “Nabot ha sido apedreado y está muerto”.

**15** En cuanto Jezabel oyó que habían apedreado a Nabot, le dijo a Acab: “Vamos, apodérate de la viña que Nabot el jezreelita se negó a venderte. Porque Nabot ya no vive. Está muerto”.

**16** Al enterarse de que Nabot estaba muerto, Acab enseguida fue y bajó a la viña de Nabot el jezreelita para quedarse con ella.

**17** Pero Elías el tisbita recibió este mensaje de Jehová:

**18** “Ve y baja a encontrarte con Acab, el rey de Israel, que está en Samaria. Está en la viña de Nabot. Fue allí para quedarse con ella.

**19** Tienes que decirle: ‘Esto es lo que dice Jehová: “¿Has asesinado a un hombre y también le has quitado su propiedad?”’. Después dile: ‘Esto es lo que dice Jehová: “En el lugar donde los perros lamieron la sangre de Nabot, los perros lamerán tu sangre”’”.

**20** Acab le dijo a Elías: “¡Me encontraste, enemigo mío!”. Él le respondió: “Sí, te encontré. Dios ha dicho: ‘Por haberte empeñado en hacer lo que está mal a los ojos de Jehová,

**21** voy a mandarte una calamidad, te barreré por completo y exterminaré de Israel a todos los hombres de Acab, incluidos los indefensos y los débiles.

**22** Haré que tu casa acabe como la casa de Jeroboán hijo de Nebat y como la casa de Baasá hijo de Ahíya, porque me has enfurecido y has hecho pecar a Israel’.

**23** Jehová también dijo esto sobre Jezabel: ‘Los perros se comerán a Jezabel en el terreno de Jezreel.

**24** A los de Acab que mueran en la ciudad se los comerán los perros. Y a los que mueran en el campo se los comerán las aves del cielo.

**25** Y es que nunca ha habido nadie como Acab, que se empeñó en hacer lo que está mal a los ojos de Jehová incitado por su esposa Jezabel.

**26** Actuó de una manera sumamente detestable al seguir a los ídolos repugnantes, como habían hecho todos los amorreos, aquellos que Jehová expulsó delante de los israelitas’”.

**27** Tan pronto como Acab oyó estas palabras, se rasgó la ropa y se cubrió el cuerpo con tela de saco. Ayunaba, se acostaba en tela de saco y andaba desanimado.

**28** Entonces Elías el tisbita recibió este mensaje de Jehová:

**29** “¿Has visto cómo se ha humillado Acab por mí? Por haberse humillado ante mí, no traeré la calamidad mientras él viva. Traeré la calamidad a su casa en los días de su hijo”.

### Notas a pie de página
- **v. 5:** Lit. “está tu espíritu”.
- **v. 17:** O “la palabra”.
- **v. 19:** Lit. “has tomado posesión”.
- **v. 20:** Lit. “haberte vendido para”.
- **v. 21:** Lit. “los que orinan contra la pared”. Expresión hebrea despectiva para referirse a los varones.
- **v. 25:** Lit. “que se vendió para”.
- **v. 28:** O “la palabra”.

---

## Primero de los Reyes 22

**1** Durante tres años no hubo guerra entre Siria e Israel.

**2** Al tercer año, el rey Jehosafat de Judá bajó a ver al rey de Israel.

**3** Entonces el rey de Israel les dijo a sus siervos: “Saben que Ramot-Galaad nos pertenece, ¿verdad? Y aun así no nos atrevemos a quitársela al rey de Siria”.

**4** Luego le dijo a Jehosafat: “¿Irás conmigo a luchar en Ramot-Galaad?”. Jehosafat le respondió al rey de Israel: “Yo estaré contigo, mi pueblo estará con tu pueblo y mis caballos con tus caballos”.

**5** Pero Jehosafat le dijo al rey de Israel: “Por favor, primero averigua qué dice Jehová”.

**6** Así que el rey de Israel juntó a los profetas, como 400 hombres, y les dijo: “¿Voy a la guerra contra Ramot-Galaad, o no?”. Ellos le dijeron: “Sube, que Jehová la entregará en manos del rey”.

**7** Entonces Jehosafat dijo: “¿No hay por aquí un profeta de Jehová? Consultemos a Dios también por medio de él”.

**8** El rey de Israel le contestó a Jehosafat: “Todavía queda un hombre por medio de quien podemos consultar a Jehová, pero yo lo odio, porque las cosas que profetiza sobre mí nunca son buenas, solo son malas. Es Micaya hijo de Imlá”. Pero Jehosafat dijo: “El rey no debería hablar así”.

**9** Así que el rey de Israel llamó a un funcionario de la corte y le dijo: “Rápido, trae a Micaya hijo de Imlá”.

**10** El rey de Israel y Jehosafat, el rey de Judá, estaban en la era a la entrada de la puerta de Samaria, sentados cada cual en su trono y vestidos con ropas reales. Y todos los profetas estaban profetizando delante de ellos.

**11** Entonces Sedequías hijo de Kenaaná se hizo unos cuernos de hierro y dijo: “Esto es lo que dice Jehová: ‘Con estos cuernos embestirás a los sirios hasta exterminarlos’”.

**12** Todos los demás profetas profetizaban lo mismo. Decían: “Sube a Ramot-Galaad, que vencerás. Jehová la entregará en manos del rey”.

**13** El mensajero que fue a llamar a Micaya le dijo: “Mira que todo lo que dijeron los profetas era bueno para el rey. Por favor, di tú lo mismo que ellos dicen, anuncia algo bueno”.

**14** Pero Micaya dijo: “Tan cierto como que Jehová vive, diré lo que Jehová me diga”.

**15** Entonces se presentó ante el rey, y el rey le preguntó: “Micaya, ¿vamos a la guerra contra Ramot-Galaad, o no?”. Al instante contestó: “Sube, que vencerás. Jehová la entregará en manos del rey”.

**16** Al oír esto, el rey le dijo: “¿Cuántas veces tengo que hacerte jurar que me dirás solo la verdad en el nombre de Jehová?”.

**17** Así que él dijo: “Veo a todos los israelitas esparcidos por las montañas, como ovejas sin pastor. Jehová dijo: ‘No tienen amo. Que cada uno vuelva a su casa en paz’”.

**18** Entonces el rey de Israel le dijo a Jehosafat: “¿No te dije ‘Él no profetizará cosas buenas sobre mí, solo malas’?”.

**19** Y Micaya dijo: “Escucha ahora las palabras de Jehová. Vi a Jehová sentado en su trono y a todo el ejército de los cielos de pie junto a él, a su derecha y a su izquierda.

**20** Jehová entonces dijo: ‘¿Quién engañará a Acab para que suba a Ramot-Galaad y muera allí?’. Y uno decía una cosa, mientras que otro decía otra.

**21** Entonces un espíritu se acercó y se paró delante de Jehová y dijo: ‘Yo lo engañaré’. Jehová le preguntó: ‘¿Cómo lo vas a hacer?’.

**22** Él contestó: ‘Iré y me convertiré en un espíritu engañoso en boca de todos sus profetas’. Así que le dijo: ‘Lo vas a engañar; sí, te va a salir bien. Ve y hazlo’.

**23** Por eso Jehová ha puesto un espíritu engañoso en boca de todos estos profetas tuyos, pero en realidad Jehová ha anunciado que sufrirás una calamidad”.

**24** Sedequías hijo de Kenaaná se acercó entonces a Micaya, le dio una bofetada y le dijo: “¿Conque el espíritu de Jehová me dejó a mí para irse a hablar contigo? ¿Y por dónde fue?”.

**25** Micaya le respondió: “¡Mira! Lo sabrás el día que te metas en el cuarto más recóndito para esconderte”.

**26** Entonces el rey de Israel dijo: “Llévense a Micaya y entréguenselo a Amón, el jefe de la ciudad, y a Joás, el hijo del rey.

**27** Díganles: ‘Esto es lo que dice el rey: “Metan a este individuo en prisión y denle una ración reducida de pan y de agua hasta que yo vuelva victorioso”’”.

**28** Pero Micaya dijo: “Si vuelves victorioso, Jehová no ha hablado conmigo”. Y añadió: “Ustedes, toda la gente, tómenlo en cuenta”.

**29** De modo que el rey de Israel y Jehosafat, el rey de Judá, subieron a Ramot-Galaad.

**30** El rey de Israel le dijo a Jehosafat: “Yo me voy a disfrazar para entrar en la batalla, pero tú ponte tus ropas reales”. Así que el rey de Israel se disfrazó y entró en la batalla.

**31** El rey de Siria les había ordenado a los 32 comandantes de los carros: “No luchen con nadie, ni con pequeño ni con grande, solo con el rey de Israel”.

**32** En cuanto los comandantes de los carros vieron a Jehosafat, se dijeron: “Seguro que es el rey de Israel”. Así que fueron hacia él para atacarlo, y Jehosafat se puso a gritar por ayuda.

**33** Cuando los comandantes de los carros se dieron cuenta de que no era el rey de Israel, enseguida dejaron de perseguirlo.

**34** Pero un hombre disparó al azar con su arco y le dio al rey de Israel entre las uniones de su coraza. El rey le dijo al conductor de su carro: “Da la vuelta y sácame de la batalla, porque me han herido gravemente”.

**35** La batalla fue muy intensa todo aquel día. Tuvieron que sostener al rey de pie en el carro de cara a los sirios. La sangre de la herida chorreaba dentro del carro, y él murió al atardecer.

**36** Hacia la puesta del sol se oyó un grito en el campamento: “¡Todos a su ciudad! ¡Todos a su tierra!”.

**37** Así fue como el rey murió y lo trajeron a Samaria, donde lo enterraron.

**38** Cuando lavaron el carro de guerra junto al estanque de Samaria, los perros lamieron su sangre y las prostitutas se bañaron allí, de acuerdo con las palabras que había dicho Jehová.

**39** En cuanto al resto de la historia de Acab, todo lo que hizo, la casa de marfil que construyó y todas las ciudades que construyó, está escrito en el libro de la historia de los reyes de Israel.

**40** Entonces Acab descansó con sus antepasados y su hijo Ocozías se convirtió en el nuevo rey.

**41** Jehosafat hijo de Asá había llegado a ser rey de Judá en el cuarto año del rey Acab de Israel.

**42** Jehosafat tenía 35 años cuando se convirtió en rey, y reinó 25 años en Jerusalén. Su madre se llamaba Azubá hija de Silhí.

**43** Él siguió los mismos pasos de su padre Asá; no se desvió de ellos. Hizo lo que estaba bien a los ojos de Jehová. Sin embargo, no se quitaron los lugares altos y la gente seguía haciendo sacrificios y humo de sacrificio en ellos.

**44** Jehosafat mantuvo la paz con el rey de Israel.

**45** En cuanto al resto de la historia de Jehosafat, de sus grandes hazañas y de cómo guerreó, está escrito en el libro de la historia de los reyes de Judá.

**46** También eliminó del país a los prostitutos de templo que habían quedado desde los días de su padre Asá.

**47** En aquel entonces no había ningún rey en Edom; un comisario hacía de rey.

**48** Jehosafat también hizo barcos de Tarsis para ir a buscar oro a Ofir, pero los barcos no fueron, porque se destrozaron en Ezión-Guéber.

**49** Fue entonces cuando Ocozías hijo de Acab le dijo a Jehosafat: “Deja que mis siervos vayan con tus siervos en los barcos”. Pero Jehosafat le dijo que no.

**50** Entonces Jehosafat descansó con sus antepasados y fue enterrado con sus antepasados en la Ciudad de David, su antepasado; y su hijo Jehoram se convirtió en el nuevo rey.

**51** Ocozías hijo de Acab llegó a ser rey de Israel en Samaria en el año 17 del rey Jehosafat de Judá y reinó sobre Israel por dos años.

**52** Hacía lo que estaba mal a los ojos de Jehová. Siguió los pasos de su padre y su madre, y los de Jeroboán hijo de Nebat, quien había hecho pecar a Israel.

**53** Servía a Baal y se inclinaba ante él, y provocaba a Jehová, el Dios de Israel, tal como había hecho su padre.

### Notas a pie de página
- **v. 5:** O “la palabra de”.
- **v. 9:** O “un oficial”.
- **v. 11:** O “empujarás”.
- **v. 21:** O “ángel”.
- **v. 34:** O “en su inocencia”.
- **v. 34:** Lit. “del campamento”.
- **v. 38:** O quizás “donde se bañaban las prostitutas, los perros lamieron su sangre”.
- **v. 39:** O “el palacio”.
- **v. 48:** Ver glosario.
