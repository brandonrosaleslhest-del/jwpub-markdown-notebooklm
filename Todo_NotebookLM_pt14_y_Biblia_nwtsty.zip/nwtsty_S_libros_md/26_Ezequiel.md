# El libro de Ezequiel (Ezequiel)

---

## Información sobre Ezequiel

---

**EZEQUIEL**

## CONTENIDO DEL LIBRO

- **1**
  - Ezequiel tiene visiones de Dios en Babilonia (1-3)
  - Visión del carro celestial de Jehová (4-28)
    - Viento, una nube y fuego (4)
    - Cuatro seres vivientes (5-14)
    - Cuatro ruedas (15-21)
    - Una plataforma que brilla como el hielo (22-24)
    - El trono de Jehová (25-28)
- **2**
  - A Ezequiel se le nombra profeta (1-10)
    - “Ya sea que escuchen o se nieguen a escuchar” (5)
    - Ve un rollo con canciones de duelo (9, 10)
- **3**
  - Se le ordena a Ezequiel que se coma el rollo que Dios le da (1-15)
  - A Ezequiel se le nombra centinela (16-27)
    - La negligencia conlleva culpa de sangre (18-21)
- **4**
  - Representación del cerco a Jerusalén (1-17)
    - Ezequiel carga con la culpa por 390 días y por 40 días (4-7)
- **5**
  - Representación de la caída de Jerusalén (1-17)
    - El profeta divide el pelo cortado en tres partes (1-4)
    - Jerusalén es peor que las naciones (7-9)
    - Tres castigos para los rebeldes (12)
- **6**
  - Profecía contra las montañas de Israel (1-14)
    - Los ídolos repugnantes serán humillados (4-6)
    - “Ustedes tendrán que saber que yo soy Jehová” (7)
- **7**
  - “El fin ha venido” (1-27)
    - “Una calamidad sin igual” (5)
    - El dinero será arrojado por las calles (19)
    - El templo será profanado (22)
- **8**
  - Ezequiel es llevado a Jerusalén en una visión (1-4)
  - Ve cosas detestables en el templo (5-18)
    - Mujeres llorando por el dios Tamuz (14)
    - Hombres adorando al sol (16)
- **9**
  - Seis verdugos y un hombre con un tintero (1-11)
    - La ejecución de la sentencia empieza por el santuario (6)
- **10**
  - Se toma fuego de entre las ruedas (1-8)
  - Descripción de los querubines y las ruedas (9-17)
  - La gloria de Dios deja el templo (18-22)
- **11**
  - Se condena a los príncipes malvados (1-13)
    - La ciudad, comparada a una olla (3-12)
  - Promesa de restauración (14-21)
    - Se dará “un espíritu nuevo” (19)
  - La gloria de Dios deja Jerusalén (22, 23)
  - Ezequiel regresa a Caldea en una visión (24, 25)
- **12**
  - Destierro profetizado mediante escenificaciones (1-20)
    - Equipaje para el destierro (1-7)
    - El jefe saldrá en la oscuridad (8-16)
    - Pan con angustia y agua con terror (17-20)
  - Se probará la falsedad de un proverbio engañoso (21-28)
    - “Ni una de mis palabras se demorará” (28)
- **13**
  - Profecía contra los falsos profetas (1-16)
    - Las paredes recubiertas con cal caerán (10-12)
  - Profecía contra las falsas profetisas (17-23)
- **14**
  - Se condena a los idólatras (1-11)
  - Imposible escapar de la sentencia contra Jerusalén (12-23)
    - Los justos Noé, Daniel y Job (14, 20)
- **15**
  - Jerusalén, una vid inútil (1-8)
- **16**
  - El amor de Dios por Jerusalén (1-63)
    - Encontrada como una niña abandonada (1-7)
    - Dios la embellece y hace un pacto matrimonial con ella (8-14)
    - Ella se vuelve infiel (15-34)
    - Castigada por adúltera (35-43)
    - Comparada con Samaria y Sodoma (44-58)
    - Dios se acuerda de su pacto (59-63)
- **17**
  - El enigma de las dos águilas y la vid (1-21)
  - Un brote tierno se convierte en un majestuoso cedro (22-24)
- **18**
  - Cada uno es responsable de sus pecados (1-32)
    - El alma que peca morirá (4)
    - Un hijo no pagará por el pecado de su padre (19, 20)
    - A Dios no le causa placer la muerte del malvado (23)
    - El arrepentimiento resulta en vida (27, 28)
- **19**
  - Canción de duelo por los jefes de Israel (1-14)
- **20**
  - Historia de la rebeldía de Israel (1-32)
  - Promesa de restauración para Israel (33-44)
  - Profecía contra el sur (45-49)
- **21**
  - Desenvainada la espada del juicio de Dios (1-17)
  - El rey de Babilonia atacará Jerusalén (18-24)
  - El fin del malvado jefe de Israel (25-27)
    - “Retira la corona” (26)
    - “Hasta que venga el que tiene el derecho legal” (27)
  - Una espada contra los ammonitas (28-32)
- **22**
  - Jerusalén, la ciudad sanguinaria (1-16)
  - Israel, “inservible como la escoria” (17-22)
  - Se condena a los líderes y al pueblo de Israel (23-31)
- **23**
  - Dos hermanas infieles (1-49)
    - Oholá con Asiria (5-10)
    - Oholibá con Babilonia y Egipto (11-35)
    - Las dos hermanas serán castigadas (36-49)
- **24**
  - Jerusalén, comparada con una olla oxidada (1-14)
  - La muerte de la esposa de Ezequiel es una señal (15-27)
- **25**
  - Profecía contra Ammón (1-7)
  - Profecía contra Moab (8-11)
  - Profecía contra Edom (12-14)
  - Profecía contra Filistea (15-17)
- **26**
  - Profecía contra Tiro (1-21)
    - “Un secadero para redes de pesca” (5, 14)
    - Piedras y suelo serán arrojados al agua (12)
- **27**
  - Canción de duelo por el naufragio de Tiro (1-36)
- **28**
  - Profecía contra el rey de Tiro (1-10)
    - “Soy un dios” (2, 9)
  - Canción de duelo por el rey de Tiro (11-19)
    - “Estabas en el Edén” (13)
    - “El querubín protector, el ungido” (14)
    - “Se encontró injusticia en ti” (15)
  - Profecía contra Sidón (20-24)
  - Israel será restaurado (25, 26)
- **29**
  - Profecía contra el faraón (1-16)
  - Egipto será la recompensa de Babilonia (17-21)
- **30**
  - Profecía contra Egipto (1-19)
    - Se predice el ataque de Nabucodonosor (10)
  - El poder del faraón será quebrado (20-26)
- **31**
  - La caída de Egipto, el extraordinario cedro (1-18)
- **32**
  - Canción de duelo por el faraón y por Egipto (1-16)
  - Entierro de Egipto con los incircuncisos (17-32)
- **33**
  - Responsabilidades del centinela (1-20)
  - Noticias sobre la caída de Jerusalén (21, 22)
  - Mensaje a los habitantes de las ruinas (23-29)
  - El pueblo no actúa de acuerdo con el mensaje (30-33)
    - Ezequiel es “como una canción de amor” (32)
    - “Hubo un profeta entre ellos” (33)
- **34**
  - Profecía contra los pastores de Israel (1-10)
  - Jehová cuida a sus ovejas (11-31)
    - “Mi siervo David” será su pastor (23)
    - “Un pacto de paz” (25)
- **35**
  - Profecía contra las montañas de Seír (1-15)
- **36**
  - Profecía acerca de las montañas de Israel (1-15)
  - Restauración de Israel (16-38)
    - “Santificaré mi gran nombre” (23)
    - “Como el jardín de Edén” (35)
- **37**
  - Visión de la llanura de los huesos secos (1-14)
  - Se deben juntar dos palos (15-28)
    - Una sola nación gobernada por un solo rey (22)
    - Pacto eterno de paz (26)
- **38**
  - Ataque de Gog contra Israel (1-16)
  - La furia de Jehová contra Gog (17-23)
    - Naciones “tendrán que saber que yo soy Jehová” (23)
- **39**
  - Destrucción de Gog y sus tropas (1-10)
  - Entierro en el valle de Hamon-Gog (11-20)
  - Restauración de Israel (21-29)
    - El espíritu de Dios será derramado sobre Israel (29)
- **40**
  - Ezequiel es llevado a Israel en una visión (1, 2)
  - Ezequiel recibe la visión de un templo (3, 4)
  - Los patios y las puertas (5-47)
    - La puerta exterior que da al este (6-16)
    - El patio exterior; otras puertas (17-26)
    - El patio interior y las puertas (27-37)
    - Comedores para el servicio del templo (38-46)
    - El altar (47)
  - El pórtico del templo (48, 49)
- **41**
  - El santuario del templo (1-4)
  - La pared y las habitaciones laterales (5-11)
  - El edificio del lado oeste (12)
  - Se miden los edificios (13-15a)
  - El interior del santuario (15b-26)
- **42**
  - Edificios de los comedores (1-14)
  - Se miden los cuatro lados del templo (15-20)
- **43**
  - La gloria de Jehová llena el templo (1-12)
  - El altar (13-27)
- **44**
  - La puerta este debe permanecer cerrada (1-3)
  - Normas sobre los extranjeros (4-9)
  - Normas para los levitas y los sacerdotes (10-31)
- **45**
  - La contribución santa y la ciudad (1-6)
  - La porción de tierra del jefe (7, 8)
  - Los jefes deben actuar con honradez (9-12)
  - Las contribuciones del pueblo y del jefe (13-25)
- **46**
  - Ofrendas en determinadas ocasiones (1-15)
  - Herencia dada por el jefe (16-18)
  - Lugares para hervir las ofrendas (19-24)
- **47**
  - El río que sale del templo (1-12)
    - El agua se hace cada vez más profunda (2-5)
    - El agua del mar Muerto será sanada (8-10)
    - Los pantanos no serán sanados (11)
    - Árboles para alimento y para sanar (12)
  - Los límites de la tierra (13-23)
- **48**
  - División de la tierra (1-29)
  - Las 12 puertas de la ciudad (30-35)
    - “El nombre de la ciudad: Jehová Está Allí” (35)

---

## Ezequiel 1

**1** En el año 30, en el día cinco del cuarto mes, mientras yo estaba entre el pueblo desterrado junto al río Kebar, se abrieron los cielos y empecé a tener visiones de Dios.

**2** En el día cinco del mes —era el quinto año del destierro del rey Joaquín—,

**3** Ezequiel hijo de Buzí el sacerdote recibió las palabras de Jehová junto al río Kebar, en la tierra de los caldeos. Allí la mano de Jehová vino sobre él.

**4** Mientras miraba, vi un viento de tormenta que venía del norte, y había una nube inmensa y un fuego centelleante con una luz fuerte alrededor. En medio del fuego había algo como el electro.

**5** Y dentro de él había algo parecido a cuatro seres vivientes, y todos ellos tenían el aspecto de un ser humano.

**6** Cada uno tenía cuatro caras y cuatro alas.

**7** Sus pies eran rectos, y las plantas de sus pies eran como las de un ternero. Estos brillaban como cobre pulido.

**8** En los cuatro lados tenían manos humanas bajo sus alas, y los cuatro tenían caras y alas.

**9** Sus alas se tocaban unas a otras. Cuando ellos avanzaban, no giraban; cada uno iba hacia adelante.

**10** Este era el aspecto de sus caras: cada uno de los cuatro tenía una cara de hombre con una cara de león a la derecha y una cara de toro a la izquierda. Y cada uno de los cuatro tenía una cara de águila.

**11** Así eran sus caras. Sus alas se extendían por encima de ellos. Cada uno tenía dos alas que se tocaban y dos que cubrían sus cuerpos.

**12** Cada uno iba hacia adelante, adonde el espíritu los impulsaba a ir. Avanzaban sin girar.

**13** Los seres vivientes parecían brasas ardientes, y algo parecido a antorchas brillantes se movía hacia atrás y hacia adelante entre los seres vivientes, y del fuego salían rayos.

**14** Y, cuando los seres vivientes iban y venían, se movían como relámpagos.

**15** Mientras observaba a los seres vivientes, vi que en el suelo había una rueda al lado de cada ser viviente de cuatro caras.

**16** Las ruedas y su estructura parecían brillar como el crisólito, y las cuatro parecían iguales. Su aspecto y su estructura eran como si hubiera una rueda dentro de otra rueda.

**17** Cuando se movían, podían ir en cualquiera de las cuatro direcciones sin girar al avanzar.

**18** Sus llantas tenían una altura que impresionaba; las llantas de las cuatro estaban llenas de ojos todo alrededor.

**19** Cuando los seres vivientes se movían, las ruedas se movían junto con ellos; cuando los seres vivientes se levantaban del suelo, las ruedas también se levantaban.

**20** Ellos iban adonde el espíritu los impulsaba a ir, fuera adonde fuera el espíritu. Las ruedas se levantaban junto con ellos, porque el espíritu que actuaba en los seres vivientes también estaba en las ruedas.

**21** Cuando ellos se movían, estas se movían; y, cuando ellos se detenían, estas se detenían; cuando se levantaban del suelo, las ruedas se levantaban junto con ellos, porque el espíritu que actuaba en los seres vivientes también estaba en las ruedas.

**22** Sobre las cabezas de los seres vivientes había una especie de plataforma que brillaba como el hielo y era impresionante. Esta se extendía por encima de sus cabezas.

**23** Debajo de la plataforma, sus alas estaban rectas, una frente a la otra. Cada uno tenía dos alas para cubrir un lado de su cuerpo y dos para cubrir el otro lado.

**24** Cuando oí el ruido de sus alas, sonaba como el ruido de aguas caudalosas, como el sonido del Todopoderoso. Cuando ellos se movían, el estruendo era como el de un ejército. Cuando se detenían, bajaban las alas.

**25** Se oía una voz sobre la plataforma que estaba por encima de sus cabezas. (Cuando ellos se detenían, bajaban las alas).

**26** Sobre la plataforma que estaba por encima de sus cabezas, había algo así como una piedra de zafiro, que parecía un trono. Sentado en el trono, en lo alto, había alguien que parecía un ser humano.

**27** Vi algo reluciendo como el electro, como un fuego que salía desde lo que parecía ser su cintura y hacia arriba; y, de su cintura hacia abajo, vi algo parecido al fuego. Alrededor de él había un resplandor

**28** como el del arcoíris en las nubes de un día lluvioso. Así era la luz brillante que lo rodeaba. Se parecía a la gloria de Jehová. Cuando lo vi, caí rostro a tierra y empecé a oír la voz de alguien que hablaba.

### Notas a pie de página
- **v. 3:** Que significa ‘Dios fortalece’.
- **v. 4:** O “y relámpagos”.
- **v. 4:** Es decir, una aleación o mezcla brillante de oro y plata.
- **v. 5:** O “criaturas vivientes”.
- **v. 9:** O “no se volvían”.
- **v. 16:** Posiblemente centradas formando ángulos rectos en un eje común.
- **v. 18:** O “aros”.
- **v. 20:** Lit. “el espíritu del ser viviente”.
- **v. 22:** Lit. “expansión”.
- **v. 23:** Lit. “expansión”.
- **v. 23:** O quizás “se extendían en línea recta”.
- **v. 25:** Lit. “expansión”.
- **v. 26:** Lit. “expansión”.

---

## Ezequiel 2

**1** Entonces él me dijo: “Hijo del hombre, ponte de pie para que hable contigo”.

**2** Cuando él me habló, el espíritu entró en mí y me hizo ponerme de pie para que oyera al que hablaba conmigo.

**3** Él me dijo: “Hijo del hombre, te envío al pueblo de Israel, a naciones rebeldes que se han rebelado contra mí. Ellos y sus antepasados han violado mis leyes hasta el día de hoy.

**4** Te envío a hijos desafiantes y tercos de corazón. Diles: ‘Esto es lo que dice el Señor Soberano Jehová’.

**5** Ya sea que escuchen o se nieguen a escuchar —porque son una casa rebelde—, sin falta sabrán que hubo un profeta entre ellos.

**6** ”Pero tú, hijo del hombre, no tengas miedo de ellos ni tampoco tengas miedo de sus palabras, aunque estés rodeado de abrojos y espinos y vivas entre escorpiones. No tengas miedo de sus palabras, y que sus rostros no te aterroricen, porque son una casa rebelde.

**7** Diles mis palabras, escuchen o no, porque son un pueblo rebelde.

**8** ”Pero tú, hijo del hombre, escucha lo que te digo. No te hagas rebelde como esta casa rebelde. Abre la boca y come lo que te doy”.

**9** Cuando miré, vi una mano extendida hacia mí, y en ella vi un rollo escrito.

**10** Él lo desenrolló delante de mí, y el rollo estaba escrito por delante y por detrás. En él había escritas canciones de duelo, lamentos y quejidos.

### Notas a pie de página
- **v. 1:** La primera de las 93 veces que aparece en Ezequiel la expresión hijo del hombre.
- **v. 4:** Lit. “duros de rostro”.
- **v. 6:** O quizás “aunque la gente sea obstinada y como cosas que te punzan”.
- **v. 9:** O “un rollo de un libro”.
- **v. 10:** O “endechas”.

---

## Ezequiel 3

**1** Entonces él me dijo: “Hijo del hombre, come lo que tienes delante de ti. Cómete este rollo y después vete a hablarle a la casa de Israel”.

**2** Así que abrí la boca, y él me hizo comer el rollo.

**3** Y añadió: “Hijo del hombre, cómete el rollo que te estoy dando y llénate el estómago con él”. De modo que empecé a comérmelo, y en mi boca era tan dulce como la miel.

**4** Luego me dijo: “Hijo del hombre, ve adonde están los de la casa de Israel y diles mis palabras.

**5** Porque no se te está enviando a un pueblo con un idioma incomprensible o una lengua desconocida, sino a la casa de Israel.

**6** No se te está enviando a muchos pueblos que hablan un idioma incomprensible o una lengua desconocida, con palabras que no puedas entender. Si te mandara a ellos, te escucharían.

**7** Pero la casa de Israel se negará a escucharte porque no quiere escucharme a mí. Todos los de la casa de Israel son de cabeza dura y tercos de corazón.

**8** Mira, he hecho tu rostro tan duro como sus rostros y tu frente tan dura como sus frentes.

**9** He hecho tu frente como un diamante, más dura que el pedernal. No les tengas miedo, y que sus rostros no te aterroricen, porque son una casa rebelde”.

**10** Él entonces me dijo: “Hijo del hombre, escucha y acepta en tu corazón todas las palabras que te digo.

**11** Ve adonde están los desterrados de tu pueblo y habla con ellos. Ya sea que escuchen o se nieguen a escuchar, diles: ‘Esto es lo que dice el Señor Soberano Jehová’”.

**12** Luego un espíritu me llevó y oí detrás de mí una voz estruendosa que decía: “Alabada sea la gloria de Jehová desde su lugar”.

**13** Oí el sonido de las alas de los seres vivientes al rozarse unas con otras, el sonido de las ruedas junto a ellos y un gran estruendo.

**14** El espíritu me levantó y me llevó. Y yo fui —con amargura y con indignación—, y la mano de Jehová era fuerte sobre mí.

**15** Así que fui al pueblo desterrado que estaba en Tel-Abib, que vivía junto al río Kebar, y me quedé donde ellos vivían. Allí, entre ellos, estuve aturdido siete días.

**16** Al terminar los siete días, recibí estas palabras de Jehová:

**17** “Hijo del hombre, te he nombrado centinela para la casa de Israel; y, cuando oigas una palabra de mi boca, los advertirás de mi parte.

**18** Si a alguien malvado yo le digo ‘Sin falta morirás’ pero tú no se lo adviertes ni hablas con el malvado para advertirle que deje su mal camino y siga viviendo, él, como es malvado, morirá por su error, pero su sangre te la exigiré a ti.

**19** En cambio, si tú le adviertes al malvado y él no deja su maldad ni su mal camino, morirá por su error, pero tú sin falta salvarás tu propia vida.

**20** Por otro lado, si alguien justo renuncia a su justicia y actúa mal, le pondré un obstáculo delante y morirá. Si no se lo advertiste, él morirá por su pecado y sus actos justos no serán recordados, pero su sangre te la exigiré a ti.

**21** En cambio, si le has advertido al justo que no peque y él no peca, sin falta seguirá viviendo porque se le advirtió, y tú habrás salvado tu propia vida”.

**22** En aquel lugar, la mano de Jehová vino sobre mí, y él me dijo: “Levántate y ve a la llanura, y allí hablaré contigo”.

**23** Así que me levanté y fui a la llanura. Y resulta que la gloria de Jehová estaba allí; era como la gloria que yo había visto junto al río Kebar. Y caí rostro a tierra.

**24** Entonces entró espíritu en mí y me hizo ponerme de pie, y él habló conmigo y me dijo: “Ve y enciérrate en tu casa.

**25** Tú, hijo del hombre, verás que te echarán cuerdas encima y te atarán con ellas para que no puedas salir y estar entre ellos.

**26** Y haré que se te pegue la lengua al paladar, y te quedarás mudo, no podrás corregirlos, porque son una casa rebelde.

**27** Pero, cuando yo hable contigo, abriré tu boca y tú les dirás: ‘Esto es lo que dice el Señor Soberano Jehová’. El que quiera escuchar, que escuche; el que se niegue a escuchar, que se niegue, porque son una casa rebelde.

### Notas a pie de página
- **v. 1:** Lit. “lo que encuentres”.
- **v. 9:** O “que una piedra”.
- **v. 11:** Lit. “de los hijos de tu pueblo”.
- **v. 14:** Lit. “y en el furor de mi espíritu”.
- **v. 17:** O “atalaya”, “vigilante”.
- **v. 18:** O “te pediré cuentas a ti por su sangre”.
- **v. 20:** O “hace injusticia”.
- **v. 20:** O “tropiezo”.
- **v. 20:** O “te pediré cuentas a ti por su sangre”.
- **v. 24:** Según parece, se refiere a Jehová.

---

## Ezequiel 4

**1** ”Y tú, hijo del hombre, toma un ladrillo y ponlo delante de ti. Graba en él una ciudad: Jerusalén.

**2** Cércala, construye un muro de asedio alrededor de ella, levanta una rampa para atacarla, monta campamentos para luchar contra ella y rodéala de arietes.

**3** Toma una plancha de hierro y colócala como un muro de hierro entre tú y la ciudad. Entonces fija tu mirada en ella y quedará cercada; tú vas a cercarla. Esto servirá de señal para la casa de Israel.

**4** ”Después, acuéstate sobre tu lado izquierdo y echa sobre ti la culpa de la casa de Israel. Cargarás con su culpa durante todos los días que estés acostado de ese lado.

**5** Yo te impondré esto por 390 días, lo que corresponde a los años de su culpa, y tú llevarás la culpa de la casa de Israel.

**6** Y tienes que completar ese periodo. ”Luego te volverás a acostar, esta vez sobre tu lado derecho, y cargarás con la culpa de la casa de Judá por 40 días. Un día por un año, un día por un año; eso es lo que yo te he impuesto.

**7** Y vuelve tu rostro hacia el cerco de Jerusalén y, con tu brazo descubierto, profetiza contra ella.

**8** ”Mira, te ataré con cuerdas para que no puedas darte la vuelta y acostarte del otro lado hasta que hayas cumplido los días de tu asedio.

**9** ”Y debes tomar trigo, cebada, habas, lentejas, mijo y espelta; ponlos en un recipiente y haz con eso tu pan. Lo comerás durante todos los días que estés acostado de un lado, 390 días.

**10** Pesarás y comerás 20 siclos de alimento al día. Lo comerás a horas fijas.

**11** ”Y tendrás el agua racionada, beberás una sexta parte de un hin. La beberás a horas fijas.

**12** ”Comerás tu pan tal como te comerías un pan redondo de cebada; ante sus ojos lo hornearás usando excremento humano seco como combustible”.

**13** Y Jehová dijo: “Así es como los israelitas comerán su pan, impuro, en medio de las naciones por donde los voy a dispersar”.

**14** Entonces dije: “¡Eso no, Señor Soberano Jehová! Desde que era joven hasta ahora, no me he contaminado comiendo la carne de un animal encontrado muerto o despedazado ni ha entrado en mi boca ninguna carne impura”.

**15** Así que me contestó: “Está bien, te doy permiso para que hornees tu pan usando estiércol de vaca en vez de excremento humano como combustible”.

**16** Luego añadió: “Hijo del hombre, voy a cortar el suministro de alimento en Jerusalén, y el pueblo comerá con angustia el pan racionado por peso y beberá con horror el agua racionada por medida.

**17** Esto sucederá para que, al faltarles el pan y el agua, se miren unos a otros desconcertados y se consuman por culpa de sus errores.

### Notas a pie de página
- **v. 4:** Lit. “él”, es decir, el lado izquierdo de Ezequiel.
- **v. 10:** Unos 230 g (7,3 oz tr). Ver apén. B14.
- **v. 11:** Unos 0,6 L (1,3 pt). Ver apén. B14.
- **v. 14:** O “asquerosa”.
- **v. 16:** Lit. “quebrar las varas de pan”. Posiblemente se refiere a las varas para colgar y almacenar el pan.

---

## Ezequiel 5

**1** ”Tú, hijo del hombre, toma para ti una espada afilada y úsala como navaja de barbero. Aféitate la cabeza y la barba, y luego pesa en una balanza el pelo cortado y divídelo en porciones.

**2** Cuando se cumplan los días del asedio, quemarás una tercera parte del pelo en el fuego dentro de la ciudad. Luego tomarás otra tercera parte y la cortarás con la espada alrededor de toda la ciudad. Finalmente, la última tercera parte la esparcirás al viento, y yo desenvainaré una espada para perseguirlos.

**3** ”Toma también unos pocos cabellos y envuélvelos en los pliegues de tu ropa.

**4** Toma algunos más, arrójalos al fuego y quémalos. Ese fuego se extenderá a toda la casa de Israel.

**5** ”Esto es lo que dice el Señor Soberano Jehová: ‘Esta es Jerusalén. La he puesto en medio de las naciones, rodeada de países.

**6** Pero ella se ha rebelado contra mis decisiones judiciales y mis estatutos, ha actuado con más maldad que las naciones y los países de alrededor. Porque sus habitantes rechazaron mis decisiones judiciales y no anduvieron según mis estatutos’.

**7** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Como ustedes causaron más problemas que las naciones de alrededor y no anduvieron según mis estatutos ni cumplieron mis decisiones judiciales, sino que actuaron según las decisiones judiciales de las naciones de alrededor,

**8** esto es lo que dice el Señor Soberano Jehová: “Oh, ciudad, aquí estoy contra ti, y yo mismo ejecutaré mi sentencia en medio de ti ante los ojos de las naciones.

**9** Por todas tus prácticas detestables, haré contigo lo que no he hecho nunca, algo que jamás volveré a hacer.

**10** ”’”Así que habrá padres entre ustedes que se comerán a sus hijos y habrá hijos que se comerán a sus padres; ejecutaré mi sentencia entre ustedes y dispersaré en todas direcciones a los que queden”’.

**11** ”‘Por lo tanto, tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, ya que contaminaste mi santuario con todos tus ídolos repugnantes y todas tus prácticas detestables, yo también te rechazo; mis ojos no sentirán lástima y no tendré compasión.

**12** Una tercera parte de ti morirá por la peste o morirá de hambre en medio de ti. Otra tercera parte caerá a espada alrededor de ti. Y a la última tercera parte la dispersaré en todas direcciones, y desenvainaré una espada para perseguirlos.

**13** Entonces mi furia se acabará y mi ira contra ellos desaparecerá, y me quedaré satisfecho. Y, cuando haya terminado de soltar mi ira contra ellos, tendrán que saber que yo, Jehová, he hablado porque insisto en recibir devoción exclusiva.

**14** ”’Te convertiré en un lugar devastado y en objeto de burla para las naciones vecinas y a la vista de todos los que pasen por ahí.

**15** Cuando ejecute en ti mi sentencia con furia, con ira y con severos castigos, llegarás a ser objeto de burla y desprecio, un ejemplo que sirva de advertencia y un motivo de terror para las naciones que te rodean. Yo, Jehová, he hablado.

**16** ”’Lanzaré contra ellos las flechas mortales del hambre para exterminarlos. Las flechas que lanzo acabarán con ellos. Haré que el hambre sea peor cortando su suministro de alimento.

**17** Contra ustedes mandaré hambre y fieras salvajes que los dejarán sin hijos. La peste y el derramamiento de sangre te arrollarán, y mandaré una espada contra ti. Yo, Jehová, he hablado’”.

### Notas a pie de página
- **v. 2:** Lit. “ella”.
- **v. 3:** O “las faldas”.
- **v. 10:** Lit. “a todo viento”.
- **v. 11:** O “disminuyo”.
- **v. 12:** O “enfermedad”.
- **v. 12:** Lit. “a todo viento”.
- **v. 16:** Lit. “quebrando las varas de pan”. Posiblemente se refiere a las varas para colgar y almacenar el pan.

---

## Ezequiel 6

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vuelve tu rostro hacia las montañas de Israel y profetiza contra ellas.

**3** Tienes que decir: ‘Oh, montañas de Israel, oigan las palabras del Señor Soberano Jehová. Esto es lo que el Señor Soberano Jehová les dice a las montañas, a las colinas, a las corrientes de agua y a los valles: “¡Miren! Mandaré una espada contra ustedes y destruiré sus lugares altos.

**4** Sus altares serán demolidos, sus altares de incienso serán destrozados, y lanzaré a sus muertos frente a sus ídolos repugnantes.

**5** Lanzaré los cadáveres del pueblo de Israel frente a sus ídolos repugnantes y esparciré sus huesos alrededor de sus altares.

**6** En todos los lugares donde vivan, las ciudades serán devastadas y los lugares altos serán demolidos y quedarán devastados. Sus altares serán demolidos y destrozados; sus ídolos repugnantes, eliminados; sus altares de incienso, destruidos, y sus obras, borradas.

**7** Los muertos caerán en medio de ustedes, y ustedes tendrán que saber que yo soy Jehová.

**8** ”’”Pero voy a dejar un resto, porque algunos de ustedes escaparán de la espada cuando estén entre las naciones, dispersados por los países.

**9** Y los que escapen se acordarán de mí en las naciones adonde sean llevados cautivos. Se darán cuenta de que me causó mucho dolor que su corazón infiel se apartara de mí y que sus ojos desearan apasionadamente a los ídolos repugnantes. Se avergonzarán y aborrecerán todas las cosas malas y detestables que han hecho.

**10** Ellos tendrán que saber que yo soy Jehová y que, cuando los amenacé con mandarles una calamidad, no eran palabras vacías”’.

**11** ”Esto es lo que dice el Señor Soberano Jehová: ‘Da palmadas con las manos y golpea el suelo con los pies, y laméntate por todas las cosas malas y detestables que ha hecho la casa de Israel, porque caerán por la espada, por el hambre y por la peste.

**12** El que esté lejos morirá por la peste; el que esté cerca caerá a espada, y todo el que escape de estas cosas y quede vivo morirá de hambre. Soltaré toda mi ira contra ellos.

**13** Y ustedes tendrán que saber que yo soy Jehová cuando sus muertos estén tendidos entre sus ídolos repugnantes, alrededor de sus altares, en todas las colinas altas, en todas las cimas de las montañas, bajo todos los árboles frondosos y bajo las ramas de árboles grandes donde han hecho ofrendas aromáticas para aplacar a todos sus ídolos repugnantes.

**14** Y extenderé mi mano contra ellos y haré que la tierra quede desolada; todos los lugares donde viven quedarán más desolados que el desierto que está cerca de Diblá. Y tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 4:** El término hebreo podría estar relacionado con una palabra para “estiércol”. Se usa como una expresión de desprecio.
- **v. 9:** O “inmoral”, “promiscuo”.
- **v. 9:** O “siguieran de un modo inmoral”.
- **v. 13:** O “han ofrecido aromas agradables”.

---

## Ezequiel 7

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, esto es lo que el Señor Soberano Jehová le dice a la tierra de Israel: ‘¡El fin! El fin ha venido sobre los cuatro extremos de esta tierra.

**3** Ahora te ha llegado el fin, y soltaré mi furia contra ti, te juzgaré según tu conducta y te pediré cuentas por todas tus acciones detestables.

**4** Mis ojos no sentirán lástima de ti, no tendré compasión, porque haré que recaigan sobre ti los resultados de tu propia conducta, sufrirás las consecuencias de tus acciones detestables. Y ustedes tendrán que saber que yo soy Jehová’.

**5** ”Esto es lo que dice el Señor Soberano Jehová: ‘¡Mira! Una calamidad, viene una calamidad sin igual.

**6** El fin ya viene. El fin vendrá, se levantará contra ti. ¡Mira! Ya viene.

**7** Te ha llegado el turno, habitante del país. Ya llega el momento, el día está cerca. En las montañas hay pánico en vez de gritos de alegría.

**8** ”’Muy pronto derramaré mi furor sobre ti, soltaré toda mi furia contra ti, te juzgaré según tu conducta y te pediré cuentas por todas tus acciones detestables.

**9** Mis ojos no sentirán lástima, no tendré compasión. Haré que recaigan sobre ti los resultados de tu conducta, sufrirás las consecuencias de tus propias acciones detestables. Y ustedes tendrán que saber que yo, Jehová, los estoy golpeando.

**10** ”’¡Mira, el día! ¡Mira, ya viene! Te ha llegado el turno; ha florecido la vara y ha brotado la arrogancia.

**11** La violencia ha crecido hasta convertirse en una vara de maldad. No sobrevivirán ni ellos, ni sus riquezas, ni sus multitudes, ni su prestigio.

**12** El momento vendrá, el día llegará. Que el comprador no se alegre y que el vendedor no se lamente, porque hay ira contra toda esa multitud.

**13** Porque el vendedor no volverá a la propiedad que vendió aunque quede con vida, pues la visión es contra toda esa multitud. Ninguno volverá. Por culpa de su error, ninguno conservará la vida.

**14** ”’Han tocado la trompeta y todos están listos, pero nadie va a la batalla, porque mi ira arde contra toda esa multitud.

**15** La espada está por fuera; la peste y el hambre, por dentro. Todo el que esté en el campo morirá a espada y todo el que esté en la ciudad será consumido por el hambre y la peste.

**16** Los que logren escapar vivos irán a las montañas; como las palomas de los valles, cada uno lamentará su propio error.

**17** Todas las manos se quedarán sin fuerzas y todas las rodillas gotearán agua.

**18** Se han vestido de tela de saco, y un temblor se ha apoderado de ellos. Todos quedarán avergonzados y todas las cabezas estarán calvas.

**19** ”’Arrojarán su plata por las calles y sentirán asco de su propio oro. Ni su plata ni su oro podrán salvarlos en el día de la furia de Jehová. No estarán satisfechos ni se llenarán el estómago, porque su plata y su oro han sido un obstáculo que los ha llevado al pecado.

**20** Estaban orgullosos de la belleza de sus adornos, y con ellos hicieron sus imágenes detestables, sus ídolos repugnantes. Por eso haré que le tengan asco a su plata y a su oro.

**21** Esto lo entregaré como botín en manos de extranjeros y como trofeo a los malvados de la tierra, y lo profanarán.

**22** ”’Me apartaré de ellos, y mi lugar oculto será profanado; ladrones entrarán en él y lo profanarán.

**23** ”’Prepara las cadenas, porque la tierra está llena de juicios manchados de sangre y la ciudad está llena de violencia.

**24** Traeré lo peor de las naciones, y ellos se quedarán con sus casas. Acabaré con el orgullo de los poderosos, y sus santuarios serán profanados.

**25** Cuando venga su angustia, buscarán la paz, pero no la habrá.

**26** Vendrá un desastre tras otro y una noticia tras otra. La gente buscará la visión de un profeta, pero la ley de los sacerdotes y los consejos de los ancianos dejarán de existir.

**27** El rey se pondrá de duelo y el jefe se vestirá de desesperación, y las manos de la gente del país temblarán de miedo. Los trataré según su conducta y los juzgaré como ellos han juzgado. Y tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 6:** Lit. “despertará”.
- **v. 7:** O quizás “la guirnalda”.
- **v. 10:** O quizás “la guirnalda”.
- **v. 12:** Es decir, ni los que compran ni los que venden propiedades saldrán beneficiados, ya que todos serán exterminados.
- **v. 13:** O quizás “Por medio de su error”.
- **v. 17:** Es decir, todos se orinarán de miedo.
- **v. 18:** Lit. “los ha cubierto”.
- **v. 18:** Es decir, estarán afeitadas en señal de duelo.
- **v. 19:** O “tropiezo”.
- **v. 22:** Lit. “Apartaré mi rostro”.
- **v. 22:** Según parece, se refiere a la parte más interna del santuario de Jehová.
- **v. 23:** Es decir, cadenas para los prisioneros.
- **v. 26:** O “instrucción”.
- **v. 27:** O “desolación”.

---

## Ezequiel 8

**1** En el sexto año, en el sexto mes, en el día cinco del mes, cuando estaba sentado en mi casa y los ancianos de Judá estaban sentados delante de mí, allí la mano del Señor Soberano Jehová me tomó.

**2** Mientras miraba, vi una figura que tenía la apariencia del fuego. Debajo de lo que parecía ser su cintura había fuego, y de su cintura hacia arriba tenía un aspecto resplandeciente, como el del electro.

**3** Entonces él extendió lo que parecía ser una mano y me agarró por un mechón de la cabeza, y un espíritu me llevó entre la tierra y los cielos y me trasladó a Jerusalén por medio de las visiones de Dios, a la entrada de la puerta interior que da al norte, donde estaba el símbolo idolátrico de celos que provoca celos.

**4** Y resulta que allí estaba la gloria del Dios de Israel; era como la visión que había tenido en la llanura.

**5** Después él me dijo: “Hijo del hombre, por favor, levanta la vista hacia el norte”. Así que levanté la vista hacia el norte y allí, al norte de la puerta del altar, en la entrada, estaba aquel símbolo de celos.

**6** Y añadió: “Hijo del hombre, ¿ves qué cosas tan horribles y detestables está haciendo la casa de Israel aquí, cosas que me alejan de mi santuario? Pero verás cosas detestables que son aún más horribles”.

**7** Luego me llevó a la entrada del patio y, cuando miré, vi un agujero en la pared.

**8** Él me dijo: “Hijo del hombre, por favor, perfora la pared”. Así que la perforé y vi una entrada.

**9** Y me dijo: “Entra y ve las cosas malas y detestables que están haciendo ahí”.

**10** De modo que entré y miré, y vi todo tipo de imágenes de animales que se arrastran y de animales asquerosos y todos los ídolos repugnantes de la casa de Israel; estaban grabados por toda la pared.

**11** De pie, delante de ellos, había 70 de los ancianos de la casa de Israel, entre quienes estaba Jaazanías hijo de Safán. Cada uno llevaba su incensario en la mano, y la nube perfumada de incienso iba subiendo.

**12** Y él me dijo: “Hijo del hombre, ¿ves lo que los ancianos de la casa de Israel están haciendo en la oscuridad, cada uno en los cuartos interiores donde tienen expuestos sus ídolos? Porque andan diciendo ‘Jehová no nos está viendo. Jehová ha abandonado el país’”.

**13** Y entonces me dijo: “Verás que están haciendo cosas detestables que son aún más horribles”.

**14** De modo que me llevó a la entrada de la puerta norte de la casa de Jehová, y allí vi sentadas a unas mujeres que lloraban por el dios Tamuz.

**15** Él también me dijo: “¿Ves esto, hijo del hombre? Verás cosas detestables que son aún más horribles que estas”.

**16** Después me llevó al patio interior de la casa de Jehová. Allí, a la entrada del templo de Jehová, entre el pórtico y el altar, había unos 25 hombres de espaldas al templo de Jehová y de cara al este; estaban inclinándose ante el sol, hacia el este.

**17** Él me dijo: “Hijo del hombre, ¿ves esto? ¿Es que no le basta a la casa de Judá con hacer estas cosas detestables, llenar el país de violencia y seguir provocándome? Mira, están pasándome la rama por la nariz.

**18** Así que actuaré con furia. Mis ojos no sentirán lástima, no tendré compasión. Aunque me griten con fuerza en los oídos, no los oiré”.

### Notas a pie de página
- **v. 2:** Es decir, una aleación o mezcla brillante de oro y plata.
- **v. 3:** O “la imagen idolátrica”.
- **v. 5:** O “aquella imagen”.
- **v. 12:** O “en los cuartos interiores de su exhibición”.
- **v. 17:** Según parece, una rama que se usaba en la adoración a ídolos.

---

## Ezequiel 9

**1** Entonces oí con mis propios oídos una voz fuerte que gritaba: “¡Que se acerquen los que castigarán a la ciudad, cada uno con su arma de destrucción en la mano!”.

**2** Vi que seis hombres venían del lado de la puerta superior que da al norte, cada uno con su arma para aplastar en la mano. Con ellos había un hombre vestido de lino con un tintero de secretario en la cintura. Y ellos entraron y se quedaron de pie al lado del altar de cobre.

**3** Entonces la gloria del Dios de Israel se elevó desde donde estaba, sobre los querubines, y fue hacia el umbral de la puerta de la casa. Y él empezó a llamar al hombre que estaba vestido de lino y que llevaba en la cintura el tintero de secretario.

**4** Jehová le dijo: “Recorre la ciudad, recorre Jerusalén, y pon una marca en la frente de todos los que suspiran y se lamentan por todas las cosas detestables que se están haciendo en la ciudad”.

**5** Y en mi presencia les dijo a los otros: “Recorran la ciudad detrás de él hiriendo de muerte a la gente. Que sus ojos no sientan lástima, no tengan ninguna compasión.

**6** Exterminen a todos, a los viejos, los jóvenes, las vírgenes, los niños y las mujeres. Pero no se acerquen a nadie que tenga la marca. Comiencen por el santuario”. De modo que comenzaron con los ancianos que estaban delante del templo.

**7** Entonces les dijo: “Contaminen el templo y llenen los patios de muertos. ¡Vayan!”. Así que salieron y mataron a la gente de la ciudad.

**8** Mientras iban matando a la gente —quedé yo solo—, caí rostro a tierra y grité: “¡Ay, Señor Soberano Jehová! ¿Vas a acabar con todos los que quedan de Israel derramando tu furia sobre Jerusalén?”.

**9** De modo que él me contestó: “El error de la casa de Israel y Judá es muy muy grande. El país está lleno de derramamiento de sangre, la ciudad está llena de corrupción. Porque ellos dicen ‘Jehová ha abandonado el país, Jehová no ve nada’.

**10** Pero así haré yo: mis ojos no sentirán lástima, no tendré compasión. Haré que las consecuencias de su conducta recaigan sobre su propia cabeza”.

**11** Entonces vi al hombre vestido de lino con el tintero en la cintura que volvía para dar su informe. Dijo: “He hecho exactamente lo que me mandaste”.

### Notas a pie de página
- **v. 2:** O “estuche con los útiles de escriba”.
- **v. 3:** Según parece, se refiere a Dios.
- **v. 4:** O “gimen”.

---

## Ezequiel 10

**1** Mientras miraba, vi algo como una piedra de zafiro por encima de los querubines, sobre la plataforma que estaba por encima de sus cabezas; era algo que parecía un trono.

**2** Entonces él le dijo al hombre vestido de lino: “Métete entre las ruedas, debajo de los querubines, llena tus manos con brasas ardientes sacadas de entre los querubines y lánzalas sobre la ciudad”. Así que, mientras yo miraba, él entró.

**3** Los querubines estaban de pie a la derecha de la casa cuando el hombre entró, y la nube llenó el patio interior.

**4** Y la gloria de Jehová se elevó desde donde estaban los querubines hasta el umbral de la puerta de la casa, y la casa se fue llenando de la nube; y el patio estaba lleno del resplandor de la gloria de Jehová.

**5** El ruido de las alas de los querubines se oía en el patio exterior, como la voz del Dios Todopoderoso cuando habla.

**6** Entonces él le ordenó al hombre vestido de lino: “Toma fuego de entre las ruedas, de entre los querubines”. Y este entró y se quedó de pie al lado de una de las ruedas.

**7** Luego, uno de los querubines extendió la mano hacia el fuego que había entre los querubines. Tomó un poco y lo puso en las manos del que iba vestido de lino. Este lo tomó y salió de allí.

**8** Los querubines tenían bajo las alas algo parecido a la forma de manos humanas.

**9** Mientras miraba, vi cuatro ruedas al lado de los querubines, una rueda al lado de cada querubín, y las ruedas parecían brillar como el crisólito.

**10** En cuanto a su aspecto, las cuatro eran iguales; era como si hubiera una rueda dentro de otra rueda.

**11** Cuando se movían, podían ir en cualquiera de las cuatro direcciones sin girar, porque iban hacia donde estaba orientada la cabeza de los querubines, sin girar.

**12** Su cuerpo entero, su espalda, sus manos y sus alas, así como las ruedas, las ruedas de los cuatro, estaban llenos de ojos todo alrededor.

**13** En cuanto a las ruedas, oí una voz que les gritó: “¡Ruedas!”.

**14** Cada uno tenía cuatro caras. La primera cara era la cara del querubín, la segunda cara era la cara de un hombre, la tercera era la cara de un león y la cuarta era la cara de un águila.

**15** Y los querubines se elevaban —eran los mismos seres vivientes que yo había visto junto al río Kebar—;

**16** cuando los querubines se movían, las ruedas se movían junto a ellos; y, cuando los querubines levantaban las alas para elevarse muy por encima del suelo, las ruedas ni giraban ni se apartaban de su lado.

**17** Cuando ellos se detenían, estas se detenían; y, cuando ellos se levantaban, estas se levantaban a la vez, porque el espíritu que actuaba en los seres vivientes estaba en las ruedas.

**18** Entonces la gloria de Jehová se fue de encima del umbral de la puerta de la casa y se detuvo sobre los querubines.

**19** Los querubines levantaron las alas y se elevaron del suelo mientras yo miraba. Las ruedas también estaban al lado de ellos cuando se fueron. Se detuvieron a la entrada de la puerta oriental de la casa de Jehová, y la gloria del Dios de Israel estaba sobre ellos.

**20** Estos eran los seres vivientes que yo había visto bajo el Dios de Israel junto al río Kebar; así me enteré de que eran querubines.

**21** Los cuatro tenían cuatro caras y cuatro alas, también algo parecido a manos humanas bajo sus alas.

**22** Y sus caras eran como las caras que yo había visto junto al río Kebar. Cada uno iba hacia adelante.

### Notas a pie de página
- **v. 1:** Lit. “expansión”.
- **v. 2:** Según parece, se refiere a Dios.
- **v. 6:** Según parece, se refiere a Dios.
- **v. 11:** O “sin volverse”.
- **v. 11:** Lit. “la cabeza”.
- **v. 13:** O “¡Rueden!”.
- **v. 14:** Es decir, cada uno de los querubines.
- **v. 14:** O “ser humano”.
- **v. 15:** Lit. “era el ser viviente”.
- **v. 17:** Lit. “el espíritu del ser viviente”.
- **v. 20:** Lit. “Este es el ser viviente”.

---

## Ezequiel 11

**1** Y un espíritu me levantó y me llevó a la puerta oriental de la casa de Jehová, la puerta que da al este. Ahí, a la entrada de la puerta, vi 25 hombres, entre quienes estaban Jaazanías hijo de Azur y Pelatías hijo de Benaya, príncipes del pueblo.

**2** Entonces él me dijo: “Hijo del hombre, estos son los hombres que están tramando el mal y dando malos consejos en esta ciudad.

**3** Andan diciendo: ‘¿Acaso no es el momento de construir casas? La ciudad es la olla y nosotros somos la carne’.

**4** ”Así que profetiza contra ellos. Profetiza, hijo del hombre”.

**5** Entonces el espíritu de Jehová vino sobre mí, y él me dijo: “Dirás: ‘Esto es lo que dice Jehová: “Oh, casa de Israel, lo que ustedes han dicho es correcto, y sé lo que están pensando.

**6** Han causado la muerte de muchos en esta ciudad, han llenado las calles de muertos”’”.

**7** “Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Los cadáveres que ustedes han esparcido por toda la ciudad son la carne, y la ciudad es la olla. Pero a ustedes se les sacará de ella’”.

**8** “‘Han temido a la espada, y la espada mandaré contra ustedes —afirma el Señor Soberano Jehová—.

**9** Los sacaré de ella, los entregaré en manos de extranjeros y ejecutaré mi sentencia contra ustedes.

**10** A espada caerán. En la frontera de Israel los juzgaré, y tendrán que saber que yo soy Jehová.

**11** La ciudad no será su olla y ustedes no serán la carne dentro de ella. En la frontera de Israel los juzgaré,

**12** y tendrán que saber que yo soy Jehová. Porque no anduvieron según mis normas ni cumplieron mis decisiones judiciales, sino que actuaron según las decisiones judiciales de las naciones de alrededor’”.

**13** En cuanto acabé de profetizar, murió Pelatías hijo de Benaya, y yo caí rostro a tierra y grité con fuerza: “¡Ay, Señor Soberano Jehová! ¿Vas a exterminar a todos los que quedan de Israel?”.

**14** Recibí de nuevo las palabras de Jehová. Me dijo:

**15** “Hijo del hombre, los habitantes de Jerusalén les han dicho a tus hermanos —a los que tienen el derecho de recompra— y a toda la casa de Israel: ‘Quédense lejos de Jehová. La tierra es nuestra, nos la han dado en propiedad’.

**16** Por lo tanto, dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “Aunque los he llevado lejos, entre las naciones, y los he dispersado por los países, yo seré para ellos durante un poco de tiempo un santuario en los países a los que han ido”’.

**17** ”Por lo tanto, dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “También los juntaré de entre los pueblos y los reuniré de entre los países por los que han sido dispersados, y les daré la tierra de Israel.

**18** Y ellos regresarán allí y harán que desaparezcan de ella todas sus cosas repugnantes y sus prácticas detestables.

**19** Unificaré su corazón y pondré en ellos un espíritu nuevo; quitaré de su cuerpo el corazón de piedra y les daré un corazón de carne

**20** para que anden según mis estatutos y para que cumplan mis decisiones judiciales y las obedezcan. Entonces ellos serán mi pueblo y yo seré su Dios”’.

**21** ”‘“Pero, a los que tienen el corazón aferrado a sus cosas repugnantes y a sus prácticas detestables..., sobre su cabeza haré que recaigan las consecuencias de su conducta”, afirma el Señor Soberano Jehová’”.

**22** Los querubines levantaron sus alas; cerca de ellos, estaban las ruedas y, sobre ellos, la gloria del Dios de Israel.

**23** Entonces la gloria de Jehová se elevó desde la ciudad y se detuvo sobre la montaña que está al este de la ciudad.

**24** Luego un espíritu me levantó —en la visión que tuve por medio del espíritu de Dios— y me llevó adonde estaba el pueblo desterrado, a Caldea. Después, la visión que yo había visto me dejó.

**25** Y me puse a contarle al pueblo desterrado todas las cosas que Jehová me había mostrado.

### Notas a pie de página
- **v. 2:** Según parece, se refiere a Dios.
- **v. 2:** O “contra”.
- **v. 3:** Lit. “Ella”, es decir, la ciudad de Jerusalén, donde los judíos creían que estarían protegidos.
- **v. 3:** O “la olla de boca ancha”.
- **v. 5:** Según parece, se refiere a Dios.
- **v. 5:** O “las cosas que suben en su espíritu”.
- **v. 19:** Lit. “Les daré un solo corazón”.
- **v. 19:** Es decir, receptivo a la guía de Dios.

---

## Ezequiel 12

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vives en una casa rebelde. Tienen ojos para ver, pero no ven; tienen oídos para oír, pero no oyen, porque son una casa rebelde.

**3** Tú, hijo del hombre, prepara tu equipaje para irte al destierro. Entonces vete al destierro durante el día, mientras ellos estén mirando. Vete al destierro, de tu casa a otro lugar, mientras ellos estén mirando. Tal vez presten atención, aunque son una casa rebelde.

**4** Durante el día, mientras ellos estén mirando, saca el equipaje para ir al destierro. Luego, al anochecer, mientras ellos estén mirando, debes salir como alguien a quien llevan al destierro.

**5** ”Mientras ellos estén mirando, abre un agujero en la pared y saca tus pertenencias a través de él.

**6** Mientras ellos estén mirando, échate tus pertenencias al hombro y sácalas en la oscuridad. Tápate la cara para no ver el suelo, porque te estoy convirtiendo en una señal para la casa de Israel”.

**7** Yo hice exactamente lo que se me mandó. Durante el día, saqué mi equipaje, el equipaje que uno se lleva al destierro. Al anochecer, abrí con las manos un agujero en la pared. Y, cuando ya estaba oscuro, saqué mis pertenencias llevándolas al hombro; lo hice ante sus ojos.

**8** Por la mañana recibí de nuevo las palabras de Jehová. Me dijo:

**9** “Hijo del hombre, ¿acaso no te ha preguntado la casa de Israel, la casa rebelde, ‘¿Qué estás haciendo?’?

**10** Diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Esta declaración tiene que ver con el jefe que está en Jerusalén y con toda la casa de Israel que está en la ciudad”’.

**11** ”Dirás: ‘Soy una señal para ustedes. Lo mismo que yo he hecho, se les hará a ellos. Irán al destierro, al cautiverio.

**12** El jefe que esté entre ellos cargará sus pertenencias al hombro y saldrá en la oscuridad. Abrirá un agujero en la muralla y sacará sus pertenencias a través de él. Se tapará la cara para no ver el suelo’.

**13** Yo le echaré mi red encima, quedará atrapado en mi red de caza. Entonces lo llevaré a Babilonia, a la tierra de los caldeos, pero no la verá; y allí morirá.

**14** Y a todos los que lo rodean, a sus ayudantes y a sus tropas, los dispersaré en todas direcciones; y desenvainaré una espada para perseguirlos.

**15** Y ellos tendrán que saber que yo soy Jehová cuando los disperse por las naciones y los esparza entre los países.

**16** Pero libraré a unos pocos de la espada, el hambre y la peste para que hablen de todas sus prácticas detestables entre las naciones a las que irán; y tendrán que saber que yo soy Jehová”.

**17** Recibí de nuevo las palabras de Jehová. Me dijo:

**18** “Hijo del hombre, come tu pan con temblores y bebe tu agua con agitación y angustia.

**19** Dile a la gente del país: ‘Esto es lo que les dice el Señor Soberano Jehová a los habitantes de Jerusalén que están en la tierra de Israel: “Comerán su pan con angustia y beberán su agua con terror, porque su tierra quedará completamente desolada por culpa de la violencia de todos los que viven en ella.

**20** Las ciudades habitadas quedarán en ruinas y la tierra se convertirá en un lugar abandonado; y ustedes tendrán que saber que yo soy Jehová”’”.

**21** Recibí de nuevo las palabras de Jehová. Me dijo:

**22** “Hijo del hombre, ¿qué es ese proverbio que ustedes tienen en Israel, que dice: ‘Pasan los días y todas las visiones acaban en nada’?

**23** Por lo tanto, diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Acabaré con ese dicho, ya no lo usarán como un proverbio en Israel”’. Pero diles: ‘Se acercan los días, y todas las visiones se cumplirán’.

**24** Porque ya no habrá ninguna visión falsa ni adivinación aduladora en la casa de Israel.

**25** ‘“Porque yo, Jehová, hablaré. Cualquier palabra que yo diga se cumplirá sin más demora. Oh, casa rebelde, en vida de ustedes diré la palabra y la llevaré a cabo”, afirma el Señor Soberano Jehová’”.

**26** Recibí de nuevo las palabras de Jehová. Me dijo:

**27** “Hijo del hombre, esto es lo que el pueblo de Israel anda diciendo: ‘La visión que él tiene es para dentro de mucho tiempo y está profetizando sobre el futuro lejano’.

**28** Por lo tanto, diles: ‘Esto es lo que dice el Señor Soberano Jehová: “‘Ni una de mis palabras se demorará; cualquier cosa que yo diga se cumplirá’, afirma el Señor Soberano Jehová”’”.

### Notas a pie de página
- **v. 24:** O “engañosa”.
- **v. 27:** Lit. “la casa”.

---

## Ezequiel 13

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, profetiza contra los profetas de Israel y diles a esos que se inventan sus propias profecías: ‘Oigan las palabras de Jehová.

**3** Esto es lo que dice el Señor Soberano Jehová: “¡Ay de los profetas insensatos, que siguen sus propias ideas sin haber visto nada!

**4** Oh, Israel, tus profetas se han vuelto como zorros entre las ruinas.

**5** Ustedes no irán a las brechas de las murallas de piedra a fin de reconstruirlas para la casa de Israel, de modo que Israel se mantenga en pie en la batalla en el día de Jehová”.

**6** “Han tenido visiones falsas y han predicho mentiras; andan diciendo ‘Estas son las palabras de Jehová’, a pesar de que Jehová mismo no los ha enviado, y todavía esperan que sus palabras se cumplan.

**7** ¿Acaso no es una visión falsa lo que ustedes han tenido y una mentira lo que ustedes han predicho diciendo ‘Estas son las palabras de Jehová’, a pesar de que yo no he dicho nada?”’.

**8** ”‘Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “‘Como ustedes han dicho falsedades y sus visiones son mentira, yo estoy contra ustedes’, afirma el Señor Soberano Jehová”.

**9** Mi mano está contra esos profetas que tienen visiones falsas y que predicen una mentira. No se encontrarán entre mis personas de confianza, ni estarán inscritos en el registro de la casa de Israel, ni regresarán a la tierra de Israel; y ustedes tendrán que saber que yo soy el Señor Soberano Jehová.

**10** Todo eso pasará porque ellos han descarriado a mi pueblo diciendo “¡Hay paz!”, cuando no hay paz. Cuando alguien construye una pared frágil, ellos la recubren con cal’.

**11** ”A esos que recubren la pared con cal, diles que se va a caer. Vendrá una lluvia torrencial y caerá granizo, y fuertes vientos de tormenta la derribarán.

**12** Y, cuando la pared se caiga, les preguntarán: ‘¿Dónde está la capa de cal?’.

**13** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘En mi ira desataré fuertes vientos de tormenta; en mi furia, una lluvia torrencial, y en mi furor destructivo, granizo.

**14** Demoleré la pared que ustedes recubrieron con cal y la haré caer al suelo, y sus cimientos quedarán a la vista. Cuando caiga la ciudad, ustedes morirán dentro de ella; y tendrán que saber que yo soy Jehová’.

**15** ”‘Cuando suelte toda mi ira sobre la pared y sobre esos que la recubrieron con cal, les diré: “La pared ya no existe y los que la recubrieron con cal ya no están.

**16** Los profetas de Israel han desaparecido, esos que profetizaban sobre Jerusalén y que tenían para ella visiones de paz cuando no había paz”’, afirma el Señor Soberano Jehová.

**17** ”Tú, hijo del hombre, enfréntate a las hijas de tu pueblo que se están inventando sus propias profecías y profetiza contra ellas.

**18** Diles: ‘Esto es lo que dice el Señor Soberano Jehová: “¡Ay de las mujeres que a fin de atrapar la vida de la gente cosen bandas para todos los brazos y hacen velos para cabezas de todas las tallas! ¿Están ustedes atrapando la vida de mi pueblo y tratan de salvar su propia vida?

**19** Por unos puñados de cebada y unos pedazos de pan, ¿me profanarán entre mi pueblo matando a los que no tendrían que morir y dejando con vida a los que no deberían vivir? Hacen eso al mentirle a mi pueblo, que escucha sus mentiras”’.

**20** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Oh, mujeres, aquí estoy en contra de las bandas que ustedes usan para atrapar a la gente como si fueran pájaros; las arrancaré de sus brazos y liberaré a los que ustedes están atrapando como pájaros.

**21** Arrancaré sus velos y rescataré a mi pueblo de sus manos, ellos ya no serán algo que puedan atrapar; y ustedes tendrán que saber que yo soy Jehová.

**22** Porque han desanimado a los justos con su falsedad cuando yo no les estaba causando angustia a ellos y han fortalecido las manos de los malvados para que no dejen su mal camino y así sigan viviendo.

**23** Por eso, mujeres, ya no tendrán más visiones falsas ni practicarán la adivinación; y yo rescataré a mi pueblo de sus manos, y ustedes tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 2:** O “que profetizan de su propio corazón”.
- **v. 3:** Lit. “su propio espíritu”.
- **v. 10:** O “enlucen con cal”. Es decir, alguien construye una pared interior frágil y ellos la cubren con cal para que parezca fuerte.
- **v. 11:** O “una lluvia torrencial, y ustedes, oh, piedras de granizo, caerán”.
- **v. 18:** Es decir, bandas mágicas que se ponían en los codos o en las muñecas.
- **v. 22:** O “dolor”.

---

## Ezequiel 14

**1** Algunos de los ancianos de Israel vinieron y se sentaron delante de mí.

**2** Entonces recibí las palabras de Jehová. Me dijo:

**3** “Hijo del hombre, estos hombres están empeñados en seguir a sus ídolos repugnantes y le han puesto a la gente un obstáculo que la hace pecar. ¿Acaso debería permitir que me consultaran?

**4** Así que habla con ellos y diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Si un israelita se empeña en seguir a sus ídolos repugnantes y le pone a la gente un obstáculo que la hace pecar y después va a consultar a un profeta, yo, Jehová, le responderé como se merece por sus muchos ídolos repugnantes.

**5** Y es que llenaré de terror el corazón de los de la casa de Israel porque todos se han apartado de mí y han seguido a sus ídolos repugnantes”’.

**6** ”De modo que dile a la casa de Israel: ‘Esto es lo que dice el Señor Soberano Jehová: “Regresen a mí, aléjense de sus ídolos repugnantes y aparten el rostro de todas sus prácticas detestables.

**7** Porque, si algún israelita o extranjero que viva en Israel se separa de mí, se empeña en seguir a sus ídolos repugnantes y le pone a la gente un obstáculo que la hace pecar y después va a consultar a mi profeta, yo, Jehová, le responderé personalmente.

**8** Me enfrentaré a ese hombre, lo convertiré en una señal de advertencia y en un tema de proverbios, y lo eliminaré de mi pueblo. Y ustedes tendrán que saber que yo soy Jehová”’.

**9** ”‘Pero, si el profeta es engañado y da una respuesta, soy yo, Jehová, quien ha engañado a ese profeta. Entonces extenderé mi mano contra él y lo eliminaré de mi pueblo Israel.

**10** Tendrán que cargar con su culpa; la culpa del que consulta será la misma que la culpa del profeta,

**11** para que la casa de Israel no siga andando sin rumbo, distanciándose de mí, ni siga contaminándose con todas sus ofensas. Y ellos serán mi pueblo y yo seré su Dios’, afirma el Señor Soberano Jehová”.

**12** Recibí de nuevo las palabras de Jehová. Me dijo:

**13** “Hijo del hombre, si un país peca contra mí actuando infielmente, extenderé mi mano contra él y destruiré su suministro de alimento; le mandaré hambre a ese país y eliminaré de él a hombre y animal.

**14** ‘Aun si estos tres hombres —Noé, Daniel y Job— estuvieran en ese país, por su justicia podrían salvarse solo a sí mismos’, afirma el Señor Soberano Jehová”.

**15** “‘O supongamos que yo hiciera pasar por el país fieras salvajes que lo despoblaran y lo convirtieran en un desierto que nadie se animaría a cruzar por miedo a las fieras.

**16** Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, aun si estos tres hombres estuvieran en él, no salvarían ni a sus hijos ni a sus hijas; se salvarían solo a sí mismos y el país quedaría desolado’”.

**17** “‘O supongamos que mandara una espada contra ese país y dijera “Que una espada atraviese el país” y eliminara de él a hombre y animal.

**18** Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, aun si estos tres hombres estuvieran en él, no salvarían ni a sus hijos ni a sus hijas; se salvarían solo a sí mismos’”.

**19** “‘O supongamos que mandara una peste a ese país y volcara mi furia sobre él con derramamiento de sangre para eliminar de él a hombre y animal.

**20** Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, si Noé, Daniel y Job estuvieran en él, no salvarían ni a sus hijos ni a sus hijas; por su justicia se salvarían solo a sí mismos’”.

**21** “Porque esto es lo que dice el Señor Soberano Jehová: ‘Así será cuando mande contra Jerusalén mis cuatro castigos —espada, hambre, fieras salvajes y peste— para eliminar de ella a hombre y animal.

**22** Pero algunos que quedarán en ella, tanto hijos como hijas, sobrevivirán y serán llevados afuera. Vendrán a ustedes, y, cuando ustedes vean su conducta y sus acciones, sin duda encontrarán consuelo por la calamidad que traje sobre Jerusalén, por todo lo que le hice’”.

**23** “‘Ellos los consolarán cuando ustedes vean su conducta y sus acciones, y ustedes sabrán que no me faltaron motivos para hacerle a ella lo que le hice’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 3:** O “tropiezo”.
- **v. 5:** Lit. “atraparé a la casa de Israel en su corazón”.
- **v. 13:** Lit. “quebraré las varas de pan”. Posiblemente se refiere a las varas para colgar y almacenar el pan.
- **v. 15:** O “lo dejaran sin hijos”.
- **v. 21:** O “actos terribles de juicio”.

---

## Ezequiel 15

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, ¿cómo es la madera de la vid si se compara con la de cualquier otro árbol o rama de los árboles del bosque?

**3** ¿Puede hacerse algún trabajo con una vara sacada de la vid? ¿O fabrica la gente un gancho con ella para colgar utensilios?

**4** Fíjate, como leña, se echa al fuego, y el fuego consume sus extremos y la chamusca por el centro. ¿Sirve ahora para hacer algún trabajo?

**5** Si cuando estaba intacta no servía para nada, ¡mucho menos cuando el fuego la ha consumido y chamuscado!”.

**6** “Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Así como he hecho con la madera de la vid entre los árboles del bosque, que la he dado como leña para el fuego, así haré con los habitantes de Jerusalén.

**7** Me he enfrentado a ellos. Han escapado del fuego, pero el fuego los consumirá. Y ustedes tendrán que saber que yo soy Jehová cuando me enfrente a ellos’”.

**8** “‘Y haré que la tierra quede desolada porque ellos han actuado infielmente’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 4:** O “combustible”.

---

## Ezequiel 16

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, hazle saber a Jerusalén sus prácticas detestables.

**3** Dirás: ‘Esto es lo que el Señor Soberano Jehová le dice a Jerusalén: “Por tu origen y nacimiento, eres de la tierra del cananeo. Tu padre era amorreo y tu madre hitita.

**4** El día de tu nacimiento, el día en que naciste, no te cortaron el cordón umbilical, no te lavaron con agua para que quedaras limpia, no te frotaron con sal y no te envolvieron con telas.

**5** Nadie tuvo lástima de ti como para hacerte alguna de estas cosas. Nadie se compadeció de ti. Al contrario, te arrojaron al campo abierto porque te odiaron el día en que naciste.

**6** ”’”Cuando yo iba pasando por allí, te vi pataleando en tu propia sangre. Y, mientras estabas tendida en tu sangre, yo te dije: ‘¡Sigue viviendo!’. Sí, yo te dije mientras estabas tendida en tu sangre: ‘¡Sigue viviendo!’.

**7** Hice de ti una multitud muy grande, como las plantas que brotan en el campo, y tú creciste y te desarrollaste, y llevabas los mejores adornos. Tus pechos se hicieron firmes y te creció el pelo; pero todavía andabas desnuda, sin nada de ropa”’.

**8** ”‘Cuando yo iba pasando por allí y te vi, me di cuenta de que ya tenías edad para las expresiones de amor. Así que extendí mi manto sobre ti, cubrí tu desnudez, hice un juramento y me uní en un pacto contigo —afirma el Señor Soberano Jehová—, y tú llegaste a ser mía.

**9** Además, te lavé con agua, te enjuagué la sangre y te unté con aceite.

**10** Luego te puse un vestido bordado, te di sandalias de cuero fino, te envolví con lino de calidad y te vestí con ropas caras.

**11** Te puse adornos: en tus muñecas, brazaletes; en tu cuello, un collar.

**12** Además, en la nariz te puse un aro; en las orejas, aretes y, en la cabeza, una hermosa corona.

**13** Te arreglabas con oro y plata, y te vestías con lino de calidad, con tejidos caros y con un vestido bordado. Tu comida era harina fina, miel y aceite, y llegaste a ser bellísima; estabas lista para ser reina’”.

**14** “‘Tu fama comenzó a extenderse entre las naciones por tu belleza, porque era perfecta gracias a que yo había puesto mi propio esplendor sobre ti’, afirma el Señor Soberano Jehová”.

**15** “‘Pero tú empezaste a confiar en tu belleza y, por tu fama, te convertiste en una prostituta. Te prostituías desenfrenadamente con cualquiera que pasaba por ahí y le entregabas tu belleza.

**16** Tomaste algunas de tus ropas e hiciste con ellas lugares altos de vivos colores, y allí te prostituías. Estas cosas no deberían pasar, no deberían suceder jamás.

**17** También tomaste tus joyas preciosas, hechas con el oro y la plata que yo te había dado, y las transformaste en imágenes masculinas, y con ellas te prostituiste.

**18** Y tomaste tus vestidos bordados y con ellos las cubriste; y les ofreciste mi aceite y mi incienso.

**19** Y el pan que yo te había dado, que te di para que lo comieras —pan hecho con harina fina, aceite y miel—, tú también se lo ofreciste a ellas como un aroma agradable. Eso es exactamente lo que sucedió’, afirma el Señor Soberano Jehová”.

**20** “‘Tomaste a los hijos y a las hijas que habías dado a luz para mí y los sacrificaste a ídolos para que fueran devorados... ¿Es que no te bastaba con tus actos de prostitución?

**21** Mataste a mis hijos y los sacrificaste quemándolos en el fuego.

**22** Mientras practicabas todas esas cosas detestables y te prostituías, no te acordaste de los días en que eras joven, cuando estabas desnuda, sin nada de ropa, y pataleando en tu propia sangre.

**23** Después de toda tu maldad, ay, ay de ti —afirma el Señor Soberano Jehová—.

**24** Te construiste un montículo y te hiciste un lugar alto en cada plaza.

**25** Construiste tus lugares altos en el punto más destacado de cada calle, convertiste tu belleza en algo detestable al ofrecerte a cualquiera que pasara por ahí, y multiplicaste tus actos de prostitución.

**26** Te prostituías con los hijos de Egipto, tus lujuriosos vecinos, y provocabas mi ira con tus incontables actos de prostitución.

**27** Ahora extenderé mi mano contra ti, reduciré tu ración de alimento y te entregaré al capricho de las mujeres que te odian, las hijas de los filisteos, que estaban horrorizadas por tu comportamiento obsceno.

**28** ”’Entonces, como eres insaciable, te prostituiste con los hijos de Asiria. Pero, después de prostituirte con ellos, todavía seguías insatisfecha.

**29** Así que te prostituiste todavía más, en la tierra de los comerciantes y con los caldeos. Pero, con todo, seguías insatisfecha.

**30** ¡Qué enfermo estaba tu corazón —afirma el Señor Soberano Jehová— para que hicieras todas esas cosas portándote como una prostituta descarada!

**31** Sin embargo, cuando construías tu montículo en el punto más destacado de cada calle y hacías tu lugar alto en cada plaza, no eras como una prostituta, porque rechazabas cualquier pago.

**32** ¡Eres una esposa adúltera, que recibe a extraños en vez de a su propio esposo!

**33** A todas las prostitutas les dan regalos; pero, en tu caso, eres tú quien les ha dado regalos a los que te desean apasionadamente, y los sobornas para que vengan a ti de todas partes para prostituirte con ellos.

**34** Tú eres lo opuesto a otras mujeres que se dedican a la prostitución. ¡Nadie se prostituye como lo haces tú! Tú les pagas a los demás en vez de que ellos te paguen a ti. Lo haces al revés’.

**35** ”Por eso, tú, prostituta, oye las palabras de Jehová.

**36** Esto es lo que dice el Señor Soberano Jehová: ‘Tu lujuria se ha derramado y tu desnudez ha quedado al descubierto mientras te prostituías con tus amantes y con todos tus ídolos repugnantes y detestables, a los que llegaste a ofrecerles la sangre de tus hijos.

**37** Por eso, voy a reunir a todos los amantes a los que les diste placer, a todos los que amaste y a todos los que odiaste. De todas partes los juntaré para ir contra ti y pondré al descubierto tu desnudez ante ellos, y te verán completamente desnuda.

**38** ”’Y te voy a aplicar los castigos que se merecen las adúlteras y las mujeres que derraman sangre; tu sangre se derramará con furia y celos.

**39** Te voy a entregar en manos de tus amantes. Ellos derribarán tus montículos y echarán abajo tus lugares altos; te quitarán la ropa, se llevarán tus preciosas joyas y te dejarán desnuda, sin nada de ropa.

**40** Traerán una multitud contra ti; te apedrearán y te matarán con sus espadas.

**41** Quemarán tus casas con fuego y ejecutarán en ti mi sentencia ante los ojos de muchas mujeres; le pondré fin a tu prostitución, y tú ya no harás más pagos.

**42** Saciaré mi furia contra ti y mi indignación se alejará de ti; me calmaré y ya no me sentiré provocado’.

**43** ”‘Como no te acordaste de los días en que eras joven y me enfureciste al hacer todas esas cosas, haré que recaigan sobre tu propia cabeza las consecuencias de tu conducta —afirma el Señor Soberano Jehová—, y ya no seguirás con tu comportamiento obsceno ni con tus prácticas detestables.

**44** ”’Mira, todos los que usan refranes te aplicarán este refrán: “De tal madre, tal hija”.

**45** Tú eres hija de tu madre, que detestaba a su esposo y a sus hijos. Y eres hermana de tus hermanas, que detestaban a sus esposos y a sus hijos. La madre de ustedes era hitita y su padre amorreo’”.

**46** “‘Tu hermana mayor es Samaria, que vive con sus hijas al norte de ti, y tu hermana menor es Sodoma, que vive con sus hijas al sur de ti.

**47** No solo anduviste en sus caminos y copiaste sus prácticas detestables, sino que en poco tiempo tu comportamiento se volvió más corrupto que el de ellas.

**48** Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, tu hermana Sodoma y sus hijas no han hecho lo que tú y tus hijas han hecho.

**49** Fíjate, este fue el error de tu hermana Sodoma: ella y sus hijas eran orgullosas; tenían comida en abundancia y vivían despreocupadas y, aun así, no ayudaron ni al que sufre ni al pobre.

**50** No dejaron de ser arrogantes y siguieron con sus prácticas detestables a mi vista, así que no tuve más remedio que acabar con ellas.

**51** ”’Tampoco Samaria cometió ni la mitad de los pecados que tú cometiste. Tú hiciste que tus prácticas detestables fueran muchas, más que las de ellas; eran tantas tus prácticas detestables que a tu lado tus hermanas parecían justas.

**52** Ahora tienes que cargar con tu humillación, porque has justificado el comportamiento de tus hermanas. Por tu pecado, por actuar de manera más detestable que ellas, ellas son más justas que tú. Así que ahora avergüénzate y carga con la humillación de haber hecho que tus hermanas parezcan justas’.

**53** ”‘Y reuniré a sus cautivos: los cautivos de Sodoma y sus hijas y los cautivos de Samaria y sus hijas; junto con ellos también reuniré a tus cautivos

**54** para que cargues con tu humillación; y te sentirás humillada por lo que has hecho, por haberlas consolado.

**55** Tu hermana Sodoma y sus hijas volverán a ser como antes; tu hermana Samaria y sus hijas volverán a ser como antes, y tú, junto con tus propias hijas, volverás a ser como antes.

**56** Tu hermana Sodoma no merecía que la mencionaras en los días en que te sentías orgullosa,

**57** antes de que tu propia maldad quedara al descubierto. Ahora las hijas de Siria y sus vecinas te insultan, y las hijas de los filisteos, las que te rodean, te tratan con desprecio.

**58** Cargarás con las consecuencias de tu comportamiento obsceno y de tus prácticas detestables’, afirma Jehová”.

**59** “Porque esto es lo que dice el Señor Soberano Jehová: ‘Ahora yo te haré a ti lo mismo que tú has hecho, ya que, al romper mi pacto, despreciaste el juramento.

**60** Pero yo mismo me acordaré del pacto que hice contigo en los días de tu juventud y estableceré un pacto permanente contigo.

**61** Te acordarás de tu comportamiento y te sentirás humillada cuando recibas a tus hermanas, tanto a las mayores como a las menores que tú; y te las daré como hijas, aunque no por un pacto hecho contigo’.

**62** ”‘Y yo mismo estableceré mi pacto contigo; y tendrás que saber que yo soy Jehová.

**63** Entonces, cuando haga expiación por ti —a pesar de todo lo que has hecho—, te acordarás de lo que has hecho y te sentirás demasiado avergonzada como para abrir la boca, de lo humillada que vas a estar’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 8:** O “falda”.
- **v. 10:** O “piel de foca”.
- **v. 11:** O “manos”.
- **v. 13:** O “para un puesto de la realeza”.
- **v. 14:** Lit. “nombre”.
- **v. 17:** O “tus adornos preciosos, hechos”.
- **v. 18:** Es decir, las imágenes masculinas.
- **v. 19:** O “que aplaca”, “que calma”. Lit. “relajante”.
- **v. 21:** O “haciéndolos pasar por”.
- **v. 25:** Lit. “abrirte de piernas”.
- **v. 26:** Lit. “vecinos grandes de carne”.
- **v. 29:** Lit. “de Canaán”.
- **v. 30:** O “débil”.
- **v. 30:** O quizás “Oh, qué lleno de furia estoy contra ti”.
- **v. 39:** O “preciosos adornos”.
- **v. 46:** Probablemente se refiere a poblaciones dependientes.
- **v. 46:** Lit. “a tu izquierda”.
- **v. 46:** Lit. “a tu derecha”.
- **v. 52:** O “has declarado a favor”.

---

## Ezequiel 17

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, cuenta un enigma y relata una parábola sobre la casa de Israel.

**3** Dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “La gran águila de inmensas alas y largas plumas, de plumaje abundante y colorido, vino al Líbano y tomó la punta del cedro.

**4** Arrancó el brote más alto, lo llevó a la tierra de los comerciantes y lo plantó en una ciudad de comerciantes.

**5** Luego tomó semilla de la tierra y la plantó en un terreno fértil. La plantó como se planta un sauce a la orilla de aguas caudalosas.

**6** De modo que brotó y se hizo una vid baja y desbordante. Dirigía sus ramas hacia ella misma y sus raíces crecían debajo de ella. Así se convirtió en una vid, y produjo brotes y echó ramas.

**7** ”’”Y vino otra gran águila de inmensas alas y grandes plumas. Entonces la vid extendió sus raíces hacia ella con ansias, lejos de las porciones de tierra donde estaba plantada, y alargó sus ramas hacia el águila para que esta la regara.

**8** Ya había sido plantada en un buen terreno, cerca de aguas caudalosas, para que echara ramas, diera fruto y se convirtiera en una vid majestuosa”’.

**9** ”Dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “¿Prosperará? ¿Acaso no arrancarán sus raíces y harán que su fruto se pudra y sus brotes se marchiten? Quedará tan seca que no hará falta ni un brazo fuerte ni mucha gente para arrancarla de raíz.

**10** Aun trasplantada, ¿prosperará? ¿No se secará por completo cuando le dé el viento del este? Se secará en la porción de tierra donde había brotado”’”.

**11** Recibí de nuevo las palabras de Jehová. Me dijo:

**12** “Dile, por favor, a la casa rebelde: ‘¿Acaso no ven lo que significan estas cosas?’. Dirás: ‘Fíjense, el rey de Babilonia vino a Jerusalén, capturó al rey y a sus príncipes y se los llevó con él a Babilonia.

**13** Además, tomó a uno de la descendencia real, hizo un pacto con él y lo puso bajo juramento. Entonces se llevó a los hombres importantes del país

**14** para que el reino fuera rebajado, incapaz de levantarse, de modo que solo pudiera permanecer en pie si se cumplía el pacto que él había hecho.

**15** Pero el rey acabó rebelándose contra él cuando mandó a sus mensajeros a Egipto para que le proporcionaran caballos y un ejército grande. ¿Le irá bien? ¿Podrá librarse del castigo el que hace esas cosas? ¿Acaso puede romper el pacto y aun así librarse?’.

**16** ”‘“Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, él morirá en Babilonia, donde vive el rey que lo hizo rey, cuyo juramento él despreció y cuyo pacto él rompió.

**17** El gran ejército y las numerosas tropas del faraón no le servirán de nada en la guerra cuando levanten rampas de ataque y construyan muros de asedio para acabar con muchas vidas.

**18** Él ha despreciado un juramento y ha roto un pacto. Aunque dio su palabra, él ha hecho todas estas cosas. No se librará”’.

**19** ”‘Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “Tan cierto como que yo vivo, haré que recaigan sobre su cabeza las consecuencias de haber despreciado mi juramento y haber roto mi pacto.

**20** Le echaré mi red encima, quedará atrapado en mi red de caza. Lo llevaré a Babilonia y allí entraré en juicio con él por haberme sido infiel.

**21** Todos los fugitivos de sus tropas caerán a espada y los que queden serán dispersados en todas direcciones. Entonces ustedes tendrán que saber que yo, Jehová, he hablado”’.

**22** ”‘Esto es lo que dice el Señor Soberano Jehová: “Tomaré un brote de la punta del alto cedro y lo plantaré; de la punta de sus ramitas arrancaré un brote tierno, y yo mismo lo plantaré en una montaña alta y elevada.

**23** Lo plantaré en una montaña alta de Israel, y sus ramas crecerán; dará fruto y se convertirá en un cedro majestuoso. Y aves de todo tipo vivirán debajo de él y residirán a la sombra de sus ramas.

**24** Y todos los árboles del campo tendrán que saber que yo, Jehová, he rebajado al árbol alto y he engrandecido al árbol bajo; al árbol verde lo he secado y al árbol seco lo he hecho florecer. Yo, Jehová, lo he dicho y lo he hecho”’”.

### Notas a pie de página
- **v. 2:** O “un proverbio”.
- **v. 4:** Lit. “de Canaán”.
- **v. 5:** Lit. “simiente”.
- **v. 13:** Lit. “simiente”.
- **v. 15:** Es decir, Sedequías.
- **v. 15:** Es decir, Nabucodonosor.
- **v. 16:** Es decir, Sedequías.
- **v. 16:** Es decir, Nabucodonosor.
- **v. 18:** Lit. “mano”.
- **v. 21:** Lit. “a todo viento”.

---

## Ezequiel 18

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “¿Qué significa este proverbio que ustedes dicen en la tierra de Israel: ‘Los padres comieron uvas ácidas, pero fue a los hijos a quienes les dio dentera’?

**3** ”‘Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, ya no seguirán usando este dicho en Israel.

**4** Miren, todas las almas me pertenecen. Tanto el alma del padre como el alma del hijo me pertenecen. El alma que peca es la que morirá.

**5** ”’Supongamos que un hombre es justo y hace lo que es justo y correcto.

**6** No come lo que se sacrifica a ídolos en las montañas; no levanta su mirada hacia los ídolos repugnantes de la casa de Israel; no comete adulterio con la esposa de su prójimo ni tiene relaciones sexuales con una mujer que está con la menstruación;

**7** no maltrata a nadie, sino que le devuelve a su deudor lo que este le dio como garantía; no le roba a nadie, sino que le da su propia comida al hambriento y viste al que no tiene ropa;

**8** no presta cobrando interés ni sacando beneficio, sino que evita actuar injustamente; juzga con verdadera justicia los asuntos entre dos hombres;

**9** siempre anda según mis estatutos y obedece mis decisiones judiciales a fin de actuar fielmente. Un hombre así es justo y sin duda seguirá vivo’, afirma el Señor Soberano Jehová.

**10** ”‘Pero supongamos que él tiene un hijo que es ladrón o asesino, o que hace alguna de estas otras cosas

**11** (aunque el padre no haya hecho nada de esto). Come lo que se sacrifica a ídolos en las montañas, comete adulterio con la esposa de su prójimo,

**12** maltrata al necesitado y al pobre, roba, no devuelve una garantía, levanta la mirada hacia los ídolos repugnantes, practica cosas detestables,

**13** y presta cobrando interés y sacando beneficio. Ese hijo no seguirá vivo. Por todas las cosas detestables que ha hecho, sin falta tendrá que morir. Será responsable de su propia muerte.

**14** ”’Por otro lado, supongamos que un padre tiene un hijo que ve todos los pecados cometidos por su padre y, aunque los ve, no hace lo mismo.

**15** No come lo que se sacrifica a ídolos en las montañas, no levanta la mirada hacia los ídolos repugnantes de la casa de Israel, no comete adulterio con la esposa de su prójimo,

**16** no maltrata a nadie, no se queda con lo que le han dado como garantía, no roba nada, le da su propia comida al hambriento y viste al que no tiene ropa,

**17** no oprime al pobre, no presta cobrando interés ni sacando beneficio, cumple con mis decisiones judiciales y anda según mis estatutos. Un hombre así no morirá por el pecado de su padre. Sin duda, él seguirá vivo.

**18** En cambio, su padre, como se dedicó al fraude, robó a su hermano e hizo lo que estaba mal en medio de su pueblo, morirá por su pecado.

**19** ”’Pero ustedes dirán: “¿Por qué no carga el hijo con la culpa del pecado de su padre?”. Como el hijo ha hecho lo que es justo y recto y ha cumplido y obedecido mis estatutos, sin duda seguirá vivo.

**20** El alma que peca es la que morirá. El hijo no cargará con la culpa del pecado del padre y el padre no cargará con la culpa del pecado del hijo. La justicia del justo se le tomará en cuenta solo a él y la maldad del malvado se le tomará en cuenta solo a él.

**21** ”’Ahora bien, si alguien malvado abandona todos los pecados que ha cometido, obedece mis estatutos y hace lo que es justo y recto, sin duda seguirá vivo. No morirá.

**22** No se le tendrá en cuenta ninguna de las ofensas que haya cometido. Seguirá vivo por hacer lo que es justo’.

**23** ”‘¿Acaso me causa algún placer la muerte de alguien malvado? —afirma el Señor Soberano Jehová—. ¿Acaso no prefiero que abandone sus caminos y siga vivo?’.

**24** ”‘Por otro lado, si alguien justo renuncia a su justicia y actúa mal, si hace todas las cosas detestables que hace el malvado, ¿seguirá vivo? Ninguno de sus actos justos será recordado. Morirá por su infidelidad y por el pecado que ha cometido.

**25** ”’Pero ustedes dirán: “El camino de Jehová es injusto”. ¡Escucha, por favor, oh, casa de Israel! ¿Es mi camino el que es injusto? ¿Acaso no son los caminos de ustedes los que son injustos?

**26** ”’Si alguien justo renuncia a su justicia y actúa mal, y muere por eso, morirá por sus propias malas acciones.

**27** ”’Y, si alguien malvado abandona la maldad que ha cometido y comienza a hacer lo que es justo y recto, conservará su propia vida.

**28** Si se da cuenta de todas las ofensas que ha cometido y las abandona, sin duda seguirá vivo. No morirá.

**29** ”’Pero la casa de Israel dirá: “El camino de Jehová es injusto”. Oh, casa de Israel, ¿de verdad son mis caminos los que son injustos? ¿Acaso no son los caminos de ustedes los que son injustos?’.

**30** ”‘Por lo tanto, juzgaré a cada uno según sus caminos, oh, casa de Israel —afirma el Señor Soberano Jehová—. Abandonen, sí, abandonen por completo todas sus ofensas para que estas no sean un obstáculo que los haga culpables.

**31** Líbrense de todas las ofensas que han cometido y consigan un corazón nuevo y un espíritu nuevo. Pues ¿por qué deberían morir, oh, casa de Israel?’.

**32** ”‘No me causa ningún placer la muerte de nadie —afirma el Señor Soberano Jehová—. Así que regresen a mí y vivan’”.

### Notas a pie de página
- **v. 2:** O “se les destemplaron los dientes”.
- **v. 4:** O “vidas”. Ver glosario.
- **v. 4:** O “La persona”. Ver glosario.
- **v. 6:** Lit. “no contamina a”.
- **v. 8:** O “ni es un usurero”.
- **v. 10:** Lit. “que derrama sangre”.
- **v. 11:** Lit. “contamina a”.
- **v. 13:** O “Su sangre estará sobre él”.
- **v. 15:** Lit. “no contamina a”.
- **v. 20:** O “La persona”.
- **v. 22:** O “No será recordada contra él”.
- **v. 24:** O “hace injusticia”.
- **v. 27:** O “alma”. Ver glosario.
- **v. 30:** O “tropiezo”.
- **v. 31:** Lit. “háganse”.

---

## Ezequiel 19

**1** “Canta una canción de duelo acerca de los jefes de Israel.

**2** Dirás: ‘¿Qué era tu madre? Una leona entre leones. Se acostó entre leones jóvenes y fuertes, y crio a sus cachorros.

**3** Crio a uno de sus cachorros, que se convirtió en un león joven y fuerte. Él aprendió a desgarrar la presa, llegó a devorar humanos.

**4** Las naciones oyeron hablar de él, lo atraparon en una fosa y lo llevaron con garfios a la tierra de Egipto.

**5** Ella esperó a que él regresara hasta que finalmente vio que no había esperanza. Así que tomó a otro de sus cachorros e hizo de él un león joven y fuerte.

**6** Este también se paseó entre los leones y se hizo un león joven y fuerte. Aprendió a desgarrar la presa y llegó a devorar humanos.

**7** Merodeaba entre sus torres fortificadas y arrasaba sus ciudades, de modo que el sonido de su rugido llenó aquella tierra desolada.

**8** Naciones de las regiones vecinas vinieron contra él para echarle una red encima, y lo atraparon en una fosa.

**9** Con garfios lo metieron en una jaula y se lo llevaron al rey de Babilonia. Allí lo encerraron para que no se oyera más su rugido en las montañas de Israel.

**10** Tu madre era como una vid en tu sangre, plantada junto a las aguas. Por la abundancia de agua, daba fruto y estaba llena de ramas.

**11** De ella salieron ramas fuertes, buenas para cetros de gobernantes. Creció y sobresalió por encima de los demás árboles. Llegó a distinguirse por su altura y por sus ramas frondosas.

**12** Pero con furia fue desarraigada y arrojada a tierra, y un viento del este secó su fruto. Sus fuertes ramas fueron arrancadas y se secaron, y el fuego las consumió.

**13** Ahora está plantada en el desierto, en una tierra reseca y sedienta.

**14** El fuego se extendió desde sus ramas y consumió sus brotes y sus frutos. No le quedó ni una sola rama fuerte, ningún cetro para gobernar. ”’Esta es una canción de duelo y servirá como canción de duelo’”.

### Notas a pie de página
- **v. 1:** O “una endecha”.
- **v. 2:** O “leones jóvenes con melena”.
- **v. 10:** O quizás “en tu viña”.
- **v. 11:** O “varas”.
- **v. 14:** O “varas”.

---

## Ezequiel 20

**1** En el séptimo año, en el quinto mes, en el día 10 del mes, algunos de los ancianos de Israel vinieron y se sentaron delante de mí para consultar a Jehová.

**2** Entonces recibí las palabras de Jehová. Me dijo:

**3** “Hijo del hombre, habla con los ancianos de Israel y diles: ‘Esto es lo que dice el Señor Soberano Jehová: “¿Vienen para consultarme? ‘Tan cierto como que yo vivo, no responderé a su consulta’, afirma el Señor Soberano Jehová”’.

**4** ”¿Estás listo para juzgarlos? ¿Estás listo para juzgarlos, hijo del hombre? Hazles saber las cosas detestables que hicieron sus antepasados.

**5** Diles: ‘Esto es lo que dice el Señor Soberano Jehová: “El día en que elegí a Israel, también le hice un juramento a la descendencia de la casa de Jacob y me di a conocer a ellos en la tierra de Egipto. Sí, les juré y les dije: ‘Yo soy Jehová su Dios’.

**6** En aquel día les juré que los sacaría de la tierra de Egipto y los llevaría a una tierra que yo les había buscado, una que rebosaba de leche y miel. Era la más hermosa de todas las tierras.

**7** Entonces les dije: ‘Que cada uno de ustedes deseche las cosas detestables que están ante sus ojos; no se contaminen con los ídolos repugnantes de Egipto. Yo soy Jehová su Dios’.

**8** ”’”Pero ellos se rebelaron contra mí y no quisieron escucharme. No desecharon las cosas detestables que tenían delante de ellos ni abandonaron los ídolos repugnantes de Egipto. Así que prometí derramar mi furor sobre ellos y soltar toda mi furia contra ellos en la tierra de Egipto.

**9** Pero actué por causa de mi nombre, para que este no fuera profanado delante de las naciones entre las que ellos vivían. Porque me di a conocer a ellos delante de esas naciones cuando los saqué de la tierra de Egipto.

**10** De modo que los saqué de la tierra de Egipto y los dirigí al desierto.

**11** ”’”Luego les di mis estatutos y les hice saber mis decisiones judiciales para que el hombre que las cumpliera tuviera vida gracias a ellas.

**12** También les di mis sábados como señal entre ellos y yo para que supieran que yo, Jehová, soy el que los santifica.

**13** ”’”Pero la casa de Israel se rebeló contra mí en el desierto. No anduvieron según mis estatutos y rechazaron mis decisiones judiciales, decisiones por las que un hombre, si las cumple, tendrá vida. Ellos profanaron completamente mis sábados. Así que prometí derramar mi furia sobre ellos en el desierto para exterminarlos.

**14** Pero actué por causa de mi propio nombre, para que este no fuera profanado delante de las naciones; ante sus ojos los saqué.

**15** También les juré en el desierto que no los llevaría a la tierra que les había dado —una tierra que rebosaba de leche y miel, la más hermosa de todas las tierras—

**16** porque habían rechazado mis decisiones judiciales, no habían andado según mis estatutos y habían profanado mis sábados, ya que su corazón seguía a sus ídolos repugnantes.

**17** ”’”Pero sentí lástima por ellos y no los destruí; no los exterminé en el desierto.

**18** Les dije a sus hijos en el desierto: ‘No anden según las normas de sus antepasados ni obedezcan sus decisiones judiciales ni se contaminen con sus ídolos repugnantes.

**19** Yo soy Jehová su Dios. Anden según mis estatutos, obedezcan mis decisiones judiciales y cúmplanlas.

**20** Santifiquen mis sábados, y estos servirán de señal entre ustedes y yo, para que ustedes sepan que yo soy Jehová su Dios’.

**21** ”’”Pero sus hijos empezaron a rebelarse contra mí. No anduvieron según mis estatutos y no obedecieron ni cumplieron mis decisiones judiciales, decisiones por las que un hombre, si las cumple, tendrá vida. Mis sábados profanaron. Así que prometí derramar mi furor sobre ellos y soltar toda mi furia contra ellos en el desierto.

**22** Sin embargo, me contuve y actué por causa de mi propio nombre, para que este no fuera profanado delante de las naciones; ante los ojos de ellas los saqué.

**23** Además, yo les juré en el desierto que los esparciría entre las naciones y los dispersaría por los países.

**24** Y es que no habían cumplido mis decisiones judiciales, habían rechazado mis estatutos, habían profanado mis sábados y habían seguido a los ídolos repugnantes de sus antepasados.

**25** También dejé que siguieran normas que no eran buenas y decisiones judiciales por medio de las que no podrían tener vida.

**26** Dejé que se contaminaran con sus propios sacrificios —cuando quemaban en el fuego a su primer hijo— para que quedaran destrozados y así supieran que yo soy Jehová”’.

**27** ”De modo que háblale a la casa de Israel, oh, hijo del hombre, y diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Sus antepasados blasfemaron contra mí de esta misma manera, actuando infielmente contra mí.

**28** Yo los llevé a la tierra que había jurado darles. Y, cuando ellos vieron todas las colinas altas y todos los árboles frondosos, empezaron a ofrecer sus sacrificios y sus ofrendas ofensivas. Presentaron el aroma agradable de sus sacrificios y derramaron allí sus ofrendas líquidas.

**29** Entonces les pregunté: ‘¿Qué significa ese lugar alto al que van?’. (Se le llama Lugar Alto hasta el día de hoy)”’.

**30** ”Ahora dile a la casa de Israel: ‘Esto es lo que dice el Señor Soberano Jehová: “¿Se están contaminando ustedes del mismo modo que sus antepasados al seguir a sus ídolos repugnantes para prostituirse espiritualmente con ellos?

**31** ¿Y se siguen contaminando ustedes hasta el día de hoy ofreciendo sacrificios a todos sus ídolos repugnantes, quemando a sus hijos en el fuego? Entonces, ¿debería yo responder a su consulta, oh, casa de Israel?”’. ”‘Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, no voy a responder a su consulta.

**32** Nunca sucederá lo que ustedes tienen en mente cuando dicen “Seamos como las naciones, como las familias de otras tierras, que adoran madera y piedra”’”.

**33** “‘Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, reinaré sobre ustedes con mano poderosa y brazo poderoso, y derramando mi furia.

**34** Con mano poderosa y brazo poderoso, y derramando mi furia, los sacaré de los pueblos, de las tierras por las que han sido dispersados, y los reuniré.

**35** Los llevaré al desierto de los pueblos y allí entraré en juicio con ustedes cara a cara.

**36** ”’Tal como entré en juicio con sus antepasados en el desierto de la tierra de Egipto, así entraré en juicio con ustedes —afirma el Señor Soberano Jehová—.

**37** Los haré pasar bajo la vara del pastor y haré que queden obligados a cumplir el pacto.

**38** Pero separaré de ustedes a los rebeldes y a los que cometen ofensas contra mí. Porque los voy a sacar de la tierra donde viven como extranjeros, pero no entrarán en la tierra de Israel. Y ustedes tendrán que saber que yo soy Jehová’.

**39** ”En cuanto a ustedes, oh, casa de Israel, esto es lo que dice el Señor Soberano Jehová: ‘Que cada uno de ustedes se vaya a servir a sus ídolos repugnantes. Pero después, si no me escuchan, ya no podrán profanar más mi santo nombre con sus sacrificios y sus ídolos repugnantes’.

**40** ”‘Porque en mi santa montaña, en una montaña alta de Israel —afirma el Señor Soberano Jehová—, es donde toda la casa de Israel, toda entera, me servirá en el país. Allí me complaceré en ellos y les pediré las contribuciones y las primicias de sus ofrendas, todas sus cosas santas.

**41** Por el aroma agradable, me complaceré en ustedes cuando los saque de los pueblos, de las tierras por las que han sido dispersados, y los reúna; y seré santificado entre ustedes ante los ojos de las naciones’.

**42** ”‘Ustedes tendrán que saber que yo soy Jehová cuando los lleve a la tierra de Israel, la tierra que juré darles a sus antepasados.

**43** Allí se acordarán de su conducta y de todas sus acciones, con las que se contaminaron, y sentirán asco de ustedes mismos por todas las cosas malas que hicieron.

**44** Y tendrán que saber que yo soy Jehová, oh, casa de Israel, cuando les haga esto por causa de mi nombre y no trate con ustedes según su conducta malvada o su modo de actuar corrupto’, afirma el Señor Soberano Jehová”.

**45** Y recibí de nuevo las palabras de Jehová. Me dijo:

**46** “Hijo del hombre, vuelve tu rostro en dirección al sur y haz una declaración hacia el sur, y profetiza contra el bosque de la tierra del sur.

**47** Dile al bosque del sur: ‘Oye las palabras de Jehová. Esto es lo que dice el Señor Soberano Jehová: “Mira, voy a encender un fuego contra ti que consumirá todos los árboles que hay en ti, tanto los verdes como los secos. La llama ardiente no se apagará; chamuscará todos los rostros, de sur a norte.

**48** Y toda la gente verá que yo mismo, Jehová, lo he encendido para que no se apague”’”.

**49** Y yo dije: “¡Ay, Señor Soberano Jehová! Van diciendo de mí ‘¡Él solo habla con enigmas!’”.

### Notas a pie de página
- **v. 4:** O “dictar sentencia contra ellos”.
- **v. 5:** Lit. “alcé mi mano”.
- **v. 6:** O “yo había espiado para ellos”.
- **v. 6:** O “la decoración”.
- **v. 9:** Es decir, a los israelitas.
- **v. 15:** O “la decoración”.
- **v. 17:** Lit. “mi ojo sintió lástima”.
- **v. 22:** Es decir, a los israelitas.
- **v. 24:** Lit. “y sus ojos habían ido detrás de”.
- **v. 26:** O “hacían pasar por”.
- **v. 28:** O “libaciones”.
- **v. 30:** O “serme infieles”.
- **v. 31:** O “haciendo pasar a sus hijos por”.
- **v. 32:** Lit. “espíritu”.
- **v. 32:** O “sirven a”, “dan culto a”.
- **v. 37:** Lit. “los introduciré en el vínculo del”.
- **v. 43:** Lit. “de sus rostros”.
- **v. 48:** Lit. “toda carne”.
- **v. 49:** O “dichos proverbiales”.

---

## Ezequiel 21

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vuelve tu rostro hacia Jerusalén, haz una declaración contra los lugares santos y profetiza contra la tierra de Israel.

**3** Dile a la tierra de Israel: ‘Esto es lo que dice Jehová: “Aquí estoy contra ti; voy a desenvainar mi espada y a eliminar de ti tanto al justo como al malvado.

**4** Como yo voy a eliminar de ti al justo y al malvado, mi espada será desenvainada contra todos, de sur a norte.

**5** Todo el mundo tendrá que saber que yo, Jehová, he desenvainado mi espada. Y esta no regresará a su vaina”’.

**6** ”Y tú, hijo del hombre, suspira mientras tiemblas de miedo. Sí, suspira con amargura delante de ellos.

**7** Si te preguntan ‘¿Por qué suspiras?’, respóndeles ‘Por culpa de una noticia’. Porque sin falta vendrá, y todos los corazones se derretirán de miedo, todas las manos se quedarán sin fuerzas, todos los ánimos decaerán y todas las rodillas gotearán agua. ‘Mira, sin falta vendrá; se cumplirá’, afirma el Señor Soberano Jehová”.

**8** Recibí de nuevo las palabras de Jehová. Me dijo:

**9** “Hijo del hombre, profetiza lo siguiente: ‘Esto es lo que dice Jehová: “Dirás: ‘¡Una espada! Una espada está afilada y pulida.

**10** Está afilada para provocar una gran matanza; está pulida para brillar como el rayo’”’”. El pueblo preguntó: “¿Acaso no deberíamos alegrarnos?”. Pero Dios dijo: “‘¿Es que ella rechazará el cetro de mi propio hijo, como hace con cualquier árbol?

**11** ”’Fue entregada para que la pulieran y para que la empuñaran. Esta espada está afilada y pulida para ponerla en manos de un verdugo.

**12** ”’Grita y laméntate, hijo del hombre, porque ella ha venido contra mi pueblo; ella está contra todos los jefes de Israel. Serán víctimas de la espada junto con mi pueblo. Así que golpéate el muslo en señal de dolor.

**13** Porque se ha hecho una inspección, ¿y qué pasará si la espada rechaza el cetro? Que este dejará de existir’, afirma el Señor Soberano Jehová.

**14** ”Y tú, hijo del hombre, profetiza, da palmadas y repite tres veces: ‘¡Una espada!’. Es la espada que causa víctimas, la espada de la gran matanza, la espada que los rodea.

**15** Sus corazones se derretirán de miedo y muchos caerán a las puertas de su ciudad; voy a provocar una matanza con la espada. Sí, ¡brilla como el rayo y está pulida para la matanza!

**16** Espada afilada, ¡corta a la derecha! ¡Golpea a la izquierda! ¡Ve adonde tu hoja sea dirigida!

**17** Yo también daré palmadas y saciaré mi furia. Yo, Jehová, he hablado”.

**18** Y recibí de nuevo las palabras de Jehová. Me dijo:

**19** “Tú, hijo del hombre, traza dos caminos para que pase la espada del rey de Babilonia. Los dos saldrán de la misma tierra. Y hay que poner una señal en el punto donde la vía se divide y va hacia las dos ciudades.

**20** Traza un camino para que la espada vaya contra Rabá de los ammonitas y otro camino para que vaya contra la ciudad fortificada de Jerusalén, en Judá.

**21** Porque el rey de Babilonia se ha detenido para recurrir a la adivinación en la bifurcación de la vía, donde los dos caminos se separan. Él sacude las flechas, consulta a sus ídolos y examina el hígado.

**22** La adivinación en su mano derecha señala hacia Jerusalén para poner arietes, para ordenar la matanza, para dar el grito de guerra, para colocar arietes contra las puertas, para levantar una rampa de ataque y para construir un muro de asedio.

**23** Sin embargo, a los ojos de quienes les habían hecho juramentos, parecerá una adivinación falsa. Pero él se acuerda de la culpa de ellos y los capturará.

**24** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Ustedes han hecho que su culpa sea recordada al exponer sus ofensas y al dejar a la vista sus pecados en todo lo que hacían. Ahora que se han acordado de ustedes, serán llevados a la fuerza’.

**25** ”Pero tu día ha llegado, oh, herido de muerte y malvado jefe de Israel. Ha llegado el tiempo de tu castigo final.

**26** Esto es lo que dice el Señor Soberano Jehová: ‘Quita el turbante y retira la corona. Ya no será como antes. Pon en alto al que está abajo y echa abajo al que está arriba.

**27** ¡Una ruina! ¡Una ruina! ¡La dejaré hecha una ruina! Y no será de nadie hasta que venga el que tiene el derecho legal, y a él se la daré’.

**28** ”Y tú, hijo del hombre, profetiza lo siguiente: ‘Esto es lo que dice el Señor Soberano Jehová acerca de los ammonitas y de sus insultos’. Dirás: ‘¡Una espada! Una espada está desenvainada para la matanza; está pulida para devorar y para brillar como el rayo.

**29** A pesar de las visiones falsas y de la adivinación engañosa acerca de ti, te pondrán encima de los muertos, los hombres malvados a quienes les ha llegado su día, el tiempo de su castigo final.

**30** Vuelve a poner la espada en su vaina. Te juzgaré en el lugar en que fuiste creada, en tu tierra de origen.

**31** Derramaré mi indignación sobre ti. Soplaré sobre ti el fuego de mi furia y te entregaré a hombres crueles, expertos en destrucción.

**32** Llegarás a ser pasto del fuego; tu propia sangre será derramada en la tierra y no volverás a ser recordada, porque yo, Jehová, he hablado’”.

### Notas a pie de página
- **v. 4:** Lit. “toda carne”.
- **v. 6:** O “tus caderas tiemblan”.
- **v. 7:** Lit. “espíritus”.
- **v. 7:** Es decir, todos se orinarán de miedo.
- **v. 10:** Es decir, la espada de Jehová.
- **v. 13:** O “el cetro”.
- **v. 19:** Lit. “mano”.
- **v. 21:** Lit. “los terafim”.
- **v. 23:** Es decir, a los ojos de los habitantes de Jerusalén.
- **v. 24:** Lit. “por la mano”.
- **v. 25:** O “principal”.
- **v. 29:** Al parecer, se refiere a Rabá de los ammonitas.
- **v. 29:** Lit. “los cuellos de los caídos”.

---

## Ezequiel 22

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Tú, hijo del hombre, ¿estás preparado para anunciar la sentencia contra la ciudad culpable de derramar sangre y hacerle ver todas sus cosas detestables?

**3** Tienes que decir: ‘Esto es lo que dice el Señor Soberano Jehová: “Oh, ciudad que derrama sangre dentro de ella, a la que le está llegando su hora, la que hace ídolos repugnantes para contaminarse,

**4** la sangre que has derramado te ha hecho culpable y tus ídolos repugnantes te han hecho impura. Has adelantado el fin de tus días; el fin de tus años ha llegado. Por eso te convertiré en blanco de insultos para las naciones y en objeto de burla para todos los países.

**5** Los de cerca y los de lejos se burlarán de ti, la que tiene el nombre manchado, la ciudad en la que reina el caos.

**6** Fíjate, todos los jefes de Israel que hay en ti usan su autoridad para derramar sangre.

**7** Dentro de ti se trata al padre y a la madre con desprecio. Se comete fraude contra los residentes extranjeros y se maltrata a los huérfanos y a las viudas”’”.

**8** “‘Tú desprecias mis lugares santos y profanas mis sábados.

**9** Dentro de ti hay calumniadores decididos a derramar sangre. Dentro de ti hay gente que come sacrificios en las montañas. Y en medio de ti tienen un comportamiento obsceno.

**10** Dentro de ti deshonran la cama de su padre y violan a la mujer que está impura por la menstruación.

**11** Dentro de ti, un hombre actúa de manera detestable con la esposa de su prójimo, otro deshonra a su propia nuera actuando de modo obsceno y otro viola a su hermana, la hija de su propio padre.

**12** Dentro de ti aceptan sobornos para derramar sangre. Tú prestas cobrando intereses o para sacar beneficio y consigues dinero extorsionando a tu prójimo. Sí, te has olvidado de mí por completo’, afirma el Señor Soberano Jehová.

**13** ”‘Mira, doy palmadas en señal de desprecio por tus ganancias deshonestas y por los crímenes de sangre cometidos en medio de ti.

**14** ¿Mantendrás el ánimo y seguirán siendo fuertes tus manos en los días en que yo actúe contra ti? Yo, Jehová, he hablado, y actuaré.

**15** Te esparciré entre las naciones y te dispersaré por los países; pondré fin a tu impureza.

**16** Y serás deshonrada delante de las naciones, y tendrás que saber que yo soy Jehová’”.

**17** Recibí de nuevo las palabras de Jehová. Me dijo:

**18** “Hijo del hombre, la casa de Israel ha llegado a ser para mí inservible como la escoria. Todos ellos son cobre, estaño, hierro y plomo en un horno. Han llegado a ser escoria de plata.

**19** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Como todos ustedes han llegado a ser inservibles como la escoria, los voy a juntar dentro de Jerusalén.

**20** Tal como la plata, el cobre, el hierro, el plomo y el estaño se juntan dentro de un horno para fundirlos soplando el fuego sobre ellos, así los voy a juntar en mi furia y en mi furor; soplaré sobre ustedes y los fundiré.

**21** Los juntaré y soplaré sobre ustedes con el fuego de mi furia, y serán fundidos dentro de ella.

**22** Tal como la plata se funde en un horno, así se les fundirá a ustedes dentro de ella; y tendrán que saber que yo, Jehová, he derramado mi furor sobre ustedes’”.

**23** Y recibí de nuevo las palabras de Jehová. Me dijo:

**24** “Hijo del hombre, dile: ‘Eres una tierra que no será purificada, sobre la que no lloverá en el día de la indignación.

**25** Sus profetas han conspirado dentro de ella; como un león rugiente desgarra la presa, ellos devoran personas. Se apoderan de tesoros y objetos valiosos. Dentro de ella han dejado viudas a muchas mujeres.

**26** Sus sacerdotes han violado mi ley y siguen profanando mis lugares santos. No hacen ninguna distinción entre lo que es santo y lo que es común ni enseñan la diferencia entre lo puro y lo impuro; se niegan a respetar mis sábados y me profanan entre ellos.

**27** Sus príncipes, en medio de ella, son como lobos que desgarran la presa; derraman sangre y matan gente para conseguir ganancias deshonestas.

**28** Pero sus profetas han cubierto esos hechos con una capa de cal. Tienen visiones falsas y practican la adivinación engañosa, y dicen “Esto es lo que dice el Señor Soberano Jehová”, a pesar de que el propio Jehová no ha dicho nada.

**29** La gente del país ha defraudado y ha robado; ha maltratado al necesitado y al pobre; ha defraudado al residente extranjero y le ha negado la justicia’.

**30** ”‘Estuve buscando entre ellos a un hombre que reparara la muralla de piedra o que se plantara delante de mí en la brecha de la muralla a favor de la tierra para que no fuera destruida. Pero no encontré a ninguno.

**31** Así que derramaré mi indignación sobre ellos y los exterminaré con el fuego de mi furia. Haré que las consecuencias de su conducta recaigan sobre su propia cabeza’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 2:** Lit. “juzgarás, juzgarás a”.
- **v. 7:** O “huérfanos de padre”.
- **v. 10:** Lit. “descubren la desnudez de su padre”.
- **v. 11:** Lit. “contamina”.
- **v. 12:** O “siendo un usurero”.
- **v. 14:** Lit. “Resistirá tu corazón”.

---

## Ezequiel 23

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, había dos mujeres que eran hijas de la misma madre.

**3** Se hicieron prostitutas en Egipto; se dedicaron a la prostitución desde jóvenes. Allí sus pechos fueron apretados, sus senos virginales, manoseados.

**4** La mayor se llamaba Oholá y su hermana Oholibá. Ellas llegaron a ser mías y dieron a luz hijos e hijas. El nombre de Oholá representa a Samaria y el nombre de Oholibá representa a Jerusalén.

**5** ”Oholá empezó a prostituirse mientras era mía. Deseó ardientemente a sus apasionados amantes, a sus vecinos, los asirios.

**6** Eran gobernadores vestidos de azul y gobernantes subordinados, todos jóvenes atractivos montados a caballo.

**7** Siguió prostituyéndose con los hijos más selectos de Asiria, con todos, y se contaminó con los ídolos repugnantes de los hombres que ella deseaba ardientemente.

**8** No dejó la prostitución que había practicado en Egipto. Y es que, cuando era joven, los de allí se acostaron con ella. Manosearon sus senos virginales y derramaron sobre ella su lujuria.

**9** Así que la entregué en manos de sus apasionados amantes, los hijos de Asiria, esos que ella había deseado ardientemente.

**10** Ellos pusieron al descubierto su desnudez y capturaron a sus hijos e hijas; y la mataron a espada. Se ganó mala fama entre las mujeres, y ellos ejecutaron mi sentencia contra ella.

**11** ”Cuando su hermana Oholibá vio esto, se volvió aún más pervertida en su lujuria, y su prostitución fue peor que la de su hermana.

**12** Deseó ardientemente a sus vecinos, los hijos de Asiria, los gobernadores y los gobernantes subordinados que vestían con esplendor y montaban a caballo; todos jóvenes atractivos.

**13** Cuando ella se contaminó, vi que las dos habían tomado el mismo rumbo.

**14** Pero ella fue aún más allá en su prostitución. Vio figuras de hombres talladas en la pared, imágenes de caldeos pintadas de rojo bermellón,

**15** que llevaban un cinturón en la cintura y amplios turbantes en la cabeza, todos ellos con aspecto de guerreros, que representaban a los babilonios, nacidos en la tierra de los caldeos.

**16** En cuanto los vio, comenzó a desearlos ardientemente y les mandó mensajeros a Caldea.

**17** De modo que los hijos de Babilonia siempre venían a tener sexo con ella en su cama, y la contaminaron con su lujuria. Después de dejar que la contaminaran, se alejó de ellos asqueada.

**18** ”Como siguió dedicándose descaradamente a la prostitución, poniendo al descubierto su desnudez, yo me alejé de ella asqueado, tal como ya me había alejado asqueado de su hermana.

**19** Y ella, recordando los días de su juventud, cuando se prostituía en la tierra de Egipto, siguió prostituyéndose cada vez más.

**20** Deseó ardientemente a sus amantes como hacen las concubinas de hombres que tienen el miembro viril como el de los burros y los genitales como los de los caballos.

**21** Tú añoraste el comportamiento obsceno de tu juventud en Egipto, cuando ellos manosearon tus senos, tus pechos juveniles.

**22** ”Por lo tanto, Oholibá, esto es lo que dice el Señor Soberano Jehová: ‘Mira, voy a provocar a tus amantes, de los que te alejaste asqueada, y los traeré contra ti de todas partes:

**23** los hijos de Babilonia y todos los caldeos, los hombres de Pecod, los de Soa y los de Coa, junto con todos los hijos de Asiria. Todos ellos son jóvenes atractivos, gobernadores y gobernantes subordinados, guerreros y hombres selectos, todos montados a caballo.

**24** Te atacarán con el estruendo de carros de guerra y ruedas, y con muchas tropas, con escudos grandes y pequeños, y con cascos. Te cercarán por todas partes; yo los autorizaré a juzgarte, y te juzgarán como a ellos les parezca.

**25** Expresaré mi indignación contra ti, y ellos te tratarán con furia. Te cortarán la nariz y las orejas, y los que queden de los tuyos caerán a espada. Se llevarán a tus hijos y a tus hijas, y a los que queden de los tuyos los consumirá el fuego.

**26** Te quitarán la ropa y se quedarán con tus preciosas joyas.

**27** Pondré fin a tu comportamiento obsceno y a tu prostitución, que comenzó en la tierra de Egipto. Ya no los mirarás más y no te volverás a acordar de Egipto’.

**28** ”Porque esto es lo que dice el Señor Soberano Jehová: ‘Mira, voy a entregarte a los que odias, esos de los que te alejaste asqueada.

**29** Te tratarán con odio y se llevarán todo el fruto de tu duro trabajo; te dejarán desnuda, sin nada de ropa. La desnudez vergonzosa de tu inmoralidad, tu comportamiento obsceno y tus actos de prostitución quedarán al descubierto.

**30** Esto te pasará porque anduviste detrás de las naciones como una prostituta, porque te contaminaste con sus ídolos repugnantes.

**31** Tú has tomado el mismo rumbo que tu hermana, y yo te pondré su copa en la mano’.

**32** ”Esto es lo que dice el Señor Soberano Jehová: ‘Beberás la copa profunda y ancha de tu hermana, y te convertirás en motivo de risa y burla; la copa está llena de eso.

**33** Se adueñarán de ti la borrachera y el dolor, una copa de terror y desolación, la copa de tu hermana, Samaria.

**34** Te la beberás hasta vaciarla y roerás sus pedazos de barro, y luego te arrancarás los pechos. “Porque yo he hablado”, afirma el Señor Soberano Jehová’.

**35** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Como me has olvidado y me has despreciado por completo, cargarás con las consecuencias de tu comportamiento obsceno y de tus actos de prostitución’”.

**36** Jehová entonces me dijo: “Hijo del hombre, ¿anunciarás la sentencia contra Oholá y Oholibá y les mostrarás a las claras sus prácticas detestables?

**37** Han cometido adulterio y hay sangre en sus manos. No solo cometieron adulterio con sus ídolos repugnantes, sino que, además, a los hijos que dieron a luz para mí los quemaron en el fuego como alimento para sus ídolos.

**38** Y encima me hicieron esto: contaminaron mi santuario en aquel día y también profanaron mis sábados.

**39** En aquel mismo día, después de matar a sus hijos, de sacrificárselos a sus ídolos repugnantes, vinieron a mi santuario para profanarlo. Eso es lo que ellas hicieron dentro de mi propia casa.

**40** Hasta enviaron un mensajero para que los hombres vinieran desde lejos. Mientras ellos estaban en camino, tú te bañaste, te pintaste los ojos y te arreglaste con tus joyas.

**41** Y te sentaste en un espléndido diván con una mesa preparada delante de ti, en la que pusiste mi incienso y mi aceite.

**42** Se oía el ruido de una multitud de hombres despreocupados, entre los que había borrachos traídos del desierto. Ellos les pusieron a las mujeres brazaletes en las muñecas y bellas coronas en la cabeza.

**43** ”Entonces dije de la que estaba gastada de tanto cometer adulterio: ‘Ahora seguirá dedicándose a la prostitución’.

**44** Así que siguieron yendo a ella, igual que el que va a una prostituta. De ese modo fueron al encuentro de Oholá y Oholibá, las mujeres de comportamiento obsceno.

**45** Pero hombres justos dictarán contra ella la sentencia que se merece por adulterio y derramamiento de sangre; porque ellas son unas adúlteras y tienen las manos manchadas de sangre.

**46** ”Porque esto es lo que dice el Señor Soberano Jehová: ‘Se traerá un ejército contra ellas para convertirlas en motivo de horror y en algo que saquear.

**47** El ejército les lanzará piedras y las ejecutará a espada. Matarán a sus hijos y a sus hijas, y les prenderán fuego a sus casas.

**48** Pondré fin al comportamiento obsceno en el país, y todas las mujeres aprenderán la lección y no imitarán el comportamiento obsceno de ustedes.

**49** Ellos harán que caigan sobre ustedes las consecuencias de su comportamiento obsceno y de los pecados que cometieron con sus ídolos repugnantes. Y ustedes tendrán que saber que yo soy el Señor Soberano Jehová’”.

### Notas a pie de página
- **v. 4:** Que significa ‘la tienda de ella’.
- **v. 4:** Que significa ‘mi tienda está en ella’.
- **v. 8:** O “sus relaciones sexuales inmorales”.
- **v. 17:** O “sus relaciones sexuales inmorales”.
- **v. 23:** O “Qoa”. Ver apén. A2.
- **v. 23:** O “convocados”.
- **v. 24:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 26:** O “preciosos adornos”.
- **v. 33:** Lit. “Se te llenará de”.
- **v. 35:** Lit. “me has echado detrás de tus espaldas”.
- **v. 37:** Es decir, adulterio espiritual.
- **v. 37:** O “los hicieron pasar por”.
- **v. 40:** O “adornos”.

---

## Ezequiel 24

**1** Recibí de nuevo las palabras de Jehová en el noveno año, en el décimo mes, en el día 10 del mes. Me dijo:

**2** “Hijo del hombre, registra esta fecha, el día de hoy. Porque, precisamente en este día, el rey de Babilonia ha comenzado su ataque contra Jerusalén.

**3** Y presenta una parábola acerca de la casa rebelde. Dirás sobre ellos: ”‘Esto es lo que dice el Señor Soberano Jehová: “Pon la olla, ponla en el fuego y échale agua.

**4** Mete en ella pedazos de carne, todos los pedazos buenos, el muslo y la paletilla; llénala de los huesos más selectos.

**5** Toma las mejores ovejas del rebaño; después amontona la leña en círculo debajo de la olla. Hierve los pedazos y cocina los huesos dentro de ella”’.

**6** ”Así que esto es lo que dice el Señor Soberano Jehová: ‘¡Ay de la ciudad que derrama sangre, la olla oxidada, a la que no le han limpiado el óxido! Saca los pedazos uno a uno hasta vaciarla, sin echarlos a suertes.

**7** Porque la sangre derramada por esta ciudad todavía está dentro de ella; la derramó en la roca pelada. No la derramó en la tierra para cubrirla con polvo.

**8** A fin de despertar la furia y ejecutar la venganza, he puesto su sangre sobre la roca brillante y pelada de modo que no se pueda cubrir’.

**9** ”Así que esto es lo que dice el Señor Soberano Jehová: ‘¡Ay de la ciudad que derrama sangre! Voy a hacer un gran montón de leña.

**10** Amontona la leña y prende el fuego. Cocina bien la carne, quita el caldo y que los huesos se quemen.

**11** Coloca la olla vacía sobre las brasas para que se caliente y el cobre se ponga al rojo vivo. Su impureza se derretirá en su interior y su óxido se consumirá.

**12** Esto es frustrante y agotador, porque tiene tanto óxido que no se le quita. ¡Échala al fuego con su óxido!’.

**13** ”‘Estabas impura a causa de tu comportamiento obsceno. Traté de purificarte, pero no quedabas limpia de tu impureza. Solo quedarás purificada cuando se calme mi furia contra ti.

**14** Yo, Jehová, he hablado. Se hará realidad. Actuaré sin echarme atrás, sin sentir pesar ni arrepentirme. Te juzgarán según tu conducta y tu modo de actuar’, afirma el Señor Soberano Jehová”.

**15** Recibí de nuevo las palabras de Jehová. Me dijo:

**16** “Hijo del hombre, voy a quitarte a tu amada de un solo golpe. No te pongas de duelo ni llores ni derrames lágrimas.

**17** Laméntate en silencio, no sigas las costumbres del duelo por los muertos. Ponte el turbante y las sandalias. No te cubras la boca ni comas el pan que otros te traigan”.

**18** Le hablé al pueblo por la mañana, y al atardecer murió mi esposa. Así que, a la mañana siguiente, hice tal como se me había mandado.

**19** El pueblo me decía: “¿No nos vas a contar qué tiene que ver con nosotros todo esto que estás haciendo?”.

**20** Les contesté: “He recibido las palabras de Jehová. Me ha dicho:

**21** ‘Dile a la casa de Israel: “Esto es lo que dice el Señor Soberano Jehová: ‘Voy a profanar mi santuario, el motivo de su gran orgullo, lo que ustedes aman y el deseo de su corazón. Sus hijos y sus hijas, a los que dejaron atrás, caerán a espada.

**22** Entonces ustedes tendrán que hacer tal como yo he hecho. No se cubrirán la boca y no comerán el pan que otros les traigan.

**23** Seguirán con el turbante en la cabeza y las sandalias en los pies. No se pondrán de duelo ni llorarán. En vez de eso, se pudrirán en sus errores y se lamentarán entre ustedes.

**24** Ezequiel se ha convertido en una señal para ustedes. Harán tal como él ha hecho. Cuando todo suceda, tendrán que saber que yo soy el Señor Soberano Jehová’”’”.

**25** “Y a ti, hijo del hombre, el día que yo les quite su fortaleza —el hermoso motivo de su alegría, lo que ellos aman, el deseo de su corazón— además de a sus hijos y sus hijas,

**26** te lo informará alguien que escape.

**27** Ese día abrirás la boca y hablarás con el que haya escapado; ya no estarás mudo. Te convertirás en una señal para ellos, y tendrán que saber que yo soy Jehová”.

### Notas a pie de página
- **v. 2:** Lit. “el nombre del día”.
- **v. 3:** O “un proverbio”, “una alegoría”.
- **v. 3:** O “la olla de boca ancha”.
- **v. 4:** O “espaldilla”.
- **v. 16:** O “No te golpees el pecho”.
- **v. 17:** O “el bigote”, “el labio superior”.
- **v. 17:** Lit. “el pan de hombres”.
- **v. 21:** O “la compasión de su alma”.
- **v. 22:** O “el bigote”, “el labio superior”.
- **v. 25:** Es decir, su castillo o fortificación.

---

## Ezequiel 25

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vuelve tu rostro hacia los ammonitas y profetiza contra ellos.

**3** Diles a los ammonitas: ‘Oigan las palabras del Señor Soberano Jehová. Esto es lo que dice el Señor Soberano Jehová: “Cuando mi santuario fue profanado, cuando la tierra de Israel quedó desolada y cuando la casa de Judá fue al destierro, tú te burlaste diciendo ‘¡Qué bien!’.

**4** Por eso voy a entregarte en propiedad a los orientales. Ellos montarán sus campamentos dentro de ti y allí pondrán sus tiendas de campaña. Comerán tu fruto y beberán tu leche.

**5** Y convertiré Rabá en un campo de pasto para camellos y la tierra de los ammonitas en un lugar de descanso para el rebaño; y ustedes tendrán que saber que yo soy Jehová”’”.

**6** “Porque esto es lo que dice el Señor Soberano Jehová: ‘Diste palmadas con las manos y golpeaste el suelo con los pies, y te alegraste de la calamidad de la tierra de Israel con un desprecio enorme.

**7** Por eso extenderé mi mano contra ti y te entregaré como botín a las naciones. Te eliminaré de entre los pueblos y te haré desaparecer de los países. Acabaré contigo; y tú tendrás que saber que yo soy Jehová’.

**8** ”Esto es lo que dice el Señor Soberano Jehová: ‘Ya que Moab y Seír han dicho “¡Mira! La casa de Judá es como todas las demás naciones”,

**9** voy a dejar expuesto el costado de Moab por donde están sus ciudades fronterizas, la hermosura de su tierra: Bet-Jesimot, Baal-Meón y hasta Quiryataim.

**10** Junto con los ammonitas, se lo entregaré en propiedad a los orientales, de modo que no se recordará a los ammonitas entre las naciones.

**11** Y ejecutaré mi sentencia contra Moab; y ellos tendrán que saber que yo soy Jehová’.

**12** ”Esto es lo que dice el Señor Soberano Jehová: ‘Edom ha sido vengativo con la casa de Judá y, al vengarse de ellos, se ha hecho gravemente culpable.

**13** Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “Yo también extenderé mi mano contra Edom; eliminaré de él tanto a los hombres como al ganado y lo convertiré en un lugar desolado. Caerán a espada desde Temán hasta Dedán.

**14** ‘Me vengaré de Edom por medio de mi pueblo Israel. Ellos le harán sentir a Edom mi furia y mi ira para que conozca mi propia venganza’, afirma el Señor Soberano Jehová”’.

**15** ”Esto es lo que dice el Señor Soberano Jehová: ‘Por su constante enemistad, los filisteos han buscado venganza y destrucción llenos de malas intenciones.

**16** Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “Voy a extender mi mano contra los filisteos. Eliminaré a los keretitas y acabaré con los habitantes de la costa que hayan quedado.

**17** Realizaré poderosos actos de venganza contra ellos, los castigaré con furia; y, cuando traiga mi venganza, tendrán que saber que yo soy Jehová”’”.

### Notas a pie de página
- **v. 3:** Es decir, la nación de los ammonitas.
- **v. 4:** O “campamentos amurallados”.
- **v. 9:** O “expuesta la pendiente”.
- **v. 9:** O “decoración”.
- **v. 10:** Es decir, Moab.
- **v. 15:** O “con desprecio en el alma”.

---

## Ezequiel 26

**1** En el año 11, en el primer día del mes, recibí las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, Tiro se burló de Jerusalén diciendo: ‘¡Qué bien! ¡La puerta de entrada de los pueblos ha sido destrozada! Todo vendrá a mí y me haré rica ahora que ella ha sido devastada’.

**3** Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Oh, Tiro, aquí estoy contra ti, y levantaré muchas naciones contra ti como el mar levanta sus olas.

**4** Estas destruirán las murallas de Tiro y demolerán sus torres; yo rasparé su suelo y la dejaré como una roca brillante y pelada.

**5** Se convertirá en un secadero para redes de pesca en medio del mar’. ”‘Porque yo he hablado —afirma el Señor Soberano Jehová—, y ella se convertirá en botín para las naciones.

**6** Sus poblaciones en tierra firme morirán a espada, y la gente tendrá que saber que yo soy Jehová’.

**7** ”Porque esto es lo que dice el Señor Soberano Jehová: ‘Mira, desde el norte voy a traer contra Tiro al rey Nabucodonosor de Babilonia; él es rey de reyes, con caballos, carros de guerra, jinetes y un ejército de muchos soldados.

**8** Arrasará con la espada tus poblaciones en tierra firme; construirá un muro de asedio, levantará contra ti una rampa de ataque y alzará un gran escudo contra ti.

**9** Golpeará tus murallas con un ariete y derribará tus torres con sus hachas.

**10** Sus caballos son tantos que te cubrirán de polvo. El ruido de la caballería, de las ruedas y de los carros hará que tiemblen tus murallas cuando él cruce tus puertas como hombres invadiendo una ciudad con las murallas destrozadas.

**11** Los cascos de sus caballos pisotearán todas tus calles; él matará a tu pueblo a espada y tus poderosas columnas se estrellarán contra el suelo.

**12** Se llevarán como botín todo lo que tienes, saquearán tus mercancías, derribarán tus murallas y demolerán tus magníficas casas; entonces arrojarán al agua tus piedras, tus maderas y tu suelo’.

**13** ”‘Le pondré fin al bullicio de tus canciones, y el sonido de tus arpas no se oirá más.

**14** Y te dejaré como una roca brillante y pelada, y te convertirás en un secadero para redes de pesca. Nunca serás reconstruida, porque yo, Jehová, he hablado’, afirma el Señor Soberano Jehová.

**15** ”Esto es lo que el Señor Soberano Jehová le dice a Tiro: ‘¿Acaso no se estremecerán las islas con el estruendo de tu caída, cuando giman los moribundos, cuando ocurra la matanza en medio de ti?

**16** Todos los príncipes del mar se bajarán de sus tronos, se quitarán sus túnicas y se despojarán de sus prendas de vestir bordadas, y un temblor se apoderará de ellos. Se sentarán en el suelo temblando sin parar y se quedarán mirándote asombrados.

**17** Y entonarán una canción de duelo por ti y te dirán: “¡Cómo has quedado tan destruida, tú, la que había sido habitada por hombres de los mares, la ciudad alabada! ¡Tú y tus habitantes eran poderosos en el mar, sembraban el terror entre todos los habitantes de la tierra!

**18** Las islas temblarán en el día de tu caída, las islas del mar se pondrán inquietas cuando te llegue el fin”’.

**19** ”Porque esto es lo que dice el Señor Soberano Jehová: ‘Cuando te deje arrasada como las ciudades despobladas, cuando te inunde con aguas agitadas y las poderosas aguas te hayan cubierto,

**20** te llevaré, junto con los que bajan al hoyo contigo, adonde están las personas de tiempos pasados. Te haré vivir en el lugar más profundo, como las ciudades antiguas que fueron devastadas, junto con los que bajan al hoyo, para que no seas habitada. Entonces glorificaré la tierra de los vivos.

**21** ”’Haré que te asalten terrores repentinos, y no existirás más. Te buscarán, pero no te encontrarán jamás’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 5:** O “redes barrederas”.
- **v. 6:** Lit. “Sus hijas en el campo”.
- **v. 7:** Lit. “Nabucodorosor”. Esta es una variante en la grafía.
- **v. 7:** Lit. “pueblos”.
- **v. 9:** O “una máquina de ataque”.
- **v. 9:** O “espadas”.
- **v. 14:** O “redes barrederas”.
- **v. 15:** O “caídos”.
- **v. 16:** O “jefes”.
- **v. 16:** O “túnicas sin mangas”.
- **v. 16:** Lit. “se vestirán de temblor”.
- **v. 17:** O “una endecha”.
- **v. 17:** Lit. “Ella y sus”.
- **v. 20:** O “a la tumba”.
- **v. 20:** O “adornaré”.

---

## Ezequiel 27

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Tú, hijo del hombre, canta por Tiro una canción de duelo.

**3** Dile a Tiro: ‘Tú que habitas a las puertas del mar, la que comercia con los pueblos de muchas islas, esto es lo que dice el Señor Soberano Jehová: “Oh, Tiro, tú misma has dicho: ‘Mi belleza es perfecta’.

**4** Tus territorios están en el corazón de los mares y tus constructores han perfeccionado tu belleza.

**5** Hicieron todos tus tablones con enebros de Senir y usaron un cedro del Líbano para hacerte el mástil.

**6** Hicieron tus remos con robles de Basán, y tu proa era de ciprés con incrustaciones de marfil de las islas de Kitim.

**7** Para tu vela se usó lino de Egipto de vivos colores, y los toldos de tu cubierta eran de hilo azul y lana púrpura de las islas de Elisá.

**8** Los habitantes de Sidón y de Arvad eran tus remeros. Oh, Tiro, tus hombres hábiles eran tus marineros.

**9** Los hombres expertos y hábiles de Guebal sellaban tus juntas. Todos los barcos del mar y sus navegantes venían a ti para comerciar con mercancías.

**10** Hombres de Persia, de Lud y de Put estaban en tu ejército, eran tus guerreros. Colgaban sus escudos y cascos en ti, y te daban esplendor.

**11** Los hombres de Arvad que servían en tu ejército se apostaban a lo largo de tus murallas, y hombres valientes cubrían tus torres. Colgaban escudos circulares alrededor de tus murallas y perfeccionaban tu belleza.

**12** ”’”Tarsis hacía negocios contigo debido a tu abundante riqueza. Cambiaban plata, hierro, estaño y plomo por tus productos.

**13** Javán, Tubal y Mesec comerciaban contigo; intercambiaban esclavos y objetos de cobre por tus mercancías.

**14** La casa de Togarmá cambiaba caballos, corceles y mulas por tus productos.

**15** La gente de Dedán negociaba contigo; contratabas comerciantes en muchas islas; ellos te daban colmillos de marfil y madera de ébano como tributo.

**16** Edom hacía negocios contigo por tu gran cantidad de artículos. A cambio de tus productos, te daban turquesa, lana púrpura, bordados coloridos, tela de calidad, corales y rubíes.

**17** ”’”Judá y la tierra de Israel comerciaban contigo y te entregaban trigo de Minit, alimentos selectos, miel, aceite y bálsamo a cambio de tus productos.

**18** ”’”Damasco negociaba contigo debido a tu gran cantidad de artículos y a toda tu riqueza; te daban a cambio vino de Helbón y lana de Sahar.

**19** Vedán y Javán de Uzal te proporcionaban hierro forjado, casia y caña a cambio de tus productos.

**20** Dedán comerciaba contigo con mantas para sillas de montar.

**21** Contrataste a los árabes y a todos los jefes de Quedar, que eran comerciantes de corderos, carneros y cabras.

**22** Los comerciantes de Saba y Raamá comerciaban contigo; a cambio de tus productos, te daban toda clase de perfumes de la mejor calidad, piedras preciosas y oro.

**23** Harán, Cané, Edén, los mercaderes de Saba, Asur y Kilmad comerciaban contigo.

**24** En tu plaza de mercado, ellos comerciaban con hermosas prendas de vestir, capas de tejido azul con bordados coloridos y alfombras de muchos colores, todo bien atado con cuerdas.

**25** Los barcos de Tarsis formaban las caravanas que transportaban tus mercancías; por eso ibas por el corazón del mar llena y bien cargada.

**26** Tus remeros te llevaron a mares revueltos; el viento del este te destrozó en el corazón del mar.

**27** Tu riqueza, tus productos, tus mercancías, tus navegantes y tus marineros, los que sellan tus juntas, los que comercian con tus mercancías y todos los hombres de guerra —toda la multitud que hay en ti—, todos ellos se hundirán en el corazón del mar en el día de tu caída.

**28** Los gritos de tus marineros harán temblar las tierras costeras.

**29** Todos los remeros, los navegantes y los hombres de mar abandonarán sus barcos y se quedarán en tierra.

**30** Alzarán sus voces y se lamentarán amargamente por ti mientras lanzan polvo sobre su cabeza y se revuelcan en cenizas.

**31** Se afeitarán la cabeza y se vestirán de tela de saco; llorarán amargamente por ti con profundos quejidos.

**32** En medio de sus lamentos, cantarán una canción de duelo por ti repitiendo: ‘¿Quién es como Tiro, ahora en silencio en medio del mar?

**33** Cuando desde altamar llegaban tus productos, satisfacías a muchos pueblos. Tus abundantes riquezas y tus mercancías enriquecieron a los reyes de la tierra.

**34** Ahora has sido destrozada en altamar, en aguas profundas; todas tus mercancías y tu gente se han hundido contigo.

**35** Todos los habitantes de las islas se quedarán mirándote asombrados y sus reyes se estremecerán de terror, se les verá la angustia en la cara.

**36** Los mercaderes de las naciones silbarán por lo que te pasó. Tu final será repentino y terrible. Dejarás de existir para siempre’”’”.

### Notas a pie de página
- **v. 2:** O “una endecha”.
- **v. 9:** Lit. “ancianos”.
- **v. 18:** O “lana gris rojiza”.
- **v. 19:** Árbol de la misma familia que el árbol de la canela.
- **v. 19:** Caña aromática.
- **v. 20:** O “ropa tejida”.
- **v. 22:** O “Seba”.
- **v. 23:** O “Seba”.
- **v. 25:** O quizás “y gloriosa”.
- **v. 27:** Lit. “congregación”.

---

## Ezequiel 28

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, dile al líder de Tiro: ‘Esto es lo que dice el Señor Soberano Jehová: “Tu corazón se ha vuelto arrogante y por eso no dejas de decir ‘Soy un dios. Me siento en el trono de un dios en el corazón del mar’. Pero solo eres un hombre, no un dios, aunque en tu corazón pienses que lo eres.

**3** Ya ves, eres más sabio que Daniel. Para ti no hay ningún secreto oculto.

**4** Te has hecho rico gracias a tu sabiduría y discernimiento, y sigues acumulando oro y plata en tu tesoro.

**5** Gracias a tu habilidad para los negocios, multiplicaste tu fortuna, y tu corazón se volvió arrogante debido a tu riqueza”’.

**6** ”‘Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “Como en tu corazón piensas que eres un dios,

**7** voy a traer contra ti a extranjeros, los más despiadados de las naciones; ellos sacarán sus espadas contra la belleza de tu sabiduría y mancharán tu glorioso esplendor.

**8** Te harán bajar al hoyo, y tendrás una muerte violenta en el corazón del mar.

**9** ¿Aun así le dirás al que te mate: ‘Soy un dios’? Serás un simple hombre y no un dios en las manos de los que te contaminen”’.

**10** ‘A manos de extranjeros, sufrirás la muerte de los incircuncisos, porque yo he hablado’, afirma el Señor Soberano Jehová”.

**11** Recibí de nuevo las palabras de Jehová. Me dijo:

**12** “Hijo del hombre, canta una canción de duelo acerca del rey de Tiro. Le dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “Eras el modelo de la perfección, lleno de sabiduría y perfecta belleza.

**13** Estabas en el Edén, el jardín de Dios, adornado con toda clase de piedras preciosas: rubí, topacio y jaspe; crisólito, ónice y jade; zafiro, turquesa y esmeralda; tus engarces y monturas estaban hechos de oro. Todo eso se preparó el día en que fuiste creado.

**14** Yo te puse como el querubín protector, el ungido. Estabas en la montaña santa de Dios y paseabas entre piedras de fuego.

**15** Tu conducta fue intachable desde el día en que fuiste creado hasta que se encontró injusticia en ti.

**16** Por tu gran volumen de negocios, te llenaste de violencia y empezaste a pecar. Así que te expulsaré de la montaña de Dios como a un profano y acabaré contigo lejos de las piedras de fuego, oh, querubín protector.

**17** Tu corazón se volvió arrogante por tu belleza. Por causa de tu glorioso esplendor, corrompiste tu sabiduría. Te arrojaré a la tierra. Haré de ti un espectáculo delante de reyes.

**18** Has profanado tus santuarios con tu enorme culpa y con tus sucios negocios. Haré que se prenda un fuego en medio de ti, y este te consumirá. Te reduciré a cenizas en la tierra delante de todos los que te están observando.

**19** Todos los que te conocían entre los pueblos se quedarán mirándote asombrados. Tu final será repentino y terrible. Dejarás de existir para siempre”’”.

**20** Recibí de nuevo las palabras de Jehová. Me dijo:

**21** “Hijo del hombre, vuelve tu rostro hacia Sidón y profetiza contra ella.

**22** Dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “Oh, Sidón, aquí estoy contra ti, y seré glorificado en medio de ti. La gente tendrá que saber que yo soy Jehová cuando ejecute en ella mi sentencia y sea santificado por medio de ella.

**23** Le mandaré pestes y por sus calles correrá la sangre. Los muertos caerán en medio de ella cuando la espada venga contra ella por todas partes; y ellos tendrán que saber que yo soy Jehová.

**24** ”’”Entonces la casa de Israel ya no estará rodeada de abrojos dañinos y espinas dolorosas, de esos que la tratan con desprecio; y la gente tendrá que saber que yo soy el Señor Soberano Jehová”’.

**25** ”‘Esto es lo que dice el Señor Soberano Jehová: “Cuando vuelva a reunir a los de la casa de Israel de entre los pueblos a los que fueron dispersados, seré santificado entre ellos ante los ojos de las naciones. Y ellos vivirán en la tierra que le di a mi siervo Jacob.

**26** Allí vivirán seguros; construirán casas y plantarán viñas; vivirán seguros cuando yo haya ejecutado mi sentencia contra los vecinos de alrededor que los tratan con desprecio; y tendrán que saber que yo soy Jehová su Dios”’”.

### Notas a pie de página
- **v. 8:** O “a la tumba”.
- **v. 12:** O “una endecha”.
- **v. 12:** Lit. “Sellabas un modelo”.
- **v. 13:** O “engastes”, “encajes”.
- **v. 14:** Lit. “que cubría”.

---

## Ezequiel 29

**1** En el año 10, en el décimo mes, en el día 12 del mes, recibí las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vuelve tu rostro hacia el faraón, el rey de Egipto. Profetiza contra él y contra todo Egipto.

**3** Dirás estas palabras: ‘Esto es lo que dice el Señor Soberano Jehová: “Aquí estoy contra ti, faraón, rey de Egipto, el gran monstruo marino que está tendido entre los canales de su Nilo, el que ha dicho: ‘Mi río Nilo me pertenece. Lo hice para mí’.

**4** Yo pondré garfios en tus mandíbulas y haré que los peces de tu Nilo se peguen a tus escamas. Te sacaré de tu Nilo junto con todos los peces del Nilo que se pegan a tus escamas.

**5** A ti y a todos los peces de tu Nilo, los abandonaré en el desierto. Caerás en campo abierto y no serás recogido ni juntado. Te daré como alimento a los animales salvajes de la tierra y a las aves del cielo.

**6** Entonces todos los habitantes de Egipto tendrán que saber que yo soy Jehová, porque no le dieron más apoyo a los de la casa de Israel que el que da un tallo seco.

**7** Cuando ellos agarraron tu mano, te partiste y les desgarraste el hombro. Cuando ellos se apoyaron en ti, te rompiste e hiciste flaquear sus piernas”.

**8** ”’Por lo tanto, esto es lo que dice el Señor Soberano Jehová: “Mira, voy a mandar una espada contra ti, y eliminaré de ti a hombre y animal.

**9** La tierra de Egipto se convertirá en un lugar desolado y arrasado; y ellos tendrán que saber que yo soy Jehová. Porque tú has dicho: ‘El río Nilo me pertenece; soy yo quien lo hizo’.

**10** Así que estoy contra ti y contra tu Nilo, y dejaré la tierra de Egipto arrasada y seca, como un desierto desolado, de Migdol a Siene, hasta la frontera con Etiopía.

**11** Ni hombre ni ganado la cruzará caminando, y no será habitada por 40 años.

**12** Convertiré la tierra de Egipto en la más desolada de las tierras, y sus ciudades serán las más desoladas de las ciudades por 40 años; esparciré a los egipcios entre las naciones y los dispersaré por los países”.

**13** ”’Porque esto es lo que dice el Señor Soberano Jehová: “Después de 40 años volveré a juntar a los egipcios de entre los pueblos a los que fueron dispersados;

**14** y traeré a los cautivos egipcios de vuelta a la tierra de Patrós, a su tierra de origen, y allí se convertirán en un reino insignificante.

**15** Egipto será inferior a los otros reinos y ya no dominará más a las otras naciones. Los haré tan pequeños que no podrán someter a otras naciones.

**16** Egipto jamás volverá a ser un apoyo de confianza para los de la casa de Israel; solo les recordará el error que cometieron al pedirles ayuda a los egipcios. Y ellos tendrán que saber que yo soy el Señor Soberano Jehová”’”.

**17** En el año 27, en el primer mes, en el primer día del mes, recibí las palabras de Jehová. Me dijo:

**18** “Hijo del hombre, el rey Nabucodonosor de Babilonia lanzó a su ejército en una dura campaña contra Tiro. Todas las cabezas quedaron peladas y todos los hombros se despellejaron por el roce. Pero ni él ni su ejército recibieron ninguna paga por la campaña que realizaron en Tiro.

**19** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Mira, voy a darle la tierra de Egipto al rey Nabucodonosor de Babilonia. Él se llevará su riqueza, la saqueará y se quedará con un gran botín. Eso será la paga para su ejército’.

**20** ”‘Le daré la tierra de Egipto como compensación por su campaña contra ella, por el trabajo que realizaron para mí’, afirma el Señor Soberano Jehová.

**21** ”Ese día haré brotar un cuerno para la casa de Israel, y a ti te daré una oportunidad de hablar en medio de ellos; y ellos tendrán que saber que yo soy Jehová”.

### Notas a pie de página
- **v. 3:** En esta ocasión y en las siguientes, la palabra Nilo se refiere tanto al río como a sus canales de riego.
- **v. 6:** Lit. “una caña”.
- **v. 7:** Lit. “caderas”.
- **v. 9:** Lit. “él ha dicho”.
- **v. 18:** Lit. “Nabucodorosor”. Esta es una variante en la grafía.
- **v. 19:** Lit. “Nabucodorosor”. Esta es una variante en la grafía.
- **v. 20:** Es decir, contra Tiro.
- **v. 21:** O “le daré fuerza a”.

---

## Ezequiel 30

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, profetiza. Dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “Laméntense así: ‘¡Ay, el día ya viene!’.

**3** Porque el día está cerca, sí, está cerca un día de Jehová. Va a ser un día de nubarrones, un tiempo fijado para las naciones.

**4** Una espada vendrá contra Egipto, y el pánico se apoderará de Etiopía cuando en Egipto la gente caiga muerta, cuando sus riquezas sean tomadas y sus cimientos demolidos.

**5** Etiopía, Put, Lud y todos los de las demás naciones, y Cub junto con los hijos de la tierra del pacto, todos caerán a espada”’.

**6** Esto es lo que dice Jehová: ‘Los que apoyan a Egipto también caerán, y el poder arrogante de Egipto será derribado’. ”‘Desde Migdol hasta Siene caerán a espada en el país —afirma el Señor Soberano Jehová—.

**7** Serán las más desoladas de las tierras, y sus ciudades se convertirán en las más devastadas de las ciudades.

**8** Y ellos tendrán que saber que yo soy Jehová cuando prenda un fuego en Egipto y todos sus aliados sean aplastados.

**9** Ese día mandaré mensajeros en barcos para hacer temblar a Etiopía, la que confía en sí misma; será presa del pánico en el día que le va a llegar a Egipto, porque sin duda llegará’.

**10** ”Esto es lo que dice el Señor Soberano Jehová: ‘Les pondré fin a las multitudes de Egipto a manos del rey Nabucodonosor de Babilonia.

**11** A él y a sus tropas, los más despiadados de las naciones, se les traerá para destruir el país. Sacarán sus espadas contra Egipto y llenarán la tierra de muertos.

**12** Convertiré los canales del Nilo en suelo seco y abandonaré la tierra en manos de hombres malvados. Haré que la tierra y todo lo que hay en ella quede desolado a manos de extranjeros. Yo, Jehová, he hablado’.

**13** ”Esto es lo que dice el Señor Soberano Jehová: ‘Destruiré también los ídolos repugnantes y les pondré fin a los dioses inútiles de Nof. Ya nunca habrá un príncipe de la tierra de Egipto, y sembraré el temor en la tierra de Egipto.

**14** Arrasaré Patrós, prenderé un fuego en Zoan y ejecutaré mi sentencia en No.

**15** Derramaré mi furia sobre Sin, la fortaleza de Egipto, y exterminaré a la población de No.

**16** Prenderé un fuego en Egipto, y Sin será presa del terror. Abrirán brecha en No. ¡Y a plena luz del día Nof será atacada!

**17** Los hombres jóvenes de On y Pibéset caerán a espada y las ciudades irán al cautiverio.

**18** El día se oscurecerá en Tehafnehés cuando yo rompa allí el yugo de Egipto. Su poder arrogante se acabará, las nubes la cubrirán y sus ciudades irán al cautiverio.

**19** Ejecutaré mi sentencia en Egipto, y ellos tendrán que saber que yo soy Jehová’”.

**20** En el año 11, en el primer mes, en el día siete del mes, recibí las palabras de Jehová. Me dijo:

**21** “Hijo del hombre, le he partido el brazo al faraón, el rey de Egipto; no lo vendarán para curarlo ni le pondrán vendas para que tenga fuerzas suficientes para tomar la espada”.

**22** “Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Aquí estoy contra el faraón, el rey de Egipto. Le romperé los brazos, tanto el fuerte como el partido, y haré que se le caiga la espada de la mano.

**23** Entonces esparciré a los egipcios entre las naciones y los dispersaré por los países.

**24** Le fortaleceré los brazos al rey de Babilonia y le pondré mi espada en la mano. Y al faraón le romperé los brazos, y él lanzará fuertes quejidos delante de él, tal como lo hace un hombre moribundo.

**25** Fortaleceré los brazos del rey de Babilonia, pero los brazos del faraón quedarán colgando sin fuerzas; y ellos tendrán que saber que yo soy Jehová cuando le ponga mi espada en la mano al rey de Babilonia y él la use contra la tierra de Egipto.

**26** Y esparciré a los egipcios entre las naciones y los dispersaré por los países, y tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 5:** O “toda la mezcla de pueblos”.
- **v. 5:** Quizás se refiera a los israelitas que se habían aliado con Egipto.
- **v. 10:** O “tropas”.
- **v. 10:** Lit. “Nabucodorosor”. Esta es una variante en la grafía.
- **v. 12:** Lit. “venderé”.
- **v. 13:** O “Menfis”.
- **v. 13:** O “jefe”.
- **v. 14:** Es decir, Tebas.
- **v. 15:** Es decir, el castillo o fortificación.
- **v. 17:** Es decir, Heliópolis.
- **v. 24:** O “Aumentaré el poder del”.
- **v. 24:** Es decir, delante del rey de Babilonia.

---

## Ezequiel 31

**1** En el año 11, en el tercer mes, en el primer día del mes, recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, dile al faraón, el rey de Egipto, y a sus multitudes: ‘¿A quién se te puede comparar en grandeza?

**3** Había un asirio, un cedro del Líbano, de hermosas ramas, como un arbusto que da sombra, y de extraordinaria altura; su copa estaba entre las nubes.

**4** Las aguas lo hicieron crecer mucho, fuentes profundas lo hicieron crecer alto. Corrientes de agua rodeaban el lugar en el que estaba plantado; canales regaban todos los árboles del campo.

**5** Por eso creció más alto que todos los demás árboles del campo. Sus ramas se multiplicaron y se extendió su ramaje gracias a sus caudalosas corrientes de agua.

**6** Todas las aves del cielo anidaron en sus ramas, todos los animales salvajes del campo parieron bajo su ramaje, todas las naciones numerosas vivían a su sombra.

**7** Llegó a ser majestuoso en su hermosura y en la extensión de su ramaje, porque sus raíces bajaron a aguas caudalosas.

**8** Ningún cedro del jardín de Dios se podía comparar con él. Ningún enebro tenía ramas como las suyas. Ningún plátano lo igualaba en ramaje. Ningún otro árbol del jardín de Dios podía competir con su belleza.

**9** Lo hice hermoso, con muchas ramas, y todos los demás árboles del Edén, el jardín del Dios verdadero, le tenían envidia’.

**10** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Como este llegó a ser tan alto, con su copa entre las nubes, y su corazón se hizo arrogante por causa de su altura,

**11** se lo entregaré al poderoso gobernante de las naciones. Este sin duda actuará contra él, y yo lo rechazaré por su maldad.

**12** Y extranjeros, los más despiadados de las naciones, lo cortarán y lo abandonarán en las montañas; su ramaje caerá por todos los valles y sus ramas partidas quedarán tendidas por todas las corrientes de agua del país. Todos los pueblos de la tierra se alejarán de su sombra y lo abandonarán.

**13** Todas las aves del cielo vivirán en su tronco caído, y todos los animales salvajes del campo, en sus ramas.

**14** Esto es para que ningún árbol que esté cerca de las aguas se haga tan alto o eleve su copa hasta las nubes, y para que ningún árbol bien regado alcance la altura de ellas. Porque todos serán entregados a la muerte, a las profundidades de la tierra, junto con los hijos de la humanidad, que están bajando al hoyo’.

**15** ”Esto es lo que dice el Señor Soberano Jehová: ‘En el día en que él baje a la Tumba, haré que haya duelo. Por eso cubriré las aguas profundas y retendré sus corrientes para frenar las aguas caudalosas. Oscureceré el Líbano por causa de él, y todos los árboles del campo se secarán.

**16** Haré que tiemblen naciones al sonido de su caída, cuando lo haga bajar a la Tumba junto con los que están bajando al hoyo. Y todos los árboles del Edén, los más selectos y los mejores del Líbano, todos los que están bien regados, serán consolados en las profundidades de la tierra.

**17** Ellos han bajado con él a la Tumba, donde están los caídos a espada, junto con los que lo apoyaban, que vivían a su sombra entre las naciones’.

**18** ”‘¿Cuál de los árboles del Edén se podía comparar contigo en gloria y grandeza? Pero seguro que a ti se te hará bajar con los árboles del Edén a las profundidades de la tierra. Estarás tendido en medio de los incircuncisos, con los caídos a espada. Esto les sucederá al faraón y a todas sus multitudes’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 2:** O “tropas”.
- **v. 8:** Es decir, el árbol conocido como plátano oriental.
- **v. 10:** Lit. “tú llegaste”.
- **v. 14:** O “a la tumba”.
- **v. 15:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 16:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 16:** O “a la tumba”.
- **v. 17:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 17:** Lit. “con su brazo, que vivía”.

---

## Ezequiel 32

**1** En el año 12, en el duodécimo mes, en el primer día del mes, recibí las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, canta una canción de duelo acerca del faraón, el rey de Egipto, y dile: ‘Eras como un león joven y fuerte de las naciones, pero has sido silenciado. Eras como un monstruo marino; te revolcabas en tus ríos, con las patas enturbiabas las aguas y ensuciabas los ríos’.

**3** ”Esto es lo que dice el Señor Soberano Jehová: ‘Por medio de un grupo de muchas naciones te echaré mi red encima, y ellas te sacarán a rastras en mi red de pesca.

**4** Te abandonaré en tierra seca; te arrojaré en campo abierto. Haré que todas las aves del cielo se posen en ti y contigo saciaré el apetito de los animales salvajes de toda la tierra.

**5** Arrojaré tu carne por las montañas y llenaré los valles con tus restos.

**6** Empaparé la tierra hasta las montañas con la sangre que te saldrá a chorros; de ella se llenarán los ríos’.

**7** ‘Y, cuando estés acabado, cubriré los cielos y oscureceré sus estrellas. Con nubes cubriré el sol, y la luna no dará su luz.

**8** Por ti oscureceré todas las lumbreras que brillan en los cielos y cubriré tu tierra de oscuridad’, afirma el Señor Soberano Jehová.

**9** ‘Angustiaré el corazón de muchos pueblos cuando lleve a tus cautivos a otras naciones, a tierras que tú no has conocido.

**10** Haré que muchos pueblos queden horrorizados, y, cuando yo use mi espada delante de ellos, sus reyes se estremecerán de temor a causa de ti. Temblarán sin parar, cada uno temiendo por su vida, en el día de tu caída’.

**11** Porque esto es lo que dice el Señor Soberano Jehová: ‘La espada del rey de Babilonia vendrá contra ti.

**12** Haré que tus multitudes caigan por las espadas de guerreros poderosos, los más despiadados de las naciones, todos ellos. Echarán abajo el orgullo de Egipto, y todas sus multitudes serán exterminadas.

**13** Acabaré con todo su ganado junto a sus aguas caudalosas; ni pies humanos ni pezuñas de ganado las volverán a enturbiar’.

**14** ‘En ese tiempo aclararé sus aguas y haré que sus ríos corran como aceite’, afirma el Señor Soberano Jehová.

**15** ‘Cuando convierta a Egipto en un desierto desolado, una tierra despojada de todo lo que la llenaba, cuando golpee a todos los habitantes que hay en ella, ellos tendrán que saber que yo soy Jehová.

**16** Esta es una canción de duelo, y la gente sin falta la cantará; las hijas de las naciones la entonarán. La cantarán refiriéndose a Egipto y a todas sus multitudes’, afirma el Señor Soberano Jehová”.

**17** Entonces, en el año 12, en el día 15 del mes, recibí las palabras de Jehová. Me dijo:

**18** “Hijo del hombre, laméntate por las multitudes de Egipto y hazla bajar a las profundidades de la tierra, a ella y a las hijas de poderosas naciones, junto con los que van bajando al hoyo.

**19** ”‘¿A quién superas en belleza? ¡Baja, acuéstate junto con los incircuncisos!’.

**20** ”‘Entre los que murieron a espada, ellos caerán. Ella ha sido entregada a la espada; llévensela a rastras de aquí junto con todas sus multitudes.

**21** ”’Desde las profundidades de la Tumba, los guerreros más poderosos hablarán con él y sus ayudantes. Sin falta bajarán y quedarán tendidos como los incircuncisos, que han muerto a espada.

**22** Allí está Asiria con todas sus multitudes. Sus tumbas están alrededor de él, todos muertos a espada.

**23** Sus tumbas están en las profundidades del hoyo y sus multitudes están alrededor de su tumba, todos muertos a espada porque sembraron el terror en la tierra de los vivos.

**24** ”’Allí está Elam con todas sus multitudes alrededor de su tumba, todos muertos a espada. Han bajado a las profundidades siendo incircuncisos, los que sembraron el terror en la tierra de los vivos. Ahora cargarán con su vergüenza junto con los que van bajando al hoyo.

**25** Han hecho una cama para ella entre los muertos, junto con todas sus multitudes alrededor de las tumbas de ella. Todos ellos son incircuncisos, muertos a espada porque sembraron el terror en la tierra de los vivos. Cargarán con su vergüenza junto con los que van bajando al hoyo. Él ha sido puesto entre los muertos.

**26** ”’Allí es donde están Mesec y Tubal y todas las multitudes de ellos. Las tumbas de ellos están alrededor de él. Todos ellos son incircuncisos, atravesados por la espada porque sembraron el terror en la tierra de los vivos.

**27** ¿Acaso no quedarán ellos tendidos junto con los poderosos guerreros incircuncisos que han caído, que bajaron a la Tumba con sus armas de guerra? Y ellos pondrán sus espadas debajo de sus cabezas y sus pecados sobre sus huesos, ya que estos poderosos guerreros sembraron el terror en la tierra de los vivos.

**28** Pero tú, tú serás aplastado entre los incircuncisos y quedarás tendido junto con los que murieron a espada.

**29** ”’Allí está Edom, con sus reyes y todos sus jefes. A pesar de su poder, los dejaron tendidos entre los muertos a espada; ellos también quedarán tendidos junto con los incircuncisos y con los que van bajando al hoyo.

**30** ”’Allí están todos los príncipes del norte con todos los sidonios, quienes han bajado humillados con los muertos a pesar del terror que sembraron con su poder. Quedarán tendidos siendo incircuncisos junto con los que murieron a espada y cargarán con su vergüenza junto con los que van bajando al hoyo.

**31** ”’El faraón verá a todos estos y se consolará por todo lo que les pasó a sus multitudes; el faraón y todo su ejército caerán a espada’, afirma el Señor Soberano Jehová.

**32** ”‘Como él sembró el terror en la tierra de los vivos, al faraón y a todas sus multitudes los dejarán tendidos junto con los incircuncisos, con los caídos a espada’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 2:** O “una endecha”.
- **v. 2:** O “león joven con melena”.
- **v. 2:** Lit. “los ríos de ellos”.
- **v. 6:** Lit. “los cauces se llenarán de ti (contigo)”.
- **v. 12:** O “tropas”.
- **v. 18:** Es decir, a la nación de Egipto.
- **v. 18:** O “a la tumba”.
- **v. 20:** Es decir, la nación de Egipto.
- **v. 21:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 21:** Posiblemente se refiere al faraón.
- **v. 22:** Posiblemente se refiere al rey de Asiria.
- **v. 23:** O “de la tumba”.
- **v. 24:** O “a la tumba”.
- **v. 25:** Es decir, para la nación de Elam.
- **v. 25:** O “a la tumba”.
- **v. 26:** Lit. “ella”.
- **v. 26:** Lit. “ella”.
- **v. 26:** Posiblemente se refiere al rey de Mesec y Tubal.
- **v. 27:** O “Seol”. Es decir, el lugar simbólico donde descansan los muertos. Ver glosario.
- **v. 27:** Quizás se refiera a los guerreros enterrados con sus espadas, con honores militares.
- **v. 29:** O “a la tumba”.
- **v. 30:** O “líderes”.
- **v. 30:** O “a la tumba”.

---

## Ezequiel 33

**1** Y recibí las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, háblales a los hijos de tu pueblo y diles: ”‘Supongamos que mando una espada contra un país y toda la gente de ese país elige a un hombre y lo hace su centinela,

**3** y este ve venir la espada contra el país, toca el cuerno y avisa a la gente.

**4** Si alguien oye el sonido del cuerno pero no hace caso del aviso y una espada viene y le quita la vida, él mismo será responsable de su muerte.

**5** Oyó el sonido del cuerno, pero no hizo caso del aviso. Él mismo será responsable de su muerte. Si hubiera hecho caso del aviso, habría salvado su vida.

**6** ”’Pero, si el centinela ve venir la espada y no toca el cuerno, de modo que la gente no recibe ningún aviso y una espada viene y le quita la vida a alguno de ellos, esa persona morirá por su propio error, pero su sangre se la exigiré al centinela’.

**7** ”A ti, hijo del hombre, a ti te he nombrado centinela para la casa de Israel; y, cuando oigas una palabra de mi boca, los advertirás de mi parte.

**8** Si a alguien malvado yo le digo ‘Malvado, ¡sin falta morirás!’ pero tú no le dices nada al malvado para advertirle que cambie de rumbo, él morirá como un malvado por culpa de su propio error, pero su sangre te la exigiré a ti.

**9** En cambio, si tú le adviertes al malvado que deje su mal camino pero él se niega a cambiar de rumbo, morirá por su error, pero tú sin falta salvarás tu propia vida.

**10** ”Y tú, hijo del hombre, dile a la casa de Israel: ‘Ustedes han dicho: “Nuestros actos rebeldes y nuestros pecados pesan sobre nosotros y nos están consumiendo. ¿Cómo entonces vamos a seguir vivos?”’.

**11** Diles: ‘“Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, no me causa ningún placer la muerte del malvado, pero sí me causa placer que alguien malvado cambie de rumbo y siga vivo. Dejen sus malos caminos, déjenlos. Y es que ¿por qué tendrían que morir, oh, casa de Israel?”’.

**12** ”Y tú, hijo del hombre, diles a los hijos de tu pueblo: ‘La justicia del justo no lo salvará cuando se rebele, ni la maldad del malvado lo hará caer cuando abandone su maldad. Tampoco podrá ningún justo seguir vivo gracias a su justicia el día en que peque.

**13** Si yo le digo al justo “Sin duda seguirás vivo” pero él confía en su propia justicia y actúa mal, ninguno de sus actos justos será recordado, sino que morirá por el mal que ha hecho.

**14** ”’Y, si yo le digo al malvado “Sin falta morirás” pero él abandona su pecado y hace lo que es justo y recto,

**15** devuelve lo que ha tomado como garantía y también devuelve lo que robó, y anda en los estatutos de vida al no hacer lo que está mal, sin duda seguirá vivo. No morirá.

**16** No se le tendrá en cuenta ninguno de los pecados que cometió. Por hacer lo que es justo y recto, sin duda seguirá vivo’.

**17** ”Sin embargo, tu pueblo ha dicho ‘El camino de Jehová es injusto’, cuando en realidad es el camino de ellos el que es injusto.

**18** ”Si alguien justo renuncia a su justicia y actúa mal, morirá por eso.

**19** Pero, si alguien malvado abandona su maldad y hace lo que es justo y recto, seguirá vivo por hacer eso.

**20** ”Pero ustedes han dicho: ‘El camino de Jehová es injusto’. Yo los juzgaré a cada uno de ustedes según sus caminos, oh, casa de Israel”.

**21** Finalmente, en el año 12 de nuestro destierro, en el décimo mes, en el día cinco del mes, un hombre que había escapado de Jerusalén vino a verme y dijo: “¡La ciudad ha caído!”.

**22** La noche anterior a la llegada del hombre que había escapado, la mano de Jehová vino sobre mí, y él me abrió la boca antes de que el hombre viniera a verme por la mañana. Así que mi boca quedó abierta, y nunca más estuve mudo.

**23** Entonces recibí las palabras de Jehová. Me dijo:

**24** “Hijo del hombre, los habitantes de estas ruinas están diciendo acerca de la tierra de Israel: ‘Abrahán era un solo hombre; con todo, él llegó a ser dueño de esta tierra. Pero nosotros somos muchos. Sin duda, nos han dado esta tierra como propiedad nuestra’.

**25** ”Por lo tanto, diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Ustedes están comiendo carne con sangre, levantan la mirada hacia sus ídolos repugnantes y siguen derramando sangre. Así que ¿por qué tendrían que ser ustedes dueños de la tierra?

**26** Han confiado en sus espadas y se han entregado a prácticas detestables, y todos han cometido adulterio con la esposa de su prójimo. Así que ¿por qué tendrían que ser ustedes dueños de la tierra?”’.

**27** ”Tienes que decirles lo siguiente: ‘Esto es lo que dice el Señor Soberano Jehová: “Tan cierto como que yo vivo, los que residen en las ruinas caerán a espada; a los que están en campo abierto se los daré como alimento a los animales salvajes, y los que están en las fortalezas y en las cuevas morirán por enfermedad.

**28** Convertiré esta tierra en un desierto completamente desolado y acabaré con su arrogancia y su orgullo. Y las montañas de Israel quedarán desoladas; nadie pasará por ellas.

**29** Y tendrán que saber que yo soy Jehová cuando convierta esta tierra en un desierto completamente desolado por todas las cosas detestables que hicieron”’.

**30** ”En cuanto a ti, hijo del hombre, tu pueblo está hablando de ti junto a los muros y en las entradas de las casas. Se dicen unos a otros, cada uno a su hermano: ‘Vengan y oigamos las palabras que vienen de Jehová’.

**31** Se juntarán en gran número para sentarse delante de ti como haría mi pueblo; oirán tus palabras, pero no las pondrán en práctica. Porque, aunque de boca para afuera te halagan, su corazón desea con avaricia conseguir ganancias deshonestas.

**32** Mira, tú eres para ellos como una canción de amor cantada con una voz preciosa y tocada hábilmente con un instrumento de cuerda. Oirán tus palabras, pero nadie las pondrá en práctica.

**33** Y, cuando se cumplan —que se cumplirán—, tendrán que saber que hubo un profeta entre ellos”.

### Notas a pie de página
- **v. 4:** Lit. “y lo quita”.
- **v. 4:** Lit. “su sangre estará sobre su cabeza”.
- **v. 5:** Lit. “Su sangre estará sobre él”.
- **v. 6:** O “le pediré cuentas al centinela por su sangre”.
- **v. 7:** O “atalaya”, “vigilante”.
- **v. 8:** O “te pediré cuentas a ti por su sangre”.
- **v. 12:** O “tropezar”.
- **v. 13:** O “hace injusticia”.
- **v. 16:** O “No será recordado contra él”.
- **v. 26:** Lit. “han contaminado a”.
- **v. 31:** O “hablan de modo apasionado”.

---

## Ezequiel 34

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, profetiza contra los pastores de Israel. Profetiza y diles a los pastores: ‘Esto es lo que dice el Señor Soberano Jehová: “¡Ay de los pastores de Israel, que se han estado alimentando a sí mismos! ¿Acaso no es al rebaño a quien los pastores tienen que alimentar?

**3** Ustedes se comen la grasa, se visten con la lana y matan al animal más gordo, pero al rebaño no lo alimentan.

**4** No han fortalecido a las ovejas débiles ni han curado a las enfermas ni han vendado a las heridas ni han traído de vuelta a las descarriadas ni han buscado a las perdidas; en vez de eso, las han dominado con dureza y tiranía.

**5** Así que fueron dispersadas por no tener pastor; fueron dispersadas y se convirtieron en alimento para todos los animales salvajes del campo.

**6** Mis ovejas andaban descarriadas por todas las montañas y por todas las colinas altas; mis ovejas fueron dispersadas por toda la superficie de la tierra sin que nadie las buscara ni tratara de encontrarlas.

**7** ”’”Por lo tanto, pastores, oigan las palabras de Jehová:

**8** ‘“Tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, ya que por no tener pastor mis ovejas se convirtieron en presa, en alimento para todos los animales salvajes del campo, y mis pastores no buscaron a mis ovejas, sino que se alimentaron a sí mismos y no alimentaron a mis ovejas”’,

**9** por todo eso, pastores, oigan las palabras de Jehová.

**10** Esto es lo que dice el Señor Soberano Jehová: ‘Estoy en contra de los pastores; les pediré cuentas por mis ovejas y no les permitiré que alimenten a mis ovejas, y los pastores ya no se alimentarán a sí mismos. Voy a rescatar a mis ovejas de su boca, y no les volverán a servir de alimento’”.

**11** ”’Porque esto es lo que dice el Señor Soberano Jehová: “Aquí estoy, y yo mismo buscaré a mis ovejas y las cuidaré.

**12** Cuidaré de mis ovejas como un pastor que ha encontrado a sus ovejas dispersadas y las alimenta. Voy a rescatarlas de todos los lugares por donde fueron dispersadas en el día de nubes y densas tinieblas.

**13** Las sacaré de los pueblos y las juntaré de los países, y las traeré a su tierra y las alimentaré en las montañas de Israel, junto a las corrientes de agua y junto a todos los lugares habitados del país.

**14** En buenos pastos las alimentaré, y los prados donde pasten estarán en las montañas altas de Israel. Se recostarán allí, en buenos pastos, se alimentarán en pastos selectos de las montañas de Israel”.

**15** ”’“Yo mismo alimentaré a mis ovejas y yo mismo haré que se recuesten —afirma el Señor Soberano Jehová—.

**16** A las perdidas buscaré, a las descarriadas traeré de vuelta, a las heridas vendaré y a las débiles fortaleceré. Pero a las gordas y a las fuertes las exterminaré. Alimentaré a esas con juicios”.

**17** ”’En cuanto a ustedes, mis ovejas, esto es lo que dice el Señor Soberano Jehová: “Voy a juzgar entre oveja y oveja, entre carneros y machos de las cabras.

**18** ¿No les basta con alimentarse en los mejores pastos? ¿También tienen que pisotear lo que queda en sus pastos? Y, después de beber el agua más clara, ¿tienen que enturbiarla con las patas?

**19** ¿Y ahora mis ovejas tienen que alimentarse en los pastos que ustedes han pisoteado y beber el agua que ustedes han enturbiado con las patas?”.

**20** ”’Por lo tanto, esto es lo que les dice a ellas el Señor Soberano Jehová: “Aquí estoy, y yo mismo juzgaré entre las ovejas gordas y las ovejas flacas,

**21** porque ustedes las empujaban con el costado y con los hombros, y a todas las ovejas enfermas les daban empujones con los cuernos hasta dispersarlas lejos.

**22** Salvaré a mis ovejas; nunca más servirán de presa. Voy a juzgar entre oveja y oveja.

**23** Pondré sobre ellas a un solo pastor, mi siervo David, y él las alimentará. Él mismo las alimentará y será su pastor.

**24** Y yo, Jehová, seré su Dios; y mi siervo David, un jefe en medio de ellas. Yo, Jehová, he hablado.

**25** ”’”Haré con ellas un pacto de paz y eliminaré del país a las fieras salvajes para que mis ovejas vivan seguras en el desierto y duerman en los bosques.

**26** Las convertiré a ellas y a los alrededores de mi colina en una bendición y haré que la lluvia caiga a su tiempo. Habrá lluvias de bendiciones.

**27** Los árboles del campo darán su fruto y la tierra dará su producto, y ellas vivirán seguras en el país. Y tendrán que saber que yo soy Jehová cuando rompa su yugo y las rescate de quienes las esclavizaron.

**28** Ya no volverán a ser presa de las naciones, y los animales salvajes de la tierra no las devorarán; vivirán seguras, sin que nadie las asuste.

**29** ”’”Haré crecer para ellas una plantación de renombre; no volverán a morir de hambre en el país y las naciones no las humillarán más.

**30** ‘Entonces tendrán que saber que yo, Jehová su Dios, estoy con ellos y que ellos, la casa de Israel, son mi pueblo’, afirma el Señor Soberano Jehová”’.

**31** ”‘Ustedes, mis ovejas, las ovejas que yo cuido, son solo seres humanos, y yo soy su Dios’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 10:** O “reclamaré mis ovejas de su mano”.
- **v. 10:** O “apacienten”, “cuiden”.
- **v. 29:** Lit. “para un nombre”.

---

## Ezequiel 35

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, vuelve tu rostro hacia la región montañosa de Seír y profetiza contra ella.

**3** Dile: ‘Esto es lo que dice el Señor Soberano Jehová: “Aquí estoy contra ti, oh, región montañosa de Seír. Extenderé mi mano contra ti y te convertiré en un desierto desolado.

**4** Reduciré a ruinas tus ciudades y llegarás a ser un desierto desolado; y tendrás que saber que yo soy Jehová.

**5** Y es que tu enemistad con los hijos de Israel fue constante y los entregaste a la espada en el tiempo de su desastre, en el tiempo de su castigo final”’.

**6** ”‘Por lo tanto, tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, voy a prepararte para derramamiento de sangre, y el derramamiento de sangre te perseguirá. Como odiaste la sangre, el derramamiento de sangre te perseguirá.

**7** Convertiré la región montañosa de Seír en un desierto desolado y eliminaré de ella al que vaya y al que venga.

**8** Llenaré de muertos sus montañas; los muertos a espada caerán en tus colinas, en tus valles y en todas tus corrientes de agua.

**9** Te convertiré en un lugar permanentemente desolado; tus ciudades no serán habitadas. Y ustedes tendrán que saber que yo soy Jehová’.

**10** ”Como tú dijiste ‘Estas dos naciones y estos dos países serán míos y vamos a adueñarnos de los dos’ aunque Jehová mismo estaba allí,

**11** ‘por eso, tan cierto como que yo vivo —afirma el Señor Soberano Jehová—, te trataré con la misma furia y los mismos celos con que tú actuaste, llena de odio contra ellos; y me daré a conocer entre ellos cuando te juzgue.

**12** Entonces tendrás que saber que yo, Jehová, he oído todos los insultos que lanzaste contra las montañas de Israel cuando dijiste “Han quedado desoladas y nos las han entregado para que las devoremos”.

**13** Y con arrogancia ustedes hablaron contra mí, y contra mí lanzaron más y más insultos. Yo lo oí todo’.

**14** ”Esto es lo que dice el Señor Soberano Jehová: ‘Toda la tierra se alegrará cuando yo te convierta en un desierto desolado.

**15** Tú te alegraste cuando la herencia de la casa de Israel quedó desolada. Así que yo te trataré igual a ti. Serás reducida a ruinas desoladas, oh, región montañosa de Seír, sí, todo Edom. Y tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 12:** Lit. “como alimento”.

---

## Ezequiel 36

**1** “Tú, hijo del hombre, profetiza acerca de las montañas de Israel y di: ‘Oh, montañas de Israel, oigan las palabras de Jehová.

**2** Esto es lo que dice el Señor Soberano Jehová: “El enemigo ha dicho contra ustedes: ‘¡Qué bien! ¡Hasta los lugares altos de la antigüedad han pasado a ser propiedad nuestra!’”’.

**3** ”Así que profetiza y di: ‘Esto es lo que dice el Señor Soberano Jehová: “Como ellos las han devastado y atacado a ustedes por todos lados para que pasen a ser propiedad de los sobrevivientes de entre las naciones, y como la gente sigue hablando y diciendo calumnias sobre ustedes,

**4** por eso, oh, montañas de Israel, ¡oigan las palabras del Señor Soberano Jehová! Esto es lo que les dice el Señor Soberano Jehová a las montañas y a las colinas, a las corrientes de agua y a los valles, a las ruinas que fueron devastadas y a las ciudades abandonadas que los sobrevivientes de las naciones de alrededor han saqueado y convertido en objeto de burla;

**5** a estos les dice el Señor Soberano Jehová: ‘Voy a hablar en el fuego de mi celo contra los sobrevivientes de las naciones y contra todo Edom, esos que con inmensa alegría y profundo desprecio afirman que mi tierra es propiedad suya para quedarse con sus campos de pasto y saquearlos’”’.

**6** ”Así que profetiza acerca de la tierra de Israel y diles a las montañas y a las colinas, a las corrientes de agua y a los valles: ‘Esto es lo que dice el Señor Soberano Jehová: “¡Miren! Voy a hablar en mi celo y en mi furia por las humillaciones que las naciones les han hecho pasar”’.

**7** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Yo mismo levanto la mano y juro que las naciones vecinas cargarán con su propia vergüenza.

**8** Pero ustedes, oh, montañas de Israel, echarán ramas y darán su fruto para mi pueblo Israel, ya que ellos volverán pronto.

**9** Porque yo estoy con ustedes, les prestaré atención y serán cultivadas y sembradas.

**10** Multiplicaré su población —la casa de Israel, toda ella—, y las ciudades serán habitadas y las ruinas reconstruidas.

**11** Sí, multiplicaré su población y su ganado; aumentarán y llegarán a ser muchos. Haré que sean habitadas como antes y haré que prosperen más que en el pasado; y ustedes tendrán que saber que yo soy Jehová.

**12** Haré que gente —mi pueblo Israel— camine sobre ustedes y las convierta en su propiedad. Ustedes se convertirán en la herencia de ellos, y nunca más los dejarán sin hijos’”.

**13** “Esto es lo que dice el Señor Soberano Jehová: ‘Como ellos te dicen “Eres una tierra que devora a la población y deja a sus naciones sin hijos”’,

**14** ‘por eso, no devorarás más a la población ni volverás a dejar a tus naciones sin hijos —afirma el Señor Soberano Jehová—.

**15** No te expondré a más insultos de las naciones ni haré que soportes las burlas de la gente, y no volverás a hacer que tus naciones caigan’, afirma el Señor Soberano Jehová”.

**16** Recibí de nuevo las palabras de Jehová. Me dijo:

**17** “Hijo del hombre, cuando la casa de Israel vivía en su tierra, la hicieron impura con su manera de vivir y su modo de actuar. Para mí, su conducta fue como la impureza de la menstruación.

**18** Por eso volqué mi furia sobre ellos por la sangre que habían derramado en la tierra y por hacer impura la tierra con sus ídolos repugnantes.

**19** De modo que los esparcí entre las naciones y los dispersé por los países. Los juzgué según su manera de vivir y su modo de actuar.

**20** Pero, cuando llegaron a aquellas naciones, la gente profanó mi santo nombre al decir de ellos: ‘Este es el pueblo de Jehová, pero tuvieron que salir de su tierra’.

**21** Así que me voy a ocupar de mi santo nombre, que la casa de Israel ha profanado entre las naciones a las que han ido”.

**22** “Por lo tanto, dile a la casa de Israel: ‘Esto es lo que dice el Señor Soberano Jehová: “No lo hago por ustedes, oh, casa de Israel, sino por mi santo nombre, que ustedes han profanado entre las naciones a las que han ido”’.

**23** ‘Sin falta santificaré mi gran nombre, que fue profanado entre las naciones, que ustedes profanaron entre ellas; y las naciones tendrán que saber que yo soy Jehová —afirma el Señor Soberano Jehová— cuando yo sea santificado entre ustedes ante los ojos de ellas.

**24** Los sacaré de las naciones, los volveré a reunir de entre todas las tierras y los llevaré a su tierra.

**25** Los rociaré con agua limpia y quedarán purificados; los purificaré de toda su impureza y de todos sus ídolos repugnantes.

**26** Les daré un corazón nuevo y pondré dentro de ustedes un espíritu nuevo. Quitaré de su cuerpo el corazón de piedra y les daré un corazón de carne.

**27** Pondré mi espíritu dentro de ustedes y haré que anden según mis normas, y ustedes obedecerán mis decisiones judiciales y las cumplirán.

**28** Entonces vivirán en la tierra que les di a sus antepasados. Ustedes serán mi pueblo y yo seré su Dios’.

**29** ”‘Los libraré de toda su impureza. Llamaré al cereal y haré que abunde, y no les mandaré hambre.

**30** Haré que abunden los frutos de los árboles y los productos del campo para que ustedes no sufran nunca más la vergüenza de pasar hambre entre las naciones.

**31** Entonces recordarán su mala conducta y sus acciones, que no fueron buenas, y sentirán asco de ustedes mismos debido a su culpa y a sus prácticas detestables.

**32** Pero sepan esto: no lo hago por ustedes —afirma el Señor Soberano Jehová—. Lo que quiero es que pasen vergüenza y se sientan humillados debido a su conducta, oh, casa de Israel’.

**33** ”Esto es lo que dice el Señor Soberano Jehová: ‘En el día en que los purifique de toda su culpa, haré que las ciudades sean habitadas y las ruinas reconstruidas.

**34** Se cultivará la tierra desolada, la que estaba desolada para que todo el que pasara la viera.

**35** Y la gente dirá: “La tierra desolada ha llegado a ser como el jardín de Edén y las ciudades que quedaron en ruinas, desoladas y demolidas están ahora fortificadas y habitadas”.

**36** Y las naciones que queden alrededor de ustedes tendrán que saber que yo, Jehová, he reconstruido lo que estaba demolido y he plantado lo que estaba desolado. Yo, Jehová, lo he dicho y lo he hecho’.

**37** ”Esto es lo que dice el Señor Soberano Jehová: ‘También dejaré que la casa de Israel me pida que haga esto por ellos: multiplicar su población como un rebaño.

**38** Entonces, ellos llegarán a ser como el rebaño de los santos, como el rebaño de Jerusalén durante sus fiestas: rebaños de gente llenarán las ciudades que estaban en ruinas; y tendrán que saber que yo soy Jehová’”.

### Notas a pie de página
- **v. 3:** Lit. “del resto”, “de los restantes”.
- **v. 5:** O “indignación”.
- **v. 5:** O “desprecio en el alma”.
- **v. 15:** O “tropiecen”.
- **v. 26:** Es decir, receptivo a la guía de Dios.
- **v. 38:** O quizás “como los rebaños de ovejas en Jerusalén destinados a los sacrificios”.

---

## Ezequiel 37

**1** La mano de Jehová estuvo conmigo y, por medio de su espíritu, Jehová me tomó y me puso en medio de la llanura, que estaba llena de huesos.

**2** Él me hizo pasar por entre ellos, y vi que había muchísimos huesos por la llanura y que estaban muy secos.

**3** Él me preguntó: “Hijo del hombre, ¿podrán estos huesos volver a vivir?”. Y yo le respondí: “Señor Soberano Jehová, tú eres el que lo sabe”.

**4** Así que me dijo: “Profetiza sobre estos huesos y diles: ‘Huesos secos, oigan las palabras de Jehová:

**5** ”’Esto es lo que les dice el Señor Soberano Jehová a estos huesos: “Haré que entre aliento en ustedes, y volverán a vivir.

**6** Pondré tendones y carne sobre ustedes y los recubriré de piel; pondré aliento en ustedes, y volverán a vivir; y tendrán que saber que yo soy Jehová”’”.

**7** Entonces profeticé tal como se me había mandado. En cuanto profeticé, se oyó un ruido, un traqueteo intenso, y los huesos comenzaron a juntarse, hueso con hueso.

**8** Después vi que aparecían sobre ellos tendones y carne, y que se cubrían de piel. Pero todavía no había aliento en ellos.

**9** Luego él me dijo: “Profetízale al viento. Profetiza, hijo del hombre, y dile al viento: ‘Esto es lo que dice el Señor Soberano Jehová: “Oh, viento, ven desde los cuatro vientos y sopla sobre estas personas a las que mataron, para que así vuelvan a vivir”’”.

**10** Así que profeticé tal como él me había mandado, y el aliento entró en ellos; empezaron a vivir y a ponerse de pie, un ejército grandísimo.

**11** Después él me dijo: “Hijo del hombre, estos huesos son toda la casa de Israel. Mira lo que andan diciendo: ‘Nuestros huesos están secos y nuestra esperanza se ha desvanecido. Nos han eliminado por completo’.

**12** De modo que profetiza y diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Abriré sus tumbas y los levantaré de sus tumbas, oh, pueblo mío, y los traeré a la tierra de Israel.

**13** Y tendrán que saber que yo soy Jehová cuando abra sus tumbas y cuando los levante de sus tumbas, oh, pueblo mío”’.

**14** ‘Pondré mi espíritu en ustedes, y volverán a vivir; los estableceré en su tierra. Y tendrán que saber que yo, Jehová, lo he dicho y lo he hecho’, afirma Jehová”.

**15** Recibí de nuevo las palabras de Jehová. Me dijo:

**16** “Y tú, hijo del hombre, toma un palo y escribe en él: ‘Para Judá y para los del pueblo de Israel que están con él’. Luego toma otro palo y escribe en él: ‘Para José, el palo de Efraín, y para todos los de la casa de Israel que están con él’.

**17** Entonces júntalos, el uno con el otro, para que en tu mano lleguen a ser un solo palo.

**18** Cuando tu pueblo te pregunte ‘¿No nos vas a decir lo que significan estas cosas?’,

**19** respóndeles ‘Esto es lo que dice el Señor Soberano Jehová: “Tomaré el palo de José, que está en la mano de Efraín, y las tribus de Israel que están con él, y los juntaré con el palo de Judá. Haré de ellos un solo palo; formarán uno solo en mi mano”’.

**20** Los palos en los que escribas tienen que estar en tu mano para que ellos los vean.

**21** ”Entonces diles: ‘Esto es lo que dice el Señor Soberano Jehová: “Sacaré a los hijos de Israel de entre las naciones a las que han ido, los juntaré de todas partes y los traeré a su tierra.

**22** Haré de ellos una sola nación en esa tierra, en las montañas de Israel, y un solo rey los gobernará a todos ellos; ya no formarán dos naciones ni volverán a estar divididos en dos reinos.

**23** Ya no se contaminarán más con sus ídolos repugnantes ni con sus prácticas detestables ni con sus ofensas. Los salvaré de todas las infidelidades que los llevaron a pecar y los purificaré. Ellos serán mi pueblo y yo seré su Dios.

**24** ”’”Mi siervo David será su rey y todos ellos tendrán un solo pastor. Andarán según mis decisiones judiciales y obedecerán con cuidado mis estatutos.

**25** Vivirán en la tierra que le di a mi siervo, a Jacob, donde vivieron los antepasados de ustedes. Vivirán en ella para siempre, ellos y sus hijos y los hijos de sus hijos; y David mi siervo será su jefe para siempre.

**26** ”’”Y haré con ellos un pacto de paz; será un pacto eterno con ellos. Los estableceré, haré que sean muchos y pondré mi santuario en medio de ellos para siempre.

**27** Mi tienda estará con ellos; yo seré su Dios y ellos serán mi pueblo.

**28** Y, cuando mi santuario esté para siempre en medio de ellos, las naciones tendrán que saber que yo, Jehová, santifico a Israel”’”.

### Notas a pie de página
- **v. 9:** O “aliento”, “espíritu”.
- **v. 10:** O “espíritu”.
- **v. 16:** O “que son sus socios”.
- **v. 16:** O “que son sus socios”.
- **v. 18:** Lit. “los hijos de tu pueblo te pregunten”.
- **v. 25:** O “príncipe”.
- **v. 27:** O “carpa”, “morada”, “casa”.
- **v. 27:** O “sobre”.

---

## Ezequiel 38

**1** Recibí de nuevo las palabras de Jehová. Me dijo:

**2** “Hijo del hombre, enfréntate a Gog de la tierra de Magog, el cabecilla principal de Mesec y Tubal, y profetiza contra él.

**3** Dirás: ‘Esto es lo que dice el Señor Soberano Jehová: “Aquí estoy contra ti, oh, Gog, cabecilla principal de Mesec y Tubal.

**4** Te haré dar media vuelta, pondré garfios en tus mandíbulas y te sacaré con toda tu fuerza militar, caballos y jinetes, todos ellos vestidos con esplendor, un ejército numeroso con escudos grandes y pequeños, todos ellos armados con espadas.

**5** Persia, Etiopía y Put están con ellos, todos ellos con escudo pequeño y casco;

**6** Gómer y todas sus tropas; la casa de Togarmá, de las partes más remotas del norte, junto con todas sus tropas. Sí, muchos pueblos están contigo.

**7** ”’”Estén listos, prepárense, tú y todos los ejércitos que se han reunido contigo, y tú serás su comandante.

**8** ”’”Después de muchos días, se te prestará atención. En la parte final de los años, tú invadirás la tierra de un pueblo que ha sido restaurado tras los ataques de la espada, que ha sido juntado de entre muchos pueblos y traído a las montañas de Israel, que habían estado devastadas por mucho tiempo. Los habitantes de esta tierra fueron traídos de vuelta de entre los pueblos, y todos ellos viven seguros.

**9** Vendrás contra ellos como una tormenta y como nubes cubrirás la tierra, tú, todas tus tropas y los muchos pueblos que te acompañan”’.

**10** ”Esto es lo que dice el Señor Soberano Jehová: ‘Ese día surgirán ideas en tu corazón y tramarás un plan perverso.

**11** Dirás: “Invadiré la tierra de poblaciones indefensas. Vendré contra los que viven seguros, sin que nada los altere; todos ellos viven en poblaciones indefensas, sin murallas ni barras ni puertas”.

**12** Será para saquear y conseguir un gran botín, para atacar los lugares devastados que ahora están habitados y a un pueblo que ha sido reunido de entre las naciones, que está acumulando riquezas y propiedades, los que viven en el centro de la tierra.

**13** ”’Saba y Dedán, los mercaderes de Tarsis y todos sus guerreros te dirán: “¿Invadirás la tierra para saquear y conseguir un gran botín? ¿Has reunido a tus ejércitos para llevarte plata y oro, para tomar riquezas y propiedades, para quedarte con un inmenso botín?”’.

**14** ”Así que profetiza, hijo del hombre, y dile a Gog: ‘Esto es lo que dice el Señor Soberano Jehová: “Ese día, cuando mi pueblo Israel viva seguro, ¿acaso no lo sabrás?

**15** Vendrás de tu lugar, desde las partes más remotas del norte, acompañado de muchos pueblos, todos ellos montados a caballo, un ejército enorme, una gran fuerza militar.

**16** Como nubes que cubren el país, tú vendrás contra mi pueblo Israel. En la parte final de los días, te traeré contra mi tierra para que las naciones me conozcan cuando me santifique ante sus ojos por medio de ti, oh, Gog”’.

**17** ”Esto es lo que dice el Señor Soberano Jehová: ‘¿Acaso no eres el mismo del que hablé en el pasado por medio de mis siervos los profetas de Israel? Durante muchos años profetizaron que a ti se te traería contra ellos’.

**18** ”‘Ese día, el día en que Gog invada la tierra de Israel —afirma el Señor Soberano Jehová—, se desatará mi gran furia.

**19** En mi celo, en el fuego de mi furor, hablaré; ese día, habrá un gran terremoto en la tierra de Israel.

**20** Por mi causa temblarán los peces del mar, las aves del cielo, los animales salvajes del campo, todos los reptiles que se arrastran por el suelo y todos los seres humanos de la superficie de la tierra. Las montañas se derrumbarán, los peñascos se vendrán abajo y todas las murallas caerán a tierra’.

**21** ”‘Convocaré una espada contra Gog en todas mis montañas —afirma el Señor Soberano Jehová—. La espada de cada uno estará contra su propio hermano.

**22** Ejecutaré mi sentencia contra él con peste y con derramamiento de sangre. Haré que caiga una lluvia torrencial, granizo, fuego y azufre sobre él, sobre sus tropas y sobre los muchos pueblos que lo acompañan.

**23** Yo sin falta me engrandeceré, me santificaré y me daré a conocer ante los ojos de muchas naciones; y tendrán que saber que yo soy Jehová’.

### Notas a pie de página
- **v. 2:** Lit. “pon tu rostro contra”.
- **v. 2:** O “príncipe supremo”.
- **v. 3:** O “príncipe supremo”.
- **v. 4:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 7:** Lit. “guardia”.
- **v. 8:** O “serás convocado”.
- **v. 8:** O “restaurados”.
- **v. 11:** O “de campo abierto”, “de zona rural”.
- **v. 13:** O “Seba”.
- **v. 13:** O “leones jóvenes con melena”.
- **v. 19:** O “indignación”.
- **v. 22:** O “Me pondré en juicio con él”.

---

## Ezequiel 39

**1** ”Y tú, hijo del hombre, profetiza lo siguiente contra Gog: ‘Esto es lo que dice el Señor Soberano Jehová: “Estoy contra ti, Gog, cabecilla principal de Mesec y Tubal.

**2** Te haré dar media vuelta, te guiaré, haré que subas desde las partes más remotas del norte y te traeré a las montañas de Israel.

**3** De un golpe te quitaré el arco de la mano izquierda y haré que se te caigan las flechas de la mano derecha.

**4** Caerás en las montañas de Israel, tú, todas tus tropas y los pueblos que te acompañen. Te daré como alimento a todo tipo de ave rapaz y a los animales salvajes del campo”’.

**5** ”‘Caerás en campo abierto, porque yo he hablado’, afirma el Señor Soberano Jehová.

**6** ”‘Enviaré fuego contra Magog y contra los que viven seguros en las islas, y tendrán que saber que yo soy Jehová.

**7** Haré que mi santo nombre sea conocido entre mi pueblo Israel y no dejaré que mi santo nombre vuelva a ser profanado; y las naciones tendrán que saber que yo soy Jehová, el Santo en Israel’.

**8** ”‘Sí, esto se acerca y se cumplirá —afirma el Señor Soberano Jehová—. Este es el día del que he hablado.

**9** Los habitantes de las ciudades de Israel saldrán y harán fogatas con las armas: escudos grandes y pequeños, arcos y flechas, garrotes de guerra y lanzas. Las usarán para hacer fuego durante siete años.

**10** No necesitarán buscar madera en el campo ni recoger leña del bosque porque usarán las armas para hacer fuego’. ”‘Despojarán a los que los despojaron y saquearán a los que los saquearon’, afirma el Señor Soberano Jehová.

**11** ”‘Ese día le daré a Gog una sepultura en Israel, en el valle de los que viajan al este del mar, y ese lugar les bloqueará el camino a los que pasen. Allí enterrarán a Gog y a todas sus multitudes, y lo llamarán valle de Hamon-Gog.

**12** La casa de Israel pasará siete meses enterrándolos para purificar la tierra.

**13** Toda la gente del país participará en enterrarlos, y esto les dará fama el día en que me glorifique’, afirma el Señor Soberano Jehová.

**14** ”‘A fin de purificar el país, se asignará a hombres para que lo recorran continuamente y entierren los cuerpos que queden en la superficie de la tierra. Mantendrán la búsqueda durante siete meses.

**15** Cuando los que recorran el país vean un hueso humano, le pondrán una marca al lado. Entonces los que estén asignados a enterrarlos los enterrarán en el valle de Hamon-Gog.

**16** Allí también habrá una ciudad llamada Hamoná. Y ellos tendrán que purificar la tierra’.

**17** ”En cuanto a ti, hijo del hombre, esto es lo que dice el Señor Soberano Jehová: ‘Diles a toda clase de aves y a todos los animales salvajes del campo: “Júntense y vengan. Reúnanse alrededor de mi sacrificio, el que estoy preparando para ustedes, un gran sacrificio en las montañas de Israel. Comerán carne y beberán sangre.

**18** Comerán la carne de los poderosos y beberán la sangre de los jefes de la tierra —los carneros, los corderos, las cabras y los toros—, todos los animales engordados de Basán.

**19** Del sacrificio que estoy preparando para ustedes, comerán grasa hasta hartarse y beberán sangre hasta emborracharse”’.

**20** ”‘A mi mesa, ustedes se saciarán de caballos y de conductores de carros, de poderosos y de todo tipo de guerreros’, afirma el Señor Soberano Jehová.

**21** ”‘Mostraré mi gloria entre las naciones, y todas las naciones verán la sentencia que he ejecutado y el poder que he demostrado entre ellas.

**22** A partir de ese día, la casa de Israel tendrá que saber que yo soy Jehová su Dios.

**23** Y las naciones tendrán que saber que la casa de Israel fue al destierro por su propio error, porque me fueron infieles. Así que oculté mi rostro de ellos y los entregué a sus enemigos, y todos cayeron a espada.

**24** Los traté según su impureza y sus ofensas, y oculté mi rostro de ellos’.

**25** ”Por lo tanto, esto es lo que dice el Señor Soberano Jehová: ‘Voy a hacer volver a los cautivos de Jacob y le tendré misericordia a toda la casa de Israel; y defenderé con celo mi santo nombre.

**26** Después de haber sido humillados por todas las infidelidades que cometieron contra mí, vivirán seguros en su tierra, sin que nadie los asuste.

**27** Cuando los traiga de vuelta de los pueblos y los reúna de entre las tierras de sus enemigos, también me santificaré entre ellos ante los ojos de muchas naciones’.

**28** ”‘Tendrán que saber que yo soy Jehová su Dios cuando, después de haberlos enviado al destierro entre las naciones, los reúna de nuevo en su tierra, sin dejar atrás a ninguno de ellos.

**29** Ya no volveré a ocultar mi rostro de ellos, porque derramaré mi espíritu sobre la casa de Israel’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 1:** O “príncipe supremo”.
- **v. 9:** O “broqueles”, escudos pequeños que solían usar los arqueros.
- **v. 9:** O quizás “picas”, una especie de lanza larga.
- **v. 11:** O “tropas”.
- **v. 11:** O “valle de las Multitudes de Gog”.
- **v. 16:** Que significa ‘multitudes’.
- **v. 21:** Lit. “mi mano”.
- **v. 25:** Lit. “mostraré devoción exclusiva por”.

---

## Ezequiel 40

**1** En el año 25 de nuestro destierro, al comienzo del año, el día 10 del mes, el año 14 después de haber caído la ciudad, en ese mismo día, la mano de Jehová estuvo sobre mí y me llevó a la ciudad.

**2** Por medio de visiones divinas, él me llevó a la tierra de Israel y me puso en una montaña muy alta, en la que, hacia el sur, había una estructura parecida a una ciudad.

**3** Cuando me llevó allí, vi a un hombre de aspecto parecido al del cobre. En la mano tenía una cuerda de lino y una caña de medir, y estaba de pie a la entrada.

**4** El hombre me dijo: “Hijo del hombre, fíjate bien, escucha atentamente y presta atención a todo lo que te enseñe, ya que para eso te he traído aquí. Cuéntale a la casa de Israel todo lo que veas”.

**5** Vi un muro que rodeaba el templo por fuera. El hombre tenía en la mano una caña de medir de seis codos (a cada codo se le había añadido un palmo menor). Él empezó a medir el muro, que tenía una caña de ancho por una caña de alto.

**6** Entonces se acercó a la puerta que daba al este y subió los escalones. Midió el umbral de la puerta, y este tenía una caña de ancho; el otro umbral también tenía una caña de ancho.

**7** Cada cuarto de los guardias tenía una caña de largo por una caña de ancho, y había cinco codos entre los cuartos de los guardias. El umbral de la puerta que estaba al lado del pórtico de la puerta que daba al interior medía una caña.

**8** Él midió el pórtico de la puerta que daba al interior, y medía una caña.

**9** Entonces midió el pórtico de la puerta: ocho codos; y midió sus columnas laterales: dos codos. El pórtico de la puerta estaba en el lado que daba al interior.

**10** Había tres cuartos de los guardias a cada lado de la puerta del este. Los tres tenían el mismo tamaño, y las columnas laterales que había a cada lado tenían el mismo tamaño.

**11** Entonces midió el ancho de la entrada de la puerta: 10 codos; y el largo de la puerta: 13 codos.

**12** La zona cerrada con un muro bajo, situada delante de los cuartos de los guardias que había a los dos lados, medía un codo. Los cuartos de los guardias que había a ambos lados medían seis codos cada uno.

**13** Después midió la puerta desde el techo de un cuarto de los guardias hasta el techo del otro: 25 codos de ancho; una entrada estaba frente a la otra entrada.

**14** Entonces midió las columnas laterales, que tenían 60 codos de alto, y también las columnas laterales de las puertas que estaban alrededor de todo el patio.

**15** Desde delante de la entrada de la puerta hasta delante del pórtico, por la parte de la puerta que daba al interior, había 50 codos.

**16** Dentro de la puerta, en los cuartos de los guardias y en sus columnas laterales, a cada lado, había ventanas con marcos que se estrechaban. El interior de los pórticos también tenía ventanas a cada lado y había figuras de palmeras en las columnas laterales.

**17** Después me llevó al patio exterior, y vi comedores y una zona pavimentada alrededor del patio. Había 30 comedores sobre el pavimento.

**18** El pavimento estaba al lado de las puertas y su anchura correspondía al largo de las puertas; este era el pavimento inferior.

**19** Luego midió la distancia entre la fachada de la puerta inferior y el perímetro del patio interior. Era de 100 codos por el lado este y por el lado norte.

**20** El patio exterior tenía una puerta que daba al norte, y él midió su largo y su ancho.

**21** Había tres cuartos de los guardias a cada lado. Las columnas laterales y el pórtico tenían el mismo tamaño que los de la primera puerta, que medía 50 codos de largo por 25 codos de ancho.

**22** Las ventanas, el pórtico y las figuras de palmeras eran del mismo tamaño que los de la puerta este. La gente llegaba a ella subiendo siete escalones y, frente a ellos, estaba el pórtico.

**23** En el patio interior había una puerta enfrente de la puerta norte y otra enfrente de la puerta este. Midió la distancia de puerta a puerta: 100 codos.

**24** Después me llevó hacia el sur, y vi una puerta en el lado sur. Midió sus columnas laterales y el pórtico: eran del mismo tamaño que los otros.

**25** Había ventanas a cada lado de la puerta y del pórtico, iguales que las otras ventanas. La puerta medía 50 codos de largo por 25 codos de ancho.

**26** Se llegaba a ella subiendo siete escalones y, frente a ellos, estaba el pórtico. Tenía figuras de palmeras en las columnas laterales, una a cada lado.

**27** El patio interior tenía una puerta que daba al sur. Midió la distancia entre las dos puertas que daban al sur: 100 codos.

**28** Luego me llevó por la puerta sur al patio interior y midió la puerta sur: era del mismo tamaño que las otras.

**29** Los cuartos de los guardias, las columnas laterales y el pórtico eran del mismo tamaño que los otros. Había ventanas a cada lado de ella y del pórtico. La puerta medía 50 codos de largo por 25 codos de ancho.

**30** Había pórticos alrededor; medían 25 codos de largo por 5 codos de ancho.

**31** Su pórtico daba al patio exterior, y había figuras de palmeras en las columnas laterales; se llegaba a ella subiendo ocho escalones.

**32** Me llevó al patio interior por el lado este y midió la puerta: era del mismo tamaño que las otras.

**33** Los cuartos de los guardias, las columnas laterales y el pórtico eran del mismo tamaño que los otros, y había ventanas a cada lado de ella y del pórtico. La puerta medía 50 codos de largo por 25 codos de ancho.

**34** Su pórtico daba al patio exterior, y había figuras de palmeras en las dos columnas laterales; se llegaba a ella subiendo ocho escalones.

**35** Entonces me llevó a la puerta norte y la midió: era del mismo tamaño que las otras.

**36** Los cuartos de los guardias, las columnas laterales y el pórtico eran iguales que los otros. La puerta tenía ventanas a cada lado. Medía 50 codos de largo por 25 codos de ancho.

**37** Sus columnas laterales daban al patio exterior, y había figuras de palmeras en las dos columnas laterales; se llegaba a ella subiendo ocho escalones.

**38** Cerca de las columnas laterales de las puertas, había un comedor con una entrada; ahí se lavaban las ofrendas quemadas.

**39** Había dos mesas a cada lado del pórtico de la puerta; en ellas se mataba a los animales para las ofrendas quemadas, las ofrendas por el pecado y las ofrendas por la culpa.

**40** En la subida hacia la puerta norte, fuera de la entrada, había dos mesas. También había dos mesas en el otro lado del pórtico de la puerta.

**41** Había cuatro mesas a cada lado de la puerta —ocho mesas en total— en las que se mataba a los animales para los sacrificios.

**42** Las cuatro mesas para las ofrendas quemadas eran de piedra labrada. Tenían un codo y medio de largo, un codo y medio de ancho, y un codo de alto. Sobre ellas se dejaban los utensilios con los que se mataba a los animales para las ofrendas quemadas y los sacrificios.

**43** Había estanterías de un palmo menor de ancho colocadas por todas las paredes interiores; y la carne de las ofrendas se ponía sobre las mesas.

**44** En el lado de afuera de la puerta interior, había comedores para los cantores; estaban en el patio interior, cerca de la puerta norte, mirando hacia el sur. Había otro comedor cerca de la puerta este, mirando hacia el norte.

**45** Él me dijo: “Este comedor que da al sur es para los sacerdotes responsables de los servicios del templo.

**46** El comedor que da al norte es para los sacerdotes responsables del servicio del altar. Son los hijos de Sadoc; entre los levitas, ellos son los que están asignados a acercarse a Jehová para servirle”.

**47** Después midió el patio interior. Era cuadrado; medía 100 codos de largo por 100 codos de ancho. El altar estaba delante del templo.

**48** Entonces me llevó al pórtico del templo y midió las columnas laterales del pórtico; medían cinco codos por un lado y cinco codos por el otro lado. El ancho de la puerta era de tres codos por un lado y de tres codos por el otro lado.

**49** El pórtico tenía 20 codos de ancho por 11 codos de profundidad. La gente llegaba allí subiendo unos escalones. Había columnas junto a los postes laterales, una a cada lado.

### Notas a pie de página
- **v. 3:** Ver apén. B14.
- **v. 4:** Lit. “pon tu corazón”.
- **v. 5:** Lit. “la casa”. Esta palabra se traduce “templo” en los capítulos 40 a 48 cuando se refiere al recinto del templo o al propio edificio del templo.
- **v. 5:** Lit. “una caña de medir de seis codos, un codo y un palmo menor”. Se refiere a codos largos. Ver apén. B14.
- **v. 6:** La puerta era una construcción con varias salas.
- **v. 11:** O “del portal”.
- **v. 13:** Posiblemente se refiere a la parte alta de la pared del cuarto de los guardias.
- **v. 16:** O “ventanas biseladas (abocinadas)”.
- **v. 17:** O “cuartos”.
- **v. 19:** Lit. “anchura”.
- **v. 49:** O quizás “12”.

---

## Ezequiel 41

**1** Entonces me llevó al santuario exterior y midió las columnas laterales; tenían seis codos de ancho por un lado y seis codos de ancho por el otro lado.

**2** La entrada tenía 10 codos de ancho y las paredes laterales de la entrada tenían 5 codos por un lado y 5 codos por el otro lado. Él midió el largo del santuario exterior: 40 codos; y el ancho: 20 codos.

**3** Luego entró y midió la columna lateral de la entrada: dos codos de grosor; y la entrada: seis codos de ancho. Las paredes laterales de la entrada medían siete codos.

**4** Después midió el cuarto que daba al santuario exterior: 20 codos de largo por 20 codos de ancho. Y me dijo: “Este es el Santísimo”.

**5** Entonces midió la pared del templo: seis codos de grosor. Las habitaciones laterales que estaban alrededor del templo tenían cuatro codos de ancho.

**6** Las habitaciones laterales estaban en tres plantas, una habitación encima de otra, con 30 habitaciones en cada planta. Había repisas a lo largo de las paredes del templo que servían de apoyo para las vigas de las habitaciones laterales, de modo que las vigas no estaban empotradas en la pared del templo.

**7** En los dos lados del templo había una subida en espiral que se ensanchaba a medida que subía a las habitaciones de arriba. El ancho aumentaba de una planta a otra a medida que se subía de la planta inferior a la superior pasando por la planta de en medio.

**8** Vi que había una plataforma elevada alrededor del templo, y los cimientos de las habitaciones laterales medían hasta la esquina una caña entera de seis codos.

**9** La pared exterior de las habitaciones laterales tenía cinco codos de ancho. Había un espacio abierto a lo largo de la estructura de las habitaciones laterales que formaba parte del templo.

**10** Entre el templo y los comedores había un espacio por cada lado que tenía 20 codos de ancho.

**11** Por el lado norte, había una entrada entre las habitaciones laterales y el espacio abierto, y había otra entrada por el lado sur. El espacio abierto tenía cinco codos de ancho todo alrededor.

**12** El edificio que estaba en el lado oeste, que daba al espacio abierto, tenía 70 codos de ancho por 90 codos de largo; la pared del edificio tenía 5 codos de grosor todo alrededor.

**13** Él midió el templo: 100 codos de largo. El espacio abierto, el edificio y sus paredes también medían 100 codos de largo.

**14** La fachada del templo que daba al este, incluyendo el espacio abierto, medía 100 codos de ancho.

**15** Él midió el largo del edificio que daba a la parte de atrás del espacio abierto, incluyendo las galerías de los dos lados, y tenía 100 codos. También midió el santuario exterior, el santuario interior y los pórticos del patio,

**16** así como los umbrales, las ventanas con marcos que se estrechaban y las galerías que había en esas tres zonas. Cerca del umbral había paneles de madera que iban desde el suelo hasta las ventanas, y las ventanas estaban cubiertas.

**17** Se hicieron mediciones por encima de la entrada, en la parte interior y exterior del templo y alrededor de toda la pared.

**18** Había figuras talladas de querubines y palmeras; cada palmera estaba entre dos querubines, y cada querubín tenía dos caras.

**19** La cara de hombre miraba a la palmera que había a un lado y la cara de león miraba a la palmera que había al otro lado. Estas figuras estaban talladas así por todo el templo.

**20** En la pared del santuario, desde el suelo hasta la parte que estaba por encima de la entrada, había figuras talladas de querubines y palmeras.

**21** Los postes de la puerta del santuario eran cuadrados. Delante del lugar santo había una especie de

**22** altar de madera, que medía tres codos de alto por dos codos de largo. Tenía postes en las esquinas, y la base y los lados eran de madera. Entonces él me dijo: “Esta es la mesa que está delante de Jehová”.

**23** Tanto el santuario exterior como el lugar santo tenían puertas dobles.

**24** Las puertas tenían dos hojas plegables, dos hojas en cada puerta.

**25** Había figuras talladas de querubines y palmeras en las puertas del santuario, como las de las paredes. También había un alero de madera en la fachada del pórtico, por fuera.

**26** Además, había ventanas con marcos que se estrechaban y figuras de palmeras a ambos lados del pórtico, así como a lo largo de las habitaciones laterales del templo y de los aleros.

### Notas a pie de página
- **v. 1:** Lit. “al templo”. En los capítulos 41 y 42, la palabra hebrea se refiere al santuario exterior (el Santo) o a todo el santuario (el templo, que incluía el Santo y el Santísimo).
- **v. 1:** Se refiere a codos largos. Ver apén. B14.
- **v. 2:** Lit. “los lados”.
- **v. 3:** Es decir, entró en el santuario interior, el Santísimo.
- **v. 3:** Lit. “El ancho de la entrada era de”.
- **v. 7:** Según parece, se refiere a unas escaleras de caracol.
- **v. 9:** Según parece, un pasillo estrecho alrededor del templo.
- **v. 10:** O “cuartos”.
- **v. 13:** Es decir, el edificio que estaba en el lado oeste del santuario.
- **v. 19:** O “león joven con melena”.
- **v. 21:** Lit. “El poste (La jamba) de la puerta”. Según parece, se refiere a la entrada del Santo.
- **v. 21:** Según parece, se refiere al Santísimo.
- **v. 22:** Lit. “su largo”.
- **v. 25:** O “voladizo”, “tejadillo”.

---

## Ezequiel 42

**1** Entonces me sacó al patio exterior, al lado norte, y me llevó al edificio de los comedores que estaba junto al espacio abierto, al norte del edificio de al lado.

**2** De largo, por donde estaba la entrada norte, tenía 100 codos y, de ancho, 50 codos.

**3** Estaba entre el patio interior, que tenía 20 codos de ancho, y el pavimento del patio exterior. Había tres plantas con galerías, unas frente a las otras.

**4** Delante de los comedores había un pasillo interior de 10 codos de ancho por 100 codos de largo, y sus entradas daban al norte.

**5** Los comedores de la planta superior del edificio eran más estrechos que los de la planta inferior y que los de la planta de en medio, pues las galerías les quitaban más espacio.

**6** Y es que, aunque estaban en tres plantas, no había columnas como las de los patios. Por eso había menos espacio en la planta superior que en la planta de en medio y en la inferior.

**7** Cerca de los comedores que estaban junto al patio exterior, y enfrente de los otros comedores, había un muro exterior de piedra que medía 50 codos de largo.

**8** Porque los comedores que estaban junto al patio exterior medían 50 codos de largo, pero los que daban al santuario medían 100 codos.

**9** Los comedores tenían una entrada en el lado este para llegar a ellos desde el patio exterior.

**10** También había comedores dentro del muro de piedra del patio, que daba al este, cerca del espacio abierto y del edificio.

**11** Había un pasillo delante de ellos como el que había en los comedores del lado norte. Tenían el mismo largo y el mismo ancho, las mismas salidas y la misma distribución. Sus entradas

**12** eran como las entradas de los comedores del lado sur. Había una entrada al comienzo del pasillo, enfrente del muro de piedra contiguo que daba al este, por donde se podía entrar.

**13** Luego él me dijo: “Los comedores del norte y los comedores del sur que están junto al espacio abierto son los comedores santos, donde los sacerdotes que se acercan a Jehová comen las ofrendas santísimas. Ahí colocan las ofrendas santísimas, la ofrenda de grano, la ofrenda por el pecado y la ofrenda por la culpa, porque el lugar es santo.

**14** Cuando los sacerdotes entren allí, no deben salir del lugar santo al patio exterior sin antes quitarse la ropa que usan para servir, porque es santa. Se cambiarán de ropa para salir a las zonas abiertas para la gente”.

**15** Cuando terminó de medir la zona interior del templo, me llevó afuera por la puerta que da al este y midió toda el área.

**16** Midió el lado este con la caña de medir. Según la caña de medir, tenía 500 cañas de un extremo a otro.

**17** Midió el lado norte: 500 cañas según la caña de medir.

**18** Midió el lado sur: 500 cañas según la caña de medir.

**19** Dio la vuelta por el lado oeste. Midió 500 cañas con la caña de medir.

**20** Midió el área por los cuatro lados. Había un muro todo alrededor, que medía 500 cañas de largo por 500 cañas de ancho, para separar lo que es santo de lo que es de uso común.

### Notas a pie de página
- **v. 2:** Se refiere a codos largos. Ver apén. B14.
- **v. 4:** O “cuartos”.
- **v. 4:** Según la Septuaginta, “100 codos de largo”. El texto hebreo dice “un camino de un codo”. Ver apén. B14.
- **v. 10:** Lit. “a lo ancho”.
- **v. 15:** Lit. “la casa interior”.
- **v. 16:** Ver apén. B14.

---

## Ezequiel 43

**1** Entonces él me llevó a la puerta que daba al este.

**2** Allí vi la gloria del Dios de Israel que venía desde el este; la voz de él era como el sonido de aguas caudalosas; y la tierra se iluminó con su gloria.

**3** Esta visión era como la que yo había tenido cuando vine a destruir la ciudad; se parecía a lo que había visto cerca del río Kebar; y caí rostro a tierra.

**4** Luego la gloria de Jehová entró en el templo por la puerta que daba al este.

**5** Entonces un espíritu me levantó y me llevó al patio interior, y vi que el templo se había llenado de la gloria de Jehová.

**6** Después oí a alguien que me hablaba desde el templo, y el hombre vino y se puso a mi lado.

**7** Me dijo: “Hijo del hombre, este es el lugar de mi trono y el lugar donde pongo las plantas de mis pies, donde residiré para siempre en medio del pueblo de Israel. La casa de Israel no volverá a contaminar mi santo nombre, ni ellos ni sus reyes, con su prostitución espiritual y con los cadáveres de sus reyes.

**8** Pusieron su umbral al lado de mi umbral y los postes de sus puertas al lado de los postes de mis puertas —con tan solo una pared entre ellos y yo—, contaminando así mi santo nombre con las cosas detestables que hicieron, de modo que en mi furia los exterminé.

**9** Que alejen ahora de mí su prostitución espiritual y los cadáveres de sus reyes, y yo residiré en medio de ellos para siempre.

**10** ”Tú, hijo del hombre, descríbele el templo a la casa de Israel, para que sientan vergüenza por sus errores, y que ellos estudien su plano.

**11** Si se sienten avergonzados por todo lo que han hecho, enséñales los planos del templo, su distribución, sus salidas y sus entradas. Muéstrales todos sus planos y sus estatutos, sus planos y sus leyes. Escríbelo todo ante sus ojos para que observen todos sus planos y cumplan sus estatutos.

**12** Esta es la ley del templo: todo el terreno alrededor de la cima de la montaña es santísimo. Sí, esta es la ley del templo.

**13** ”Estas son las medidas del altar en codos (a cada codo se le había añadido un palmo menor). Su base tiene un codo de alto y sobresale un codo. Alrededor del saliente hay un borde de un palmo de ancho. Esa es la base del altar.

**14** Desde la base, que está en el suelo, hasta la parte alta de la plataforma inferior hay dos codos, y su saliente tiene un codo de ancho. Desde la plataforma inferior hasta la parte alta de la plataforma superior hay cuatro codos, y su saliente tiene un codo de ancho.

**15** El fogón del altar mide cuatro codos de alto, y los cuatro cuernos salen hacia arriba desde el fogón del altar.

**16** El fogón del altar es cuadrado. Mide 12 codos de largo por 12 codos de ancho.

**17** Cada uno de los cuatro lados de la plataforma tiene 14 codos de largo por 14 codos de ancho; el borde que hay alrededor mide medio codo y su base tiene un codo por todos los lados. ”Y los escalones del altar dan al este”.

**18** Entonces él me dijo: “Hijo del hombre, esto es lo que dice el Señor Soberano Jehová: ‘Estas son las instrucciones que se deben seguir cuando se construya el altar para que puedan presentarse ofrendas quemadas en él y pueda salpicarse con sangre’.

**19** ”‘Como ofrenda por el pecado, les darás un toro joven de la manada a los sacerdotes levitas que son descendientes de Sadoc, los que se acercan a mí para servirme —afirma el Señor Soberano Jehová—.

**20** Para purificar de pecado el altar y hacer expiación por él, tomarás parte de su sangre y la pondrás en los cuatro cuernos del altar, en las cuatro esquinas de la plataforma y en el borde que hay alrededor.

**21** Después toma el toro joven, la ofrenda por el pecado, para quemarlo en el lugar del templo destinado para eso, fuera del santuario.

**22** El segundo día presentarás como ofrenda por el pecado un macho de las cabras que esté sano; y ellos purificarán de pecado el altar, tal como lo purificaron de pecado con el toro joven’.

**23** ”‘Cuando acabes de purificarlo de pecado, ofrecerás un toro joven de la manada que esté sano y un carnero del rebaño que esté sano.

**24** Se los ofrecerás a Jehová, y los sacerdotes les echarán sal encima y los presentarán como una ofrenda quemada para Jehová.

**25** Durante siete días presentarás como ofrenda diaria por el pecado un macho de las cabras, así como un toro joven de la manada y un carnero del rebaño; ofrecerás animales sin defecto.

**26** Durante siete días, ellos harán expiación por el altar, y tienen que purificarlo e inaugurarlo.

**27** Cuando se hayan completado los días, del octavo día en adelante, los sacerdotes presentarán en el altar sus ofrendas quemadas y sacrificios de paz; y yo estaré contento con ustedes’, afirma el Señor Soberano Jehová”.

### Notas a pie de página
- **v. 3:** O quizás “él vino”.
- **v. 4:** Lit. “la casa”.
- **v. 7:** Al parecer, transmitiendo un mensaje de Dios.
- **v. 7:** Lit. “sus reyes en su muerte”.
- **v. 8:** O “las jambas”.
- **v. 10:** Lit. “midan el modelo”.
- **v. 13:** Se refiere a codos largos. Ver apén. B14.
- **v. 13:** Unos 22,2 cm (8,75 in). Ver apén. B14.
- **v. 25:** O “perfectos”.
- **v. 27:** Es decir, del pueblo.
- **v. 27:** O “de comunión”.

---

## Ezequiel 44

**1** Él me llevó de vuelta por la puerta exterior del santuario que daba al este, y estaba cerrada.

**2** Entonces Jehová me dijo: “Esta puerta permanecerá cerrada. No se abrirá, y ningún ser humano entrará por ella; porque Jehová, el Dios de Israel, ha entrado por ella, así que tiene que permanecer cerrada.

**3** Pero el jefe, por ser jefe, se sentará allí para comer pan delante de Jehová. Entrará por el pórtico de la puerta y saldrá por él”.

**4** Luego me llevó por la puerta norte hasta delante del templo. Cuando miré, vi que la gloria de Jehová había llenado el templo de Jehová. De modo que caí rostro a tierra.

**5** Entonces Jehová me dijo: “Hijo del hombre, presta atención, observa y escucha atentamente todo lo que te digo sobre los estatutos y las leyes del templo de Jehová. Presta mucha atención a la entrada del templo y a todas las salidas del santuario.

**6** Tienes que decirle a la casa rebelde de Israel: ‘Esto es lo que dice el Señor Soberano Jehová: “Oh, casa de Israel, ¡ya basta de todas sus prácticas detestables!

**7** Cuando ustedes traen a mi santuario a extranjeros incircuncisos de corazón y de carne, ellos profanan mi templo. Ustedes presentan mi pan, la grasa y la sangre mientras se viola mi pacto por culpa de todas sus prácticas detestables.

**8** Ustedes no se han ocupado de mis cosas santas. En vez de eso, les encargan a otros que cumplan con los deberes de mi santuario”’.

**9** ”‘Esto es lo que dice el Señor Soberano Jehová: “Ningún extranjero que viva en Israel y sea incircunciso de corazón y de carne puede entrar en mi santuario”’.

**10** ”‘Pero los levitas que se alejaron de mí cuando Israel perdió el rumbo y se apartó de mí para seguir a sus ídolos repugnantes cargarán con las consecuencias de su error.

**11** Y serán siervos en mi santuario para supervisar las puertas del templo y para servir en el templo. Matarán a los animales para la ofrenda quemada y para el sacrificio por el pueblo, y estarán delante del pueblo para servirle.

**12** Como le sirvieron delante de sus ídolos repugnantes y se convirtieron en un obstáculo que hizo pecar a la casa de Israel, he levantado mi mano y jurado contra ellos —afirma el Señor Soberano Jehová—, y cargarán con las consecuencias de su error.

**13** No se acercarán a mí para servirme como sacerdotes ni se acercarán a ninguna de mis cosas santas o santísimas, y cargarán con la vergüenza por las cosas detestables que hicieron.

**14** Pero los pondré a cargo de las responsabilidades del templo para que cumplan con el servicio del templo y con todas las cosas que se deben hacer allí’.

**15** ”‘Y los sacerdotes levitas, los hijos de Sadoc, que cumplieron con las responsabilidades de mi santuario cuando los israelitas perdieron el rumbo y se apartaron de mí, se acercarán a mí para servirme y estarán delante de mí para ofrecerme la grasa y la sangre —afirma el Señor Soberano Jehová—.

**16** Ellos son los que entrarán en mi santuario; se acercarán a mi mesa para servirme y cumplirán con las responsabilidades que tienen conmigo.

**17** ”’Cuando entren por las puertas del patio interior, tienen que llevar ropa de lino. Que no lleven nada hecho de lana al servir en las puertas del patio interior o dentro de él.

**18** Tienen que llevar turbantes de lino en la cabeza y cubrirse las caderas con calzoncillos de lino. No deben ponerse nada que los haga sudar.

**19** Antes de salir al patio exterior —al patio exterior donde está el pueblo—, que se quiten la ropa con la que estaban sirviendo y la dejen en los comedores santos. Después se pondrán otra ropa para no transmitirle santidad al pueblo con su ropa.

**20** No deben afeitarse la cabeza ni dejarse el cabello largo. Tienen que recortarse el cabello.

**21** Que los sacerdotes no beban vino cuando entren en el patio interior.

**22** No deben tomar por esposa a una viuda ni a una mujer divorciada, pero sí pueden casarse con una virgen del pueblo de Israel o con la viuda de un sacerdote’.

**23** ”‘Tienen que instruir a mi pueblo sobre la diferencia entre lo que es santo y lo que es común; y les enseñarán la diferencia entre lo puro y lo impuro.

**24** Deben presidir como jueces en los casos legales; que juzguen según mis decisiones judiciales. Que obedezcan las leyes y los estatutos de todas mis fiestas y que santifiquen mis sábados.

**25** No deben acercarse a ningún ser humano muerto; si se acercan, se harán impuros. Sin embargo, pueden hacerse impuros por su padre, madre, hijo, hija, hermano o por una hermana soltera.

**26** Y, después de su purificación, el sacerdote esperará siete días.

**27** El día que entre en el lugar santo, en el patio interior, para servir en el lugar santo, debe presentar su ofrenda por el pecado’, afirma el Señor Soberano Jehová.

**28** ”‘Y esta será su herencia: yo soy su herencia. No les den ninguna propiedad en Israel, porque su propiedad soy yo.

**29** Ellos serán los que coman la ofrenda de grano, la ofrenda por el pecado y la ofrenda por la culpa, y todo lo que se haya dedicado a Dios en Israel será suyo.

**30** Lo mejor de todos los primeros frutos maduros y de todo tipo de contribución que ustedes hagan será de los sacerdotes. Y tienen que darles a los sacerdotes las primicias de su harina gruesa. Gracias a esto, una bendición reposará sobre las casas de ustedes.

**31** Los sacerdotes no deben comer ningún ave ni ningún otro animal encontrado muerto o despedazado’.

### Notas a pie de página
- **v. 5:** Lit. “pon tu corazón”.
- **v. 12:** O “tropiezo”.
- **v. 19:** O “cuartos”.
- **v. 19:** Lit. “santificar”.

---

## Ezequiel 45

**1** ”‘Cuando ustedes repartan la tierra como herencia, ofrezcan una porción santa de la tierra como contribución para Jehová. Debe tener 25.000 codos de largo por 10.000 codos de ancho. Toda esa área será una porción santa.

**2** Dentro de ella habrá una parcela cuadrada para el lugar santo; medirá 500 codos por 500 codos, y tendrá a cada lado una franja de 50 codos de ancho para campos de pasto.

**3** De esa zona, tienes que medir 25.000 codos de largo por 10.000 codos de ancho; allí estará el santuario, algo santísimo.

**4** Será una porción santa de la tierra para los sacerdotes, los siervos del santuario, los que se acercan allí para servir a Jehová. Será un lugar para sus casas y un lugar sagrado para el santuario.

**5** ”’Para los levitas, los siervos del templo, habrá una porción de 25.000 codos de largo por 10.000 codos de ancho, y tendrán 20 comedores en propiedad.

**6** ”’Tienen que darle en propiedad a la ciudad un área de 25.000 codos de largo (igual que la contribución santa) por 5.000 codos de ancho. Este terreno será de toda la casa de Israel.

**7** ”’Y habrá una porción de tierra para el jefe a ambos lados de la contribución santa y de la zona destinada a la ciudad. Estará al lado de la contribución santa y de la propiedad de la ciudad. Se extenderá por el lado oeste y por el lado este. Desde el límite occidental hasta el límite oriental, tendrá el mismo largo que la porción de tierra de una de las tribus.

**8** Esa tierra será su propiedad en Israel. Mis jefes no volverán a maltratar a mi pueblo, y le darán el resto de la tierra a la casa de Israel según sus tribus’.

**9** ”Esto es lo que dice el Señor Soberano Jehová: ‘¡Han ido demasiado lejos, jefes de Israel!’. ”‘Abandonen la violencia y la explotación, y hagan lo que es justo y recto. Dejen de quitarle a mi pueblo sus propiedades —afirma el Señor Soberano Jehová—.

**10** Usen balanzas exactas, un efá exacto y un bato exacto.

**11** Hay que tener una medida fija para el efá y para el bato. El bato contendrá la décima parte de un homer, y el efá, la décima parte de un homer. El homer será el estándar para las medidas.

**12** El siclo equivaldrá a 20 guerás. Y, para ustedes, 20 siclos más 25 siclos más 15 siclos sumarán un mané’.

**13** ”‘Esta es la contribución que ustedes deben ofrecer: por cada homer de trigo, la sexta parte de un efá; por cada homer de cebada, la sexta parte de un efá.

**14** Para el aceite, la cantidad fijada se basará en el bato. El bato es la décima parte de un coro, y 10 batos son un homer. Y es que 10 batos equivalen a un homer.

**15** Y ofrecerán una de cada 200 ovejas del rebaño de Israel. Todo esto se usará para la ofrenda de grano, la ofrenda quemada y los sacrificios de paz a fin de hacer expiación por el pueblo’, afirma el Señor Soberano Jehová.

**16** ”‘Toda la gente del país le hará esta contribución al jefe de Israel.

**17** Pero el jefe estará a cargo de las ofrendas quemadas, la ofrenda de grano y la ofrenda líquida durante las fiestas, las lunas nuevas, los sábados y todas las fiestas señaladas de la casa de Israel. Él es quien suministrará la ofrenda por el pecado, la ofrenda de grano, la ofrenda quemada y los sacrificios de paz para hacer expiación a favor de la casa de Israel’.

**18** ”Esto es lo que dice el Señor Soberano Jehová: ‘En el primer mes, en el primer día del mes, toma un toro joven de la manada que esté sano y purifica de pecado el santuario.

**19** El sacerdote tomará parte de la sangre de la ofrenda por el pecado y la pondrá en el poste de la puerta del templo, en las cuatro esquinas de la plataforma del altar y en el poste de la puerta del patio interior.

**20** Harás eso mismo en el día siete del mes a favor de cualquier persona que peque por equivocación o por ignorancia; y ustedes tienen que hacer expiación por el templo.

**21** ”’En el primer mes, en el día 14 del mes, celebrarás la fiesta de la Pascua. Se comerá pan sin levadura por siete días.

**22** Ese día, el jefe suministrará un toro joven como ofrenda por el pecado a favor de sí mismo y a favor de toda la gente del país.

**23** En los siete días de la fiesta, cada uno de los siete días, suministrará como ofrenda quemada para Jehová siete toros jóvenes y sanos, y siete carneros sanos, así como un macho de las cabras como ofrenda por el pecado cada día.

**24** También suministrará como ofrenda de grano un efá por cada toro joven y un efá por cada carnero, así como un hin de aceite por cada efá.

**25** ”’En el séptimo mes, desde el día 15 del mes, durante los siete días de la fiesta, suministrará las mismas cosas: la ofrenda por el pecado, la ofrenda quemada, la ofrenda de grano y el aceite’”.

### Notas a pie de página
- **v. 1:** Se refiere a codos largos. Ver apén. B14.
- **v. 1:** O “Dentro de todos sus límites”.
- **v. 2:** Lit. “500 por 500”.
- **v. 5:** O “cuartos”.
- **v. 10:** Ver apén. B14.
- **v. 10:** Ver apén. B14.
- **v. 11:** Ver apén. B14.
- **v. 12:** Ver apén. B14.
- **v. 12:** Ver apén. B14.
- **v. 12:** O “una mina”. Ver apén. B14.
- **v. 14:** Ver apén. B14.
- **v. 19:** O “la jamba”.
- **v. 24:** Ver apén. B14.

---

## Ezequiel 46

**1** “Esto es lo que dice el Señor Soberano Jehová: ‘La puerta del patio interior que da al este debe permanecer cerrada los seis días laborables, pero se debe abrir en sábado y en el día de la luna nueva.

**2** El jefe entrará desde el exterior por el pórtico de la puerta y se quedará junto al poste de la puerta. Los sacerdotes presentarán la ofrenda quemada y los sacrificios de paz de él, y él se inclinará en el umbral de la puerta y entonces saldrá. Pero la puerta no debe cerrarse hasta el atardecer.

**3** La gente del país también se inclinará delante de Jehová a la entrada de la puerta en sábado y en luna nueva.

**4** ”’La ofrenda quemada que el jefe le presentará a Jehová en sábado estará compuesta por seis corderos sanos y un carnero sano.

**5** La ofrenda de grano será de un efá por el carnero y, por los corderos, lo que él pueda dar, además de un hin de aceite con cada efá.

**6** El día de la luna nueva, la ofrenda estará compuesta por un toro joven y sano de la manada, seis corderos y un carnero; deben estar sanos.

**7** Que presente como ofrenda de grano un efá por el toro joven, un efá por el carnero y, por los corderos, lo que esté dentro de sus posibilidades. Y que ofrezca un hin de aceite con cada efá.

**8** ”’Cuando el jefe entre, debe entrar por el pórtico de la puerta y salir por el mismo sitio.

**9** Y, cuando la gente del país entre delante de Jehová durante las fiestas, los que entren por la puerta norte para adorarlo, que salgan por la puerta sur, y los que entren por la puerta sur, que salgan por la puerta norte. Que nadie regrese por la puerta por la que entró, sino que todos salgan por la puerta opuesta.

**10** En cuanto al jefe que esté en medio de ellos, que entre cuando ellos entren y que salga cuando ellos salgan.

**11** Durante las fiestas y las temporadas festivas, la ofrenda de grano será de un efá por el toro joven, un efá por el carnero y, por los corderos, lo que él pueda dar, además de un hin de aceite con cada efá.

**12** ”’Si el jefe suministra una ofrenda quemada o sacrificios de paz como ofrenda voluntaria para Jehová, abrirán para él la puerta que da al este, y él suministrará su ofrenda quemada y su sacrificio de paz tal como lo hace en sábado. Después de que él salga, debe cerrarse la puerta.

**13** ”’Debes suministrar cada día un cordero sano en su primer año como ofrenda quemada para Jehová. Lo harás mañana tras mañana.

**14** Además, cada mañana, suministra esto como ofrenda de grano: una sexta parte de un efá junto con un tercio de un hin de aceite para rociarlo sobre la harina fina. Esta será una ofrenda regular de grano para Jehová; es un estatuto permanente.

**15** El cordero, la ofrenda de grano y el aceite se suministrarán cada mañana como una ofrenda quemada regular’.

**16** ”Esto es lo que dice el Señor Soberano Jehová: ‘Si el jefe le da a cada uno de sus hijos un regalo como herencia, este les pertenecerá a sus hijos. Es su propiedad por herencia.

**17** Pero, si le da una parte de su herencia como regalo a uno de sus siervos, esta será de él hasta el año de libertad, y entonces volverá a ser del jefe. Solo la herencia dada a sus hijos seguirá siendo de ellos permanentemente.

**18** El jefe no debe quitarle al pueblo nada de su herencia obligándolos a salir de sus propiedades. La herencia que les dé a sus hijos la tomará de lo que es propiedad suya para que a nadie de mi pueblo se le eche de su propiedad’”.

**19** Después el hombre me llevó a la entrada que estaba al lado de la puerta que daba acceso a los comedores santos de los sacerdotes, los que daban al norte, y vi allí un lugar en la parte de atrás, hacia el oeste.

**20** Me dijo: “Este es el lugar donde los sacerdotes hervirán la ofrenda por la culpa y la ofrenda por el pecado, y donde hornearán la ofrenda de grano, para que no saquen nada al patio exterior y le transmitan santidad al pueblo”.

**21** Él me sacó al patio exterior y me hizo pasar por las cuatro esquinas del patio, y vi otro patio en cada esquina del patio exterior.

**22** En las cuatro esquinas del patio había unos patios pequeños. Tenían 40 codos de largo por 30 codos de ancho; los cuatro eran del mismo tamaño.

**23** Dentro de los cuatro, en cada lado, había bancos de piedra, y debajo de los bancos había sitios para hervir las ofrendas.

**24** Entonces me dijo: “Estos son los lugares donde los siervos del templo hierven los sacrificios del pueblo”.

### Notas a pie de página
- **v. 2:** O “a la jamba”.
- **v. 5:** Ver apén. B14.
- **v. 5:** Ver apén. B14.
- **v. 19:** O “cuartos”.
- **v. 20:** Lit. “santifiquen”.
- **v. 22:** Se refiere a codos largos. Ver apén. B14.
- **v. 22:** O “los cuatro y sus estructuras de esquina eran del mismo tamaño”.
- **v. 23:** O “hileras”.
- **v. 24:** O “Estas son las casas”.

---

## Ezequiel 47

**1** Entonces él me llevó de vuelta a la entrada del templo, y allí vi agua saliendo de debajo del umbral del templo; corría hacia el este, porque la fachada del templo daba al este. El agua salía de debajo del lado derecho del templo, al sur del altar.

**2** Luego me sacó de allí por la puerta norte y me hizo dar la vuelta por fuera hasta la puerta exterior que daba al este, y vi que salía un poco de agua por el lado derecho.

**3** Cuando el hombre salió hacia el este con un cordón de medir en la mano, midió 1.000 codos y me hizo cruzar el agua; el agua me llegaba a los tobillos.

**4** Después midió otros 1.000 y me hizo cruzar el agua, y esta me llegaba a las rodillas. Midió otros 1.000 más y me hizo cruzar, y el agua me llegaba a las caderas.

**5** Cuando midió otros 1.000, ya era un torrente que yo no podía cruzar andando, porque el agua era tan profunda que había que nadar; era un torrente imposible de atravesar a pie.

**6** Él me preguntó: “¿Has visto esto, hijo del hombre?”. Entonces me hizo volver andando a la orilla del río.

**7** Cuando regresé, vi que había muchísimos árboles en las dos orillas del río.

**8** Después me dijo: “Esta agua corre hacia la región oriental, baja por el Arabá y llega al mar. Cuando llegue al mar, el agua del mar será sanada.

**9** Por donde corran las aguas, multitudes de seres vivos podrán vivir. Habrá peces en abundancia, pues por allí correrá esta agua. El agua de mar será sanada y, por donde pase el río, todo vivirá.

**10** ”Los pescadores se quedarán en la orilla, desde En-Guedí hasta En-Eglaim, donde habrá un secadero para redes de pesca. Habrá una gran cantidad de peces, de muchos tipos, como los peces del mar Grande.

**11** ”Habrá pantanos y lagunas cenagosas, pero estos no serán sanados. Seguirán siendo salados.

**12** ”En las dos orillas del río crecerá todo tipo de árboles frutales. Sus hojas no se marchitarán ni su fruto se estropeará. Cada mes darán nuevos frutos, porque el agua que los riega sale del santuario. Su fruto servirá de alimento, y sus hojas, para sanar”.

**13** Esto es lo que dice el Señor Soberano Jehová: “Este es el territorio que ustedes repartirán como la herencia de tierra de las 12 tribus de Israel, y José recibirá dos partes.

**14** Ustedes la heredarán y recibirán partes iguales. Les juré a sus antepasados que les daría esta tierra, así que ahora se reparte entre ustedes como herencia.

**15** ”Este es el límite de la tierra por el lado norte: va desde el mar Grande por el camino de Hetlón en dirección a Zedad,

**16** Hamat, Berotá y Sibraim —que está entre el territorio de Damasco y el territorio de Hamat—, y sigue hasta Hazer-Haticón, que está junto al límite de Haurán.

**17** Así que el límite irá desde el mar hasta Hazar-Enón, a lo largo del límite de Damasco, al norte, y del límite de Hamat. Esa es la frontera norte.

**18** ”El lado este pasa entre Haurán y Damasco, y sigue a lo largo del río Jordán, entre Galaad y la tierra de Israel. Midan la distancia desde el límite hasta el mar del este. Esa es la frontera este.

**19** ”La frontera sur irá desde Tamar hasta las aguas de Meribat-Cadés, y de allí hasta el Torrente y hasta el mar Grande. Esa es la frontera sur.

**20** ”En el lado oeste está el mar Grande, desde el límite hasta cierto lugar enfrente de Lebó-Hamat. Esa es la frontera oeste”.

**21** “Se repartirán esta tierra entre ustedes, entre las 12 tribus de Israel.

**22** Distribúyanla como herencia entre ustedes y los extranjeros que viven con ustedes y que han tenido hijos mientras vivían entre ustedes. Ellos deben ser considerados israelitas de nacimiento. Recibirán una herencia entre las tribus de Israel junto con ustedes.

**23** Deben darle al residente extranjero una herencia en el territorio de la tribu en la que se haya establecido”, afirma el Señor Soberano Jehová.

### Notas a pie de página
- **v. 3:** Se refiere a codos largos. Ver apén. B14.
- **v. 8:** O “la llanura desértica”.
- **v. 9:** Lit. “los dos ríos”.
- **v. 10:** O “redes barrederas”.
- **v. 10:** Es decir, el mar Mediterráneo.
- **v. 12:** Lit. “árboles de alimento”.
- **v. 14:** Lit. “la heredarán, cada uno como su hermano”.
- **v. 14:** Lit. “les cae a”.
- **v. 18:** Es decir, el límite norte.
- **v. 18:** Es decir, el mar Muerto.
- **v. 19:** Lit. “El lado sur hacia el sur”.
- **v. 19:** Es decir, el torrente (wadi) de Egipto.
- **v. 19:** Lit. “Este es el lado sur hacia el sur”.
- **v. 20:** Es decir, el límite sur.
- **v. 20:** O “la entrada de Hamat”.

---

## Ezequiel 48

**1** “Estos son los nombres de las tribus empezando por el extremo norte: la parte de Dan pasa a lo largo del camino de Hetlón hasta Lebó-Hamat y hasta Hazar-Enán, a lo largo del límite de Damasco en dirección norte, al lado de Hamat; y se extiende desde la frontera este hasta la oeste.

**2** La parte de Aser limita con la de Dan, desde la frontera este hasta la oeste.

**3** La parte de Neftalí limita con la de Aser, desde la frontera este hasta la oeste.

**4** La parte de Manasés limita con la de Neftalí, desde la frontera este hasta la oeste.

**5** La parte de Efraín limita con la de Manasés, desde la frontera este hasta la oeste.

**6** La parte de Rubén limita con la de Efraín, desde la frontera este hasta la oeste.

**7** La parte de Judá limita con la de Rubén, desde la frontera este hasta la oeste.

**8** Limitando con Judá, desde la frontera este hasta la oeste, la contribución que ustedes deben reservar será de 25.000 codos de ancho; de largo será igual que las partes de las otras tribus desde la frontera este hasta la oeste. El santuario estará en medio de ella.

**9** ”La contribución que ustedes reservarán para Jehová tendrá 25.000 codos de largo por 10.000 codos de ancho.

**10** Esta será la contribución santa para los sacerdotes: 25.000 codos por el norte, 10.000 por el oeste, 10.000 por el este y 25.000 por el sur. El santuario de Jehová estará en medio de ella.

**11** Esta será para los sacerdotes santificados de los hijos de Sadoc, los que cumplieron con las responsabilidades que tenían conmigo y no se desviaron cuando los israelitas y los levitas se desviaron.

**12** Ellos tendrán una parte de la contribución de la tierra reservada como algo santísimo; esta limitará con la de los levitas.

**13** ”Justo al lado del territorio de los sacerdotes, los levitas tendrán una parte de 25.000 codos de largo por 10.000 codos de ancho. (El largo total será de 25.000 codos, y el ancho, de 10.000).

**14** No deben vender, cambiar o traspasar ninguna parcela de esta, que es la mejor parte de la tierra, ya que es algo santo para Jehová.

**15** ”El resto del terreno, de 5.000 codos de ancho a lo largo del límite de 25.000 codos, será para uso comunitario de la ciudad, para viviendas y campos de pasto. La ciudad estará en medio de él.

**16** Estas son las medidas de la ciudad: el límite norte, 4.500 codos; el límite sur, 4.500; el límite este, 4.500, y el límite oeste, 4.500.

**17** El campo de pasto de la ciudad tendrá 250 codos por el norte, 250 por el sur, 250 por el este y 250 por el oeste.

**18** ”El largo de la parte que quede se extenderá a lo largo de la contribución santa: 10.000 codos por el este y 10.000 por el oeste. Se extenderá a lo largo de la contribución santa, y su producto servirá de alimento para los trabajadores de la ciudad.

**19** Será cultivada por los trabajadores de la ciudad, que vendrán de todas las tribus de Israel.

**20** ”La contribución entera es un cuadrado de 25.000 codos por cada lado. Deben reservarla como contribución santa junto con la propiedad de la ciudad.

**21** ”El terreno que quede a los dos lados de la contribución santa y de la propiedad de la ciudad será del jefe. Lindará con los límites de 25.000 codos al este y al oeste de la contribución. Correrá paralelo a las dos partes contiguas y será del jefe. La contribución santa y el santuario del templo estarán en medio de su porción de tierra.

**22** ”La propiedad de los levitas y la propiedad de la ciudad estarán en medio de la parte que le pertenece al jefe. El territorio del jefe estará entre el límite con Judá y el límite con Benjamín.

**23** ”En cuanto a las demás tribus, la parte de Benjamín se extiende desde la frontera este hasta la frontera oeste.

**24** La parte de Simeón limita con la de Benjamín, desde la frontera este hasta la oeste.

**25** La parte de Isacar limita con la de Simeón, desde la frontera este hasta la oeste.

**26** La parte de Zabulón limita con la de Isacar, desde la frontera este hasta la oeste.

**27** La parte de Gad limita con la de Zabulón, desde la frontera este hasta la oeste.

**28** La frontera sur, que corre a lo largo del límite de Gad, va desde Tamar hasta las aguas de Meribat-Cadés, hasta el Torrente, y desde allí hasta el mar Grande.

**29** ”Esa es la tierra que ustedes les repartirán como herencia a las tribus de Israel, y esas serán las partes de cada una”, afirma el Señor Soberano Jehová.

**30** “Estas serán las salidas de la ciudad: el lado norte medirá 4.500 codos.

**31** ”Las puertas de la ciudad llevarán el nombre de las tribus de Israel. Habrá tres puertas por el norte: una puerta para Rubén, una puerta para Judá y una puerta para Leví.

**32** ”El lado este medirá 4.500 codos, y allí habrá tres puertas: una puerta para José, una puerta para Benjamín y una puerta para Dan.

**33** ”El lado sur medirá 4.500 codos y tendrá tres puertas: una puerta para Simeón, una puerta para Isacar y una puerta para Zabulón.

**34** ”El lado oeste medirá 4.500 codos y tendrá tres puertas: una puerta para Gad, una puerta para Aser y una puerta para Neftalí.

**35** ”El perímetro de la ciudad tendrá 18.000 codos. A partir de ese día, este será el nombre de la ciudad: Jehová Está Allí”.

### Notas a pie de página
- **v. 1:** O “la entrada de Hamat”.
- **v. 8:** Se refiere a codos largos. Ver apén. B14.
- **v. 28:** Es decir, el torrente (wadi) de Egipto.
- **v. 28:** Es decir, el mar Mediterráneo.
